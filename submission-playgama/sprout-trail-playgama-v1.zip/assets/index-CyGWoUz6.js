var $f=Object.defineProperty;var Yf=(i,e,t)=>e in i?$f(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var te=(i,e,t)=>Yf(i,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const rl="170",jf=0,tu=1,Kf=2,cd=1,ld=2,Jn=3,si=0,on=1,Bt=2,bi=0,$i=1,Cs=2,nu=3,iu=4,Zf=5,Wi=100,Jf=101,Qf=102,ep=103,tp=104,np=200,ip=201,sp=202,rp=203,Qa=204,ec=205,op=206,ap=207,cp=208,lp=209,up=210,hp=211,dp=212,fp=213,pp=214,tc=0,nc=1,ic=2,Ps=3,sc=4,rc=5,oc=6,ac=7,ol=0,mp=1,gp=2,Ei=0,_p=1,xp=2,vp=3,ud=4,yp=5,Mp=6,Sp=7,su="attached",wp="detached",hd=300,Ls=301,Is=302,cc=303,lc=304,Xo=306,Yi=1e3,Si=1001,No=1002,en=1003,dd=1004,hr=1005,hn=1006,Eo=1007,ti=1008,ri=1009,fd=1010,pd=1011,yr=1012,al=1013,ji=1014,Dn=1015,Ir=1016,cl=1017,ll=1018,Ds=1020,md=35902,gd=1021,_d=1022,Mn=1023,xd=1024,vd=1025,bs=1026,Ns=1027,ul=1028,hl=1029,yd=1030,dl=1031,fl=1033,To=33776,Ao=33777,Ro=33778,Co=33779,uc=35840,hc=35841,dc=35842,fc=35843,pc=36196,mc=37492,gc=37496,_c=37808,xc=37809,vc=37810,yc=37811,Mc=37812,Sc=37813,wc=37814,bc=37815,Ec=37816,Tc=37817,Ac=37818,Rc=37819,Cc=37820,Pc=37821,Po=36492,Lc=36494,Ic=36495,Md=36283,Dc=36284,Nc=36285,Uc=36286,Mr=2300,Sr=2301,aa=2302,ru=2400,ou=2401,au=2402,bp=2500,Ep=0,Sd=1,kc=2,Tp=3200,Ap=3201,pl=0,Rp=1,yi="",Lt="srgb",nn="srgb-linear",qo="linear",pt="srgb",is=7680,cu=519,Cp=512,Pp=513,Lp=514,wd=515,Ip=516,Dp=517,Np=518,Up=519,Fc=35044,lu="300 es",ni=2e3,Uo=2001;class Vs{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const s=this._listeners[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const n=this._listeners[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}}const Wt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let uu=1234567;const mr=Math.PI/180,Us=180/Math.PI;function wn(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Wt[i&255]+Wt[i>>8&255]+Wt[i>>16&255]+Wt[i>>24&255]+"-"+Wt[e&255]+Wt[e>>8&255]+"-"+Wt[e>>16&15|64]+Wt[e>>24&255]+"-"+Wt[t&63|128]+Wt[t>>8&255]+"-"+Wt[t>>16&255]+Wt[t>>24&255]+Wt[n&255]+Wt[n>>8&255]+Wt[n>>16&255]+Wt[n>>24&255]).toLowerCase()}function It(i,e,t){return Math.max(e,Math.min(t,i))}function ml(i,e){return(i%e+e)%e}function kp(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function Fp(i,e,t){return i!==e?(t-i)/(e-i):0}function gr(i,e,t){return(1-t)*i+t*e}function Op(i,e,t,n){return gr(i,e,1-Math.exp(-t*n))}function Bp(i,e=1){return e-Math.abs(ml(i,e*2)-e)}function zp(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function Hp(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function Vp(i,e){return i+Math.floor(Math.random()*(e-i+1))}function Gp(i,e){return i+Math.random()*(e-i)}function Wp(i){return i*(.5-Math.random())}function Xp(i){i!==void 0&&(uu=i);let e=uu+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function qp(i){return i*mr}function $p(i){return i*Us}function Yp(i){return(i&i-1)===0&&i!==0}function jp(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Kp(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Zp(i,e,t,n,s){const r=Math.cos,o=Math.sin,a=r(t/2),c=o(t/2),l=r((e+n)/2),u=o((e+n)/2),h=r((e-n)/2),d=o((e-n)/2),f=r((n-e)/2),g=o((n-e)/2);switch(s){case"XYX":i.set(a*u,c*h,c*d,a*l);break;case"YZY":i.set(c*d,a*u,c*h,a*l);break;case"ZXZ":i.set(c*h,c*d,a*u,a*l);break;case"XZX":i.set(a*u,c*g,c*f,a*l);break;case"YXY":i.set(c*f,a*u,c*g,a*l);break;case"ZYZ":i.set(c*g,c*f,a*u,a*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function In(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ht(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const gl={DEG2RAD:mr,RAD2DEG:Us,generateUUID:wn,clamp:It,euclideanModulo:ml,mapLinear:kp,inverseLerp:Fp,lerp:gr,damp:Op,pingpong:Bp,smoothstep:zp,smootherstep:Hp,randInt:Vp,randFloat:Gp,randFloatSpread:Wp,seededRandom:Xp,degToRad:qp,radToDeg:$p,isPowerOfTwo:Yp,ceilPowerOfTwo:jp,floorPowerOfTwo:Kp,setQuaternionFromProperEuler:Zp,normalize:ht,denormalize:In};class se{constructor(e=0,t=0){se.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(It(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Ke{constructor(e,t,n,s,r,o,a,c,l){Ke.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,c,l)}set(e,t,n,s,r,o,a,c,l){const u=this.elements;return u[0]=e,u[1]=s,u[2]=a,u[3]=t,u[4]=r,u[5]=c,u[6]=n,u[7]=o,u[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[3],c=n[6],l=n[1],u=n[4],h=n[7],d=n[2],f=n[5],g=n[8],_=s[0],m=s[3],p=s[6],M=s[1],v=s[4],x=s[7],I=s[2],A=s[5],T=s[8];return r[0]=o*_+a*M+c*I,r[3]=o*m+a*v+c*A,r[6]=o*p+a*x+c*T,r[1]=l*_+u*M+h*I,r[4]=l*m+u*v+h*A,r[7]=l*p+u*x+h*T,r[2]=d*_+f*M+g*I,r[5]=d*m+f*v+g*A,r[8]=d*p+f*x+g*T,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8];return t*o*u-t*a*l-n*r*u+n*a*c+s*r*l-s*o*c}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],h=u*o-a*l,d=a*c-u*r,f=l*r-o*c,g=t*h+n*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return e[0]=h*_,e[1]=(s*l-u*n)*_,e[2]=(a*n-s*o)*_,e[3]=d*_,e[4]=(u*t-s*c)*_,e[5]=(s*r-a*t)*_,e[6]=f*_,e[7]=(n*c-l*t)*_,e[8]=(o*t-n*r)*_,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,a){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*o+l*a)+o+e,-s*l,s*c,-s*(-l*o+c*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(ca.makeScale(e,t)),this}rotate(e){return this.premultiply(ca.makeRotation(-e)),this}translate(e,t){return this.premultiply(ca.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const ca=new Ke;function bd(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function wr(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Jp(){const i=wr("canvas");return i.style.display="block",i}const hu={};function dr(i){i in hu||(hu[i]=!0,console.warn(i))}function Qp(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}function em(i){const e=i.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function tm(i){const e=i.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const st={enabled:!0,workingColorSpace:nn,spaces:{},convert:function(i,e,t){return this.enabled===!1||e===t||!e||!t||(this.spaces[e].transfer===pt&&(i.r=ii(i.r),i.g=ii(i.g),i.b=ii(i.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(i.applyMatrix3(this.spaces[e].toXYZ),i.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===pt&&(i.r=Es(i.r),i.g=Es(i.g),i.b=Es(i.b))),i},fromWorkingColorSpace:function(i,e){return this.convert(i,this.workingColorSpace,e)},toWorkingColorSpace:function(i,e){return this.convert(i,e,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===yi?qo:this.spaces[i].transfer},getLuminanceCoefficients:function(i,e=this.workingColorSpace){return i.fromArray(this.spaces[e].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,e,t){return i.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function ii(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Es(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}const du=[.64,.33,.3,.6,.15,.06],fu=[.2126,.7152,.0722],pu=[.3127,.329],mu=new Ke().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),gu=new Ke().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);st.define({[nn]:{primaries:du,whitePoint:pu,transfer:qo,toXYZ:mu,fromXYZ:gu,luminanceCoefficients:fu,workingColorSpaceConfig:{unpackColorSpace:Lt},outputColorSpaceConfig:{drawingBufferColorSpace:Lt}},[Lt]:{primaries:du,whitePoint:pu,transfer:pt,toXYZ:mu,fromXYZ:gu,luminanceCoefficients:fu,outputColorSpaceConfig:{drawingBufferColorSpace:Lt}}});let ss;class nm{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{ss===void 0&&(ss=wr("canvas")),ss.width=e.width,ss.height=e.height;const n=ss.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=ss}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=wr("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=ii(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(ii(t[n]/255)*255):t[n]=ii(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let im=0;class Ed{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:im++}),this.uuid=wn(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(la(s[o].image)):r.push(la(s[o]))}else r=la(s);n.url=r}return t||(e.images[this.uuid]=n),n}}function la(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?nm.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let sm=0;class Nt extends Vs{constructor(e=Nt.DEFAULT_IMAGE,t=Nt.DEFAULT_MAPPING,n=Si,s=Si,r=hn,o=ti,a=Mn,c=ri,l=Nt.DEFAULT_ANISOTROPY,u=yi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:sm++}),this.uuid=wn(),this.name="",this.source=new Ed(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new se(0,0),this.repeat=new se(1,1),this.center=new se(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ke,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==hd)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Yi:e.x=e.x-Math.floor(e.x);break;case Si:e.x=e.x<0?0:1;break;case No:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Yi:e.y=e.y-Math.floor(e.y);break;case Si:e.y=e.y<0?0:1;break;case No:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Nt.DEFAULT_IMAGE=null;Nt.DEFAULT_MAPPING=hd;Nt.DEFAULT_ANISOTROPY=1;class at{constructor(e=0,t=0,n=0,s=1){at.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r;const c=e.elements,l=c[0],u=c[4],h=c[8],d=c[1],f=c[5],g=c[9],_=c[2],m=c[6],p=c[10];if(Math.abs(u-d)<.01&&Math.abs(h-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(u+d)<.1&&Math.abs(h+_)<.1&&Math.abs(g+m)<.1&&Math.abs(l+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const v=(l+1)/2,x=(f+1)/2,I=(p+1)/2,A=(u+d)/4,T=(h+_)/4,P=(g+m)/4;return v>x&&v>I?v<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(v),s=A/n,r=T/n):x>I?x<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(x),n=A/s,r=P/s):I<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(I),n=T/r,s=P/r),this.set(n,s,r,t),this}let M=Math.sqrt((m-g)*(m-g)+(h-_)*(h-_)+(d-u)*(d-u));return Math.abs(M)<.001&&(M=1),this.x=(m-g)/M,this.y=(h-_)/M,this.z=(d-u)/M,this.w=Math.acos((l+f+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class rm extends Vs{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new at(0,0,e,t),this.scissorTest=!1,this.viewport=new at(0,0,e,t);const s={width:e,height:t,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:hn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const r=new Nt(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,s=e.textures.length;n<s;n++)this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new Ed(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ki extends rm{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Td extends Nt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=en,this.minFilter=en,this.wrapR=Si,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class om extends Nt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=en,this.minFilter=en,this.wrapR=Si,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Un{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,a){let c=n[s+0],l=n[s+1],u=n[s+2],h=n[s+3];const d=r[o+0],f=r[o+1],g=r[o+2],_=r[o+3];if(a===0){e[t+0]=c,e[t+1]=l,e[t+2]=u,e[t+3]=h;return}if(a===1){e[t+0]=d,e[t+1]=f,e[t+2]=g,e[t+3]=_;return}if(h!==_||c!==d||l!==f||u!==g){let m=1-a;const p=c*d+l*f+u*g+h*_,M=p>=0?1:-1,v=1-p*p;if(v>Number.EPSILON){const I=Math.sqrt(v),A=Math.atan2(I,p*M);m=Math.sin(m*A)/I,a=Math.sin(a*A)/I}const x=a*M;if(c=c*m+d*x,l=l*m+f*x,u=u*m+g*x,h=h*m+_*x,m===1-a){const I=1/Math.sqrt(c*c+l*l+u*u+h*h);c*=I,l*=I,u*=I,h*=I}}e[t]=c,e[t+1]=l,e[t+2]=u,e[t+3]=h}static multiplyQuaternionsFlat(e,t,n,s,r,o){const a=n[s],c=n[s+1],l=n[s+2],u=n[s+3],h=r[o],d=r[o+1],f=r[o+2],g=r[o+3];return e[t]=a*g+u*h+c*f-l*d,e[t+1]=c*g+u*d+l*h-a*f,e[t+2]=l*g+u*f+a*d-c*h,e[t+3]=u*g-a*h-c*d-l*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,c=Math.sin,l=a(n/2),u=a(s/2),h=a(r/2),d=c(n/2),f=c(s/2),g=c(r/2);switch(o){case"XYZ":this._x=d*u*h+l*f*g,this._y=l*f*h-d*u*g,this._z=l*u*g+d*f*h,this._w=l*u*h-d*f*g;break;case"YXZ":this._x=d*u*h+l*f*g,this._y=l*f*h-d*u*g,this._z=l*u*g-d*f*h,this._w=l*u*h+d*f*g;break;case"ZXY":this._x=d*u*h-l*f*g,this._y=l*f*h+d*u*g,this._z=l*u*g+d*f*h,this._w=l*u*h-d*f*g;break;case"ZYX":this._x=d*u*h-l*f*g,this._y=l*f*h+d*u*g,this._z=l*u*g-d*f*h,this._w=l*u*h+d*f*g;break;case"YZX":this._x=d*u*h+l*f*g,this._y=l*f*h+d*u*g,this._z=l*u*g-d*f*h,this._w=l*u*h-d*f*g;break;case"XZY":this._x=d*u*h-l*f*g,this._y=l*f*h-d*u*g,this._z=l*u*g+d*f*h,this._w=l*u*h+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],a=t[5],c=t[9],l=t[2],u=t[6],h=t[10],d=n+a+h;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(u-c)*f,this._y=(r-l)*f,this._z=(o-s)*f}else if(n>a&&n>h){const f=2*Math.sqrt(1+n-a-h);this._w=(u-c)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+l)/f}else if(a>h){const f=2*Math.sqrt(1+a-n-h);this._w=(r-l)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(c+u)/f}else{const f=2*Math.sqrt(1+h-n-a);this._w=(o-s)/f,this._x=(r+l)/f,this._y=(c+u)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(It(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,r=e._z,o=e._w,a=t._x,c=t._y,l=t._z,u=t._w;return this._x=n*u+o*a+s*l-r*c,this._y=s*u+o*c+r*a-n*l,this._z=r*u+o*l+n*c-s*a,this._w=o*u-n*a-s*c-r*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,s=this._y,r=this._z,o=this._w;let a=o*e._w+n*e._x+s*e._y+r*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;const c=1-a*a;if(c<=Number.EPSILON){const f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*s+t*this._y,this._z=f*r+t*this._z,this.normalize(),this}const l=Math.sqrt(c),u=Math.atan2(l,a),h=Math.sin((1-t)*u)/l,d=Math.sin(t*u)/l;return this._w=o*h+this._w*d,this._x=n*h+this._x*d,this._y=s*h+this._y*d,this._z=r*h+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class R{constructor(e=0,t=0,n=0){R.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(_u.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(_u.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,a=e.z,c=e.w,l=2*(o*s-a*n),u=2*(a*t-r*s),h=2*(r*n-o*t);return this.x=t+c*l+o*h-a*u,this.y=n+c*u+a*l-r*h,this.z=s+c*h+r*u-o*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,r=e.z,o=t.x,a=t.y,c=t.z;return this.x=s*c-r*a,this.y=r*o-n*c,this.z=n*a-s*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return ua.copy(this).projectOnVector(e),this.sub(ua)}reflect(e){return this.sub(ua.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(It(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const ua=new R,_u=new Un;class Bn{constructor(e=new R(1/0,1/0,1/0),t=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(An.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(An.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=An.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,An):An.fromBufferAttribute(r,o),An.applyMatrix4(e.matrixWorld),this.expandByPoint(An);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),zr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),zr.copy(n.boundingBox)),zr.applyMatrix4(e.matrixWorld),this.union(zr)}const s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,An),An.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Qs),Hr.subVectors(this.max,Qs),rs.subVectors(e.a,Qs),os.subVectors(e.b,Qs),as.subVectors(e.c,Qs),di.subVectors(os,rs),fi.subVectors(as,os),Di.subVectors(rs,as);let t=[0,-di.z,di.y,0,-fi.z,fi.y,0,-Di.z,Di.y,di.z,0,-di.x,fi.z,0,-fi.x,Di.z,0,-Di.x,-di.y,di.x,0,-fi.y,fi.x,0,-Di.y,Di.x,0];return!ha(t,rs,os,as,Hr)||(t=[1,0,0,0,1,0,0,0,1],!ha(t,rs,os,as,Hr))?!1:(Vr.crossVectors(di,fi),t=[Vr.x,Vr.y,Vr.z],ha(t,rs,os,as,Hr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,An).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(An).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(qn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),qn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),qn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),qn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),qn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),qn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),qn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),qn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(qn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const qn=[new R,new R,new R,new R,new R,new R,new R,new R],An=new R,zr=new Bn,rs=new R,os=new R,as=new R,di=new R,fi=new R,Di=new R,Qs=new R,Hr=new R,Vr=new R,Ni=new R;function ha(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Ni.fromArray(i,r);const a=s.x*Math.abs(Ni.x)+s.y*Math.abs(Ni.y)+s.z*Math.abs(Ni.z),c=e.dot(Ni),l=t.dot(Ni),u=n.dot(Ni);if(Math.max(-Math.max(c,l,u),Math.min(c,l,u))>a)return!1}return!0}const am=new Bn,er=new R,da=new R;class zn{constructor(e=new R,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):am.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;er.subVectors(e,this.center);const t=er.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(er,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(da.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(er.copy(e.center).add(da)),this.expandByPoint(er.copy(e.center).sub(da))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const $n=new R,fa=new R,Gr=new R,pi=new R,pa=new R,Wr=new R,ma=new R;class $o{constructor(e=new R,t=new R(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,$n)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=$n.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):($n.copy(this.origin).addScaledVector(this.direction,t),$n.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){fa.copy(e).add(t).multiplyScalar(.5),Gr.copy(t).sub(e).normalize(),pi.copy(this.origin).sub(fa);const r=e.distanceTo(t)*.5,o=-this.direction.dot(Gr),a=pi.dot(this.direction),c=-pi.dot(Gr),l=pi.lengthSq(),u=Math.abs(1-o*o);let h,d,f,g;if(u>0)if(h=o*c-a,d=o*a-c,g=r*u,h>=0)if(d>=-g)if(d<=g){const _=1/u;h*=_,d*=_,f=h*(h+o*d+2*a)+d*(o*h+d+2*c)+l}else d=r,h=Math.max(0,-(o*d+a)),f=-h*h+d*(d+2*c)+l;else d=-r,h=Math.max(0,-(o*d+a)),f=-h*h+d*(d+2*c)+l;else d<=-g?(h=Math.max(0,-(-o*r+a)),d=h>0?-r:Math.min(Math.max(-r,-c),r),f=-h*h+d*(d+2*c)+l):d<=g?(h=0,d=Math.min(Math.max(-r,-c),r),f=d*(d+2*c)+l):(h=Math.max(0,-(o*r+a)),d=h>0?r:Math.min(Math.max(-r,-c),r),f=-h*h+d*(d+2*c)+l);else d=o>0?-r:r,h=Math.max(0,-(o*d+a)),f=-h*h+d*(d+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,h),s&&s.copy(fa).addScaledVector(Gr,d),f}intersectSphere(e,t){$n.subVectors(e.center,this.origin);const n=$n.dot(this.direction),s=$n.dot($n)-n*n,r=e.radius*e.radius;if(s>r)return null;const o=Math.sqrt(r-s),a=n-o,c=n+o;return c<0?null:a<0?this.at(c,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,a,c;const l=1/this.direction.x,u=1/this.direction.y,h=1/this.direction.z,d=this.origin;return l>=0?(n=(e.min.x-d.x)*l,s=(e.max.x-d.x)*l):(n=(e.max.x-d.x)*l,s=(e.min.x-d.x)*l),u>=0?(r=(e.min.y-d.y)*u,o=(e.max.y-d.y)*u):(r=(e.max.y-d.y)*u,o=(e.min.y-d.y)*u),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),h>=0?(a=(e.min.z-d.z)*h,c=(e.max.z-d.z)*h):(a=(e.max.z-d.z)*h,c=(e.min.z-d.z)*h),n>c||a>s)||((a>n||n!==n)&&(n=a),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,$n)!==null}intersectTriangle(e,t,n,s,r){pa.subVectors(t,e),Wr.subVectors(n,e),ma.crossVectors(pa,Wr);let o=this.direction.dot(ma),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;pi.subVectors(this.origin,e);const c=a*this.direction.dot(Wr.crossVectors(pi,Wr));if(c<0)return null;const l=a*this.direction.dot(pa.cross(pi));if(l<0||c+l>o)return null;const u=-a*pi.dot(ma);return u<0?null:this.at(u/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class He{constructor(e,t,n,s,r,o,a,c,l,u,h,d,f,g,_,m){He.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,c,l,u,h,d,f,g,_,m)}set(e,t,n,s,r,o,a,c,l,u,h,d,f,g,_,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=a,p[13]=c,p[2]=l,p[6]=u,p[10]=h,p[14]=d,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new He().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,s=1/cs.setFromMatrixColumn(e,0).length(),r=1/cs.setFromMatrixColumn(e,1).length(),o=1/cs.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),a=Math.sin(n),c=Math.cos(s),l=Math.sin(s),u=Math.cos(r),h=Math.sin(r);if(e.order==="XYZ"){const d=o*u,f=o*h,g=a*u,_=a*h;t[0]=c*u,t[4]=-c*h,t[8]=l,t[1]=f+g*l,t[5]=d-_*l,t[9]=-a*c,t[2]=_-d*l,t[6]=g+f*l,t[10]=o*c}else if(e.order==="YXZ"){const d=c*u,f=c*h,g=l*u,_=l*h;t[0]=d+_*a,t[4]=g*a-f,t[8]=o*l,t[1]=o*h,t[5]=o*u,t[9]=-a,t[2]=f*a-g,t[6]=_+d*a,t[10]=o*c}else if(e.order==="ZXY"){const d=c*u,f=c*h,g=l*u,_=l*h;t[0]=d-_*a,t[4]=-o*h,t[8]=g+f*a,t[1]=f+g*a,t[5]=o*u,t[9]=_-d*a,t[2]=-o*l,t[6]=a,t[10]=o*c}else if(e.order==="ZYX"){const d=o*u,f=o*h,g=a*u,_=a*h;t[0]=c*u,t[4]=g*l-f,t[8]=d*l+_,t[1]=c*h,t[5]=_*l+d,t[9]=f*l-g,t[2]=-l,t[6]=a*c,t[10]=o*c}else if(e.order==="YZX"){const d=o*c,f=o*l,g=a*c,_=a*l;t[0]=c*u,t[4]=_-d*h,t[8]=g*h+f,t[1]=h,t[5]=o*u,t[9]=-a*u,t[2]=-l*u,t[6]=f*h+g,t[10]=d-_*h}else if(e.order==="XZY"){const d=o*c,f=o*l,g=a*c,_=a*l;t[0]=c*u,t[4]=-h,t[8]=l*u,t[1]=d*h+_,t[5]=o*u,t[9]=f*h-g,t[2]=g*h-f,t[6]=a*u,t[10]=_*h+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(cm,e,lm)}lookAt(e,t,n){const s=this.elements;return cn.subVectors(e,t),cn.lengthSq()===0&&(cn.z=1),cn.normalize(),mi.crossVectors(n,cn),mi.lengthSq()===0&&(Math.abs(n.z)===1?cn.x+=1e-4:cn.z+=1e-4,cn.normalize(),mi.crossVectors(n,cn)),mi.normalize(),Xr.crossVectors(cn,mi),s[0]=mi.x,s[4]=Xr.x,s[8]=cn.x,s[1]=mi.y,s[5]=Xr.y,s[9]=cn.y,s[2]=mi.z,s[6]=Xr.z,s[10]=cn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[4],c=n[8],l=n[12],u=n[1],h=n[5],d=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],M=n[3],v=n[7],x=n[11],I=n[15],A=s[0],T=s[4],P=s[8],b=s[12],w=s[1],D=s[5],z=s[9],O=s[13],Y=s[2],q=s[6],j=s[10],Q=s[14],W=s[3],le=s[7],pe=s[11],Me=s[15];return r[0]=o*A+a*w+c*Y+l*W,r[4]=o*T+a*D+c*q+l*le,r[8]=o*P+a*z+c*j+l*pe,r[12]=o*b+a*O+c*Q+l*Me,r[1]=u*A+h*w+d*Y+f*W,r[5]=u*T+h*D+d*q+f*le,r[9]=u*P+h*z+d*j+f*pe,r[13]=u*b+h*O+d*Q+f*Me,r[2]=g*A+_*w+m*Y+p*W,r[6]=g*T+_*D+m*q+p*le,r[10]=g*P+_*z+m*j+p*pe,r[14]=g*b+_*O+m*Q+p*Me,r[3]=M*A+v*w+x*Y+I*W,r[7]=M*T+v*D+x*q+I*le,r[11]=M*P+v*z+x*j+I*pe,r[15]=M*b+v*O+x*Q+I*Me,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],a=e[5],c=e[9],l=e[13],u=e[2],h=e[6],d=e[10],f=e[14],g=e[3],_=e[7],m=e[11],p=e[15];return g*(+r*c*h-s*l*h-r*a*d+n*l*d+s*a*f-n*c*f)+_*(+t*c*f-t*l*d+r*o*d-s*o*f+s*l*u-r*c*u)+m*(+t*l*h-t*a*f-r*o*h+n*o*f+r*a*u-n*l*u)+p*(-s*a*u-t*c*h+t*a*d+s*o*h-n*o*d+n*c*u)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],h=e[9],d=e[10],f=e[11],g=e[12],_=e[13],m=e[14],p=e[15],M=h*m*l-_*d*l+_*c*f-a*m*f-h*c*p+a*d*p,v=g*d*l-u*m*l-g*c*f+o*m*f+u*c*p-o*d*p,x=u*_*l-g*h*l+g*a*f-o*_*f-u*a*p+o*h*p,I=g*h*c-u*_*c-g*a*d+o*_*d+u*a*m-o*h*m,A=t*M+n*v+s*x+r*I;if(A===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const T=1/A;return e[0]=M*T,e[1]=(_*d*r-h*m*r-_*s*f+n*m*f+h*s*p-n*d*p)*T,e[2]=(a*m*r-_*c*r+_*s*l-n*m*l-a*s*p+n*c*p)*T,e[3]=(h*c*r-a*d*r-h*s*l+n*d*l+a*s*f-n*c*f)*T,e[4]=v*T,e[5]=(u*m*r-g*d*r+g*s*f-t*m*f-u*s*p+t*d*p)*T,e[6]=(g*c*r-o*m*r-g*s*l+t*m*l+o*s*p-t*c*p)*T,e[7]=(o*d*r-u*c*r+u*s*l-t*d*l-o*s*f+t*c*f)*T,e[8]=x*T,e[9]=(g*h*r-u*_*r-g*n*f+t*_*f+u*n*p-t*h*p)*T,e[10]=(o*_*r-g*a*r+g*n*l-t*_*l-o*n*p+t*a*p)*T,e[11]=(u*a*r-o*h*r-u*n*l+t*h*l+o*n*f-t*a*f)*T,e[12]=I*T,e[13]=(u*_*s-g*h*s+g*n*d-t*_*d-u*n*m+t*h*m)*T,e[14]=(g*a*s-o*_*s-g*n*c+t*_*c+o*n*m-t*a*m)*T,e[15]=(o*h*s-u*a*s+u*n*c-t*h*c-o*n*d+t*a*d)*T,this}scale(e){const t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,a=e.y,c=e.z,l=r*o,u=r*a;return this.set(l*o+n,l*a-s*c,l*c+s*a,0,l*a+s*c,u*a+n,u*c-s*o,0,l*c-s*a,u*c+s*o,r*c*c+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,r=t._x,o=t._y,a=t._z,c=t._w,l=r+r,u=o+o,h=a+a,d=r*l,f=r*u,g=r*h,_=o*u,m=o*h,p=a*h,M=c*l,v=c*u,x=c*h,I=n.x,A=n.y,T=n.z;return s[0]=(1-(_+p))*I,s[1]=(f+x)*I,s[2]=(g-v)*I,s[3]=0,s[4]=(f-x)*A,s[5]=(1-(d+p))*A,s[6]=(m+M)*A,s[7]=0,s[8]=(g+v)*T,s[9]=(m-M)*T,s[10]=(1-(d+_))*T,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;let r=cs.set(s[0],s[1],s[2]).length();const o=cs.set(s[4],s[5],s[6]).length(),a=cs.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],Rn.copy(this);const l=1/r,u=1/o,h=1/a;return Rn.elements[0]*=l,Rn.elements[1]*=l,Rn.elements[2]*=l,Rn.elements[4]*=u,Rn.elements[5]*=u,Rn.elements[6]*=u,Rn.elements[8]*=h,Rn.elements[9]*=h,Rn.elements[10]*=h,t.setFromRotationMatrix(Rn),n.x=r,n.y=o,n.z=a,this}makePerspective(e,t,n,s,r,o,a=ni){const c=this.elements,l=2*r/(t-e),u=2*r/(n-s),h=(t+e)/(t-e),d=(n+s)/(n-s);let f,g;if(a===ni)f=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===Uo)f=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=l,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=u,c[9]=d,c[13]=0,c[2]=0,c[6]=0,c[10]=f,c[14]=g,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,s,r,o,a=ni){const c=this.elements,l=1/(t-e),u=1/(n-s),h=1/(o-r),d=(t+e)*l,f=(n+s)*u;let g,_;if(a===ni)g=(o+r)*h,_=-2*h;else if(a===Uo)g=r*h,_=-1*h;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-d,c[1]=0,c[5]=2*u,c[9]=0,c[13]=-f,c[2]=0,c[6]=0,c[10]=_,c[14]=-g,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const cs=new R,Rn=new He,cm=new R(0,0,0),lm=new R(1,1,1),mi=new R,Xr=new R,cn=new R,xu=new He,vu=new Un;class fn{constructor(e=0,t=0,n=0,s=fn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,r=s[0],o=s[4],a=s[8],c=s[1],l=s[5],u=s[9],h=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(It(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,l),this._z=0);break;case"YXZ":this._x=Math.asin(-It(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-h,r),this._z=0);break;case"ZXY":this._x=Math.asin(It(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-h,f),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-It(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(It(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,l),this._y=Math.atan2(-h,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-It(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,l),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-u,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return xu.makeRotationFromQuaternion(e),this.setFromRotationMatrix(xu,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return vu.setFromEuler(this),this.setFromQuaternion(vu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}fn.DEFAULT_ORDER="XYZ";class Ad{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let um=0;const yu=new R,ls=new Un,Yn=new He,qr=new R,tr=new R,hm=new R,dm=new Un,Mu=new R(1,0,0),Su=new R(0,1,0),wu=new R(0,0,1),bu={type:"added"},fm={type:"removed"},us={type:"childadded",child:null},ga={type:"childremoved",child:null};class St extends Vs{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:um++}),this.uuid=wn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=St.DEFAULT_UP.clone();const e=new R,t=new fn,n=new Un,s=new R(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new He},normalMatrix:{value:new Ke}}),this.matrix=new He,this.matrixWorld=new He,this.matrixAutoUpdate=St.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=St.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ad,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ls.setFromAxisAngle(e,t),this.quaternion.multiply(ls),this}rotateOnWorldAxis(e,t){return ls.setFromAxisAngle(e,t),this.quaternion.premultiply(ls),this}rotateX(e){return this.rotateOnAxis(Mu,e)}rotateY(e){return this.rotateOnAxis(Su,e)}rotateZ(e){return this.rotateOnAxis(wu,e)}translateOnAxis(e,t){return yu.copy(e).applyQuaternion(this.quaternion),this.position.add(yu.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Mu,e)}translateY(e){return this.translateOnAxis(Su,e)}translateZ(e){return this.translateOnAxis(wu,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Yn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?qr.copy(e):qr.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),tr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Yn.lookAt(tr,qr,this.up):Yn.lookAt(qr,tr,this.up),this.quaternion.setFromRotationMatrix(Yn),s&&(Yn.extractRotation(s.matrixWorld),ls.setFromRotationMatrix(Yn),this.quaternion.premultiply(ls.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(bu),us.child=e,this.dispatchEvent(us),us.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(fm),ga.child=e,this.dispatchEvent(ga),ga.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Yn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Yn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Yn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(bu),us.child=e,this.dispatchEvent(us),us.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(tr,e,hm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(tr,dm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,u=c.length;l<u;l++){const h=c[l];r(e.shapes,h)}else r(e.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(r(e.materials,this.material[c]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];s.animations.push(r(e.animations,c))}}if(t){const a=o(e.geometries),c=o(e.materials),l=o(e.textures),u=o(e.images),h=o(e.shapes),d=o(e.skeletons),f=o(e.animations),g=o(e.nodes);a.length>0&&(n.geometries=a),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),u.length>0&&(n.images=u),h.length>0&&(n.shapes=h),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){const c=[];for(const l in a){const u=a[l];delete u.metadata,c.push(u)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}}St.DEFAULT_UP=new R(0,1,0);St.DEFAULT_MATRIX_AUTO_UPDATE=!0;St.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Cn=new R,jn=new R,_a=new R,Kn=new R,hs=new R,ds=new R,Eu=new R,xa=new R,va=new R,ya=new R,Ma=new at,Sa=new at,wa=new at;class yn{constructor(e=new R,t=new R,n=new R){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),Cn.subVectors(e,t),s.cross(Cn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){Cn.subVectors(s,t),jn.subVectors(n,t),_a.subVectors(e,t);const o=Cn.dot(Cn),a=Cn.dot(jn),c=Cn.dot(_a),l=jn.dot(jn),u=jn.dot(_a),h=o*l-a*a;if(h===0)return r.set(0,0,0),null;const d=1/h,f=(l*c-a*u)*d,g=(o*u-a*c)*d;return r.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,Kn)===null?!1:Kn.x>=0&&Kn.y>=0&&Kn.x+Kn.y<=1}static getInterpolation(e,t,n,s,r,o,a,c){return this.getBarycoord(e,t,n,s,Kn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,Kn.x),c.addScaledVector(o,Kn.y),c.addScaledVector(a,Kn.z),c)}static getInterpolatedAttribute(e,t,n,s,r,o){return Ma.setScalar(0),Sa.setScalar(0),wa.setScalar(0),Ma.fromBufferAttribute(e,t),Sa.fromBufferAttribute(e,n),wa.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(Ma,r.x),o.addScaledVector(Sa,r.y),o.addScaledVector(wa,r.z),o}static isFrontFacing(e,t,n,s){return Cn.subVectors(n,t),jn.subVectors(e,t),Cn.cross(jn).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Cn.subVectors(this.c,this.b),jn.subVectors(this.a,this.b),Cn.cross(jn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return yn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return yn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return yn.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return yn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return yn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,r=this.c;let o,a;hs.subVectors(s,n),ds.subVectors(r,n),xa.subVectors(e,n);const c=hs.dot(xa),l=ds.dot(xa);if(c<=0&&l<=0)return t.copy(n);va.subVectors(e,s);const u=hs.dot(va),h=ds.dot(va);if(u>=0&&h<=u)return t.copy(s);const d=c*h-u*l;if(d<=0&&c>=0&&u<=0)return o=c/(c-u),t.copy(n).addScaledVector(hs,o);ya.subVectors(e,r);const f=hs.dot(ya),g=ds.dot(ya);if(g>=0&&f<=g)return t.copy(r);const _=f*l-c*g;if(_<=0&&l>=0&&g<=0)return a=l/(l-g),t.copy(n).addScaledVector(ds,a);const m=u*g-f*h;if(m<=0&&h-u>=0&&f-g>=0)return Eu.subVectors(r,s),a=(h-u)/(h-u+(f-g)),t.copy(s).addScaledVector(Eu,a);const p=1/(m+_+d);return o=_*p,a=d*p,t.copy(n).addScaledVector(hs,o).addScaledVector(ds,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Rd={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},gi={h:0,s:0,l:0},$r={h:0,s:0,l:0};function ba(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Fe{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Lt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,st.toWorkingColorSpace(this,t),this}setRGB(e,t,n,s=st.workingColorSpace){return this.r=e,this.g=t,this.b=n,st.toWorkingColorSpace(this,s),this}setHSL(e,t,n,s=st.workingColorSpace){if(e=ml(e,1),t=It(t,0,1),n=It(n,0,1),t===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=ba(o,r,e+1/3),this.g=ba(o,r,e),this.b=ba(o,r,e-1/3)}return st.toWorkingColorSpace(this,s),this}setStyle(e,t=Lt){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Lt){const n=Rd[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=ii(e.r),this.g=ii(e.g),this.b=ii(e.b),this}copyLinearToSRGB(e){return this.r=Es(e.r),this.g=Es(e.g),this.b=Es(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Lt){return st.fromWorkingColorSpace(Xt.copy(this),e),Math.round(It(Xt.r*255,0,255))*65536+Math.round(It(Xt.g*255,0,255))*256+Math.round(It(Xt.b*255,0,255))}getHexString(e=Lt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=st.workingColorSpace){st.fromWorkingColorSpace(Xt.copy(this),t);const n=Xt.r,s=Xt.g,r=Xt.b,o=Math.max(n,s,r),a=Math.min(n,s,r);let c,l;const u=(a+o)/2;if(a===o)c=0,l=0;else{const h=o-a;switch(l=u<=.5?h/(o+a):h/(2-o-a),o){case n:c=(s-r)/h+(s<r?6:0);break;case s:c=(r-n)/h+2;break;case r:c=(n-s)/h+4;break}c/=6}return e.h=c,e.s=l,e.l=u,e}getRGB(e,t=st.workingColorSpace){return st.fromWorkingColorSpace(Xt.copy(this),t),e.r=Xt.r,e.g=Xt.g,e.b=Xt.b,e}getStyle(e=Lt){st.fromWorkingColorSpace(Xt.copy(this),e);const t=Xt.r,n=Xt.g,s=Xt.b;return e!==Lt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(gi),this.setHSL(gi.h+e,gi.s+t,gi.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(gi),e.getHSL($r);const n=gr(gi.h,$r.h,t),s=gr(gi.s,$r.s,t),r=gr(gi.l,$r.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Xt=new Fe;Fe.NAMES=Rd;let pm=0;class bn extends Vs{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:pm++}),this.uuid=wn(),this.name="",this.blending=$i,this.side=si,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Qa,this.blendDst=ec,this.blendEquation=Wi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Fe(0,0,0),this.blendAlpha=0,this.depthFunc=Ps,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=cu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=is,this.stencilZFail=is,this.stencilZPass=is,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==$i&&(n.blending=this.blending),this.side!==si&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Qa&&(n.blendSrc=this.blendSrc),this.blendDst!==ec&&(n.blendDst=this.blendDst),this.blendEquation!==Wi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Ps&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==cu&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==is&&(n.stencilFail=this.stencilFail),this.stencilZFail!==is&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==is&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const o=[];for(const a in r){const c=r[a];delete c.metadata,o.push(c)}return o}if(t){const r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class Dt extends bn{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new Fe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new fn,this.combine=ol,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Ct=new R,Yr=new se;class jt{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Fc,this.updateRanges=[],this.gpuType=Dn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Yr.fromBufferAttribute(this,t),Yr.applyMatrix3(e),this.setXY(t,Yr.x,Yr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.applyMatrix3(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.applyMatrix4(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.applyNormalMatrix(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.transformDirection(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=In(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ht(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=In(t,this.array)),t}setX(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=In(t,this.array)),t}setY(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=In(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=In(t,this.array)),t}setW(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=ht(t,this.array),n=ht(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=ht(t,this.array),n=ht(n,this.array),s=ht(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=ht(t,this.array),n=ht(n,this.array),s=ht(s,this.array),r=ht(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Fc&&(e.usage=this.usage),e}}class Cd extends jt{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Pd extends jt{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class Ze extends jt{constructor(e,t,n){super(new Float32Array(e),t,n)}}let mm=0;const mn=new He,Ea=new St,fs=new R,ln=new Bn,nr=new Bn,Ft=new R;class Tt extends Vs{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:mm++}),this.uuid=wn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(bd(e)?Pd:Cd)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Ke().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return mn.makeRotationFromQuaternion(e),this.applyMatrix4(mn),this}rotateX(e){return mn.makeRotationX(e),this.applyMatrix4(mn),this}rotateY(e){return mn.makeRotationY(e),this.applyMatrix4(mn),this}rotateZ(e){return mn.makeRotationZ(e),this.applyMatrix4(mn),this}translate(e,t,n){return mn.makeTranslation(e,t,n),this.applyMatrix4(mn),this}scale(e,t,n){return mn.makeScale(e,t,n),this.applyMatrix4(mn),this}lookAt(e){return Ea.lookAt(e),Ea.updateMatrix(),this.applyMatrix4(Ea.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(fs).negate(),this.translate(fs.x,fs.y,fs.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,r=e.length;s<r;s++){const o=e[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Ze(n,3))}else{for(let n=0,s=t.count;n<s;n++){const r=e[n];t.setXYZ(n,r.x,r.y,r.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Bn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const r=t[n];ln.setFromBufferAttribute(r),this.morphTargetsRelative?(Ft.addVectors(this.boundingBox.min,ln.min),this.boundingBox.expandByPoint(Ft),Ft.addVectors(this.boundingBox.max,ln.max),this.boundingBox.expandByPoint(Ft)):(this.boundingBox.expandByPoint(ln.min),this.boundingBox.expandByPoint(ln.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new zn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new R,1/0);return}if(e){const n=this.boundingSphere.center;if(ln.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){const a=t[r];nr.setFromBufferAttribute(a),this.morphTargetsRelative?(Ft.addVectors(ln.min,nr.min),ln.expandByPoint(Ft),Ft.addVectors(ln.max,nr.max),ln.expandByPoint(Ft)):(ln.expandByPoint(nr.min),ln.expandByPoint(nr.max))}ln.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)Ft.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(Ft));if(t)for(let r=0,o=t.length;r<o;r++){const a=t[r],c=this.morphTargetsRelative;for(let l=0,u=a.count;l<u;l++)Ft.fromBufferAttribute(a,l),c&&(fs.fromBufferAttribute(e,l),Ft.add(fs)),s=Math.max(s,n.distanceToSquared(Ft))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new jt(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],c=[];for(let P=0;P<n.count;P++)a[P]=new R,c[P]=new R;const l=new R,u=new R,h=new R,d=new se,f=new se,g=new se,_=new R,m=new R;function p(P,b,w){l.fromBufferAttribute(n,P),u.fromBufferAttribute(n,b),h.fromBufferAttribute(n,w),d.fromBufferAttribute(r,P),f.fromBufferAttribute(r,b),g.fromBufferAttribute(r,w),u.sub(l),h.sub(l),f.sub(d),g.sub(d);const D=1/(f.x*g.y-g.x*f.y);isFinite(D)&&(_.copy(u).multiplyScalar(g.y).addScaledVector(h,-f.y).multiplyScalar(D),m.copy(h).multiplyScalar(f.x).addScaledVector(u,-g.x).multiplyScalar(D),a[P].add(_),a[b].add(_),a[w].add(_),c[P].add(m),c[b].add(m),c[w].add(m))}let M=this.groups;M.length===0&&(M=[{start:0,count:e.count}]);for(let P=0,b=M.length;P<b;++P){const w=M[P],D=w.start,z=w.count;for(let O=D,Y=D+z;O<Y;O+=3)p(e.getX(O+0),e.getX(O+1),e.getX(O+2))}const v=new R,x=new R,I=new R,A=new R;function T(P){I.fromBufferAttribute(s,P),A.copy(I);const b=a[P];v.copy(b),v.sub(I.multiplyScalar(I.dot(b))).normalize(),x.crossVectors(A,b);const D=x.dot(c[P])<0?-1:1;o.setXYZW(P,v.x,v.y,v.z,D)}for(let P=0,b=M.length;P<b;++P){const w=M[P],D=w.start,z=w.count;for(let O=D,Y=D+z;O<Y;O+=3)T(e.getX(O+0)),T(e.getX(O+1)),T(e.getX(O+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new jt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const s=new R,r=new R,o=new R,a=new R,c=new R,l=new R,u=new R,h=new R;if(e)for(let d=0,f=e.count;d<f;d+=3){const g=e.getX(d+0),_=e.getX(d+1),m=e.getX(d+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,_),o.fromBufferAttribute(t,m),u.subVectors(o,r),h.subVectors(s,r),u.cross(h),a.fromBufferAttribute(n,g),c.fromBufferAttribute(n,_),l.fromBufferAttribute(n,m),a.add(u),c.add(u),l.add(u),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(_,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),u.subVectors(o,r),h.subVectors(s,r),u.cross(h),n.setXYZ(d+0,u.x,u.y,u.z),n.setXYZ(d+1,u.x,u.y,u.z),n.setXYZ(d+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Ft.fromBufferAttribute(e,t),Ft.normalize(),e.setXYZ(t,Ft.x,Ft.y,Ft.z)}toNonIndexed(){function e(a,c){const l=a.array,u=a.itemSize,h=a.normalized,d=new l.constructor(c.length*u);let f=0,g=0;for(let _=0,m=c.length;_<m;_++){a.isInterleavedBufferAttribute?f=c[_]*a.data.stride+a.offset:f=c[_]*u;for(let p=0;p<u;p++)d[g++]=l[f++]}return new jt(d,u,h)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Tt,n=this.index.array,s=this.attributes;for(const a in s){const c=s[a],l=e(c,n);t.setAttribute(a,l)}const r=this.morphAttributes;for(const a in r){const c=[],l=r[a];for(let u=0,h=l.length;u<h;u++){const d=l[u],f=e(d,n);c.push(f)}t.morphAttributes[a]=c}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,c=o.length;a<c;a++){const l=o[a];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const c in n){const l=n[c];e.data.attributes[c]=l.toJSON(e.data)}const s={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],u=[];for(let h=0,d=l.length;h<d;h++){const f=l[h];u.push(f.toJSON(e.data))}u.length>0&&(s[c]=u,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone(t));const s=e.attributes;for(const l in s){const u=s[l];this.setAttribute(l,u.clone(t))}const r=e.morphAttributes;for(const l in r){const u=[],h=r[l];for(let d=0,f=h.length;d<f;d++)u.push(h[d].clone(t));this.morphAttributes[l]=u}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let l=0,u=o.length;l<u;l++){const h=o[l];this.addGroup(h.start,h.count,h.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Tu=new He,Ui=new $o,jr=new zn,Au=new R,Kr=new R,Zr=new R,Jr=new R,Ta=new R,Qr=new R,Ru=new R,eo=new R;class G extends St{constructor(e=new Tt,t=new Dt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const a=this.morphTargetInfluences;if(r&&a){Qr.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const u=a[c],h=r[c];u!==0&&(Ta.fromBufferAttribute(h,e),o?Qr.addScaledVector(Ta,u):Qr.addScaledVector(Ta.sub(t),u))}t.add(Qr)}return t}raycast(e,t){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),jr.copy(n.boundingSphere),jr.applyMatrix4(r),Ui.copy(e.ray).recast(e.near),!(jr.containsPoint(Ui.origin)===!1&&(Ui.intersectSphere(jr,Au)===null||Ui.origin.distanceToSquared(Au)>(e.far-e.near)**2))&&(Tu.copy(r).invert(),Ui.copy(e.ray).applyMatrix4(Tu),!(n.boundingBox!==null&&Ui.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Ui)))}_computeIntersections(e,t,n){let s;const r=this.geometry,o=this.material,a=r.index,c=r.attributes.position,l=r.attributes.uv,u=r.attributes.uv1,h=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){const m=d[g],p=o[m.materialIndex],M=Math.max(m.start,f.start),v=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let x=M,I=v;x<I;x+=3){const A=a.getX(x),T=a.getX(x+1),P=a.getX(x+2);s=to(this,p,e,n,l,u,h,A,T,P),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),_=Math.min(a.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const M=a.getX(m),v=a.getX(m+1),x=a.getX(m+2);s=to(this,o,e,n,l,u,h,M,v,x),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(c!==void 0)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){const m=d[g],p=o[m.materialIndex],M=Math.max(m.start,f.start),v=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let x=M,I=v;x<I;x+=3){const A=x,T=x+1,P=x+2;s=to(this,p,e,n,l,u,h,A,T,P),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),_=Math.min(c.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const M=m,v=m+1,x=m+2;s=to(this,o,e,n,l,u,h,M,v,x),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function gm(i,e,t,n,s,r,o,a){let c;if(e.side===on?c=n.intersectTriangle(o,r,s,!0,a):c=n.intersectTriangle(s,r,o,e.side===si,a),c===null)return null;eo.copy(a),eo.applyMatrix4(i.matrixWorld);const l=t.ray.origin.distanceTo(eo);return l<t.near||l>t.far?null:{distance:l,point:eo.clone(),object:i}}function to(i,e,t,n,s,r,o,a,c,l){i.getVertexPosition(a,Kr),i.getVertexPosition(c,Zr),i.getVertexPosition(l,Jr);const u=gm(i,e,t,n,Kr,Zr,Jr,Ru);if(u){const h=new R;yn.getBarycoord(Ru,Kr,Zr,Jr,h),s&&(u.uv=yn.getInterpolatedAttribute(s,a,c,l,h,new se)),r&&(u.uv1=yn.getInterpolatedAttribute(r,a,c,l,h,new se)),o&&(u.normal=yn.getInterpolatedAttribute(o,a,c,l,h,new R),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));const d={a,b:c,c:l,normal:new R,materialIndex:0};yn.getNormal(Kr,Zr,Jr,d.normal),u.face=d,u.barycoord=h}return u}class li extends Tt{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};const a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const c=[],l=[],u=[],h=[];let d=0,f=0;g("z","y","x",-1,-1,n,t,e,o,r,0),g("z","y","x",1,-1,n,t,-e,o,r,1),g("x","z","y",1,1,e,n,t,s,o,2),g("x","z","y",1,-1,e,n,-t,s,o,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(c),this.setAttribute("position",new Ze(l,3)),this.setAttribute("normal",new Ze(u,3)),this.setAttribute("uv",new Ze(h,2));function g(_,m,p,M,v,x,I,A,T,P,b){const w=x/T,D=I/P,z=x/2,O=I/2,Y=A/2,q=T+1,j=P+1;let Q=0,W=0;const le=new R;for(let pe=0;pe<j;pe++){const Me=pe*D-O;for(let Le=0;Le<q;Le++){const qe=Le*w-z;le[_]=qe*M,le[m]=Me*v,le[p]=Y,l.push(le.x,le.y,le.z),le[_]=0,le[m]=0,le[p]=A>0?1:-1,u.push(le.x,le.y,le.z),h.push(Le/T),h.push(1-pe/P),Q+=1}}for(let pe=0;pe<P;pe++)for(let Me=0;Me<T;Me++){const Le=d+Me+q*pe,qe=d+Me+q*(pe+1),J=d+(Me+1)+q*(pe+1),ae=d+(Me+1)+q*pe;c.push(Le,qe,ae),c.push(qe,J,ae),W+=6}a.addGroup(f,W,b),f+=W,d+=Q}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new li(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function ks(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function Zt(i){const e={};for(let t=0;t<i.length;t++){const n=ks(i[t]);for(const s in n)e[s]=n[s]}return e}function _m(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function Ld(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:st.workingColorSpace}const xm={clone:ks,merge:Zt};var vm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,ym=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class oi extends bn{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=vm,this.fragmentShader=ym,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ks(e.uniforms),this.uniformsGroups=_m(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Id extends St{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new He,this.projectionMatrix=new He,this.projectionMatrixInverse=new He,this.coordinateSystem=ni}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const _i=new R,Cu=new se,Pu=new se;class Qt extends Id{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Us*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(mr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Us*2*Math.atan(Math.tan(mr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){_i.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(_i.x,_i.y).multiplyScalar(-e/_i.z),_i.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(_i.x,_i.y).multiplyScalar(-e/_i.z)}getViewSize(e,t){return this.getViewBounds(e,Cu,Pu),t.subVectors(Pu,Cu)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(mr*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,l=o.fullHeight;r+=o.offsetX*s/c,t-=o.offsetY*n/l,s*=o.width/c,n*=o.height/l}const a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const ps=-90,ms=1;class Mm extends St{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Qt(ps,ms,e,t);s.layers=this.layers,this.add(s);const r=new Qt(ps,ms,e,t);r.layers=this.layers,this.add(r);const o=new Qt(ps,ms,e,t);o.layers=this.layers,this.add(o);const a=new Qt(ps,ms,e,t);a.layers=this.layers,this.add(a);const c=new Qt(ps,ms,e,t);c.layers=this.layers,this.add(c);const l=new Qt(ps,ms,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,a,c]=t;for(const l of t)this.remove(l);if(e===ni)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===Uo)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,c,l,u]=this.children,h=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,o),e.setRenderTarget(n,2,s),e.render(t,a),e.setRenderTarget(n,3,s),e.render(t,c),e.setRenderTarget(n,4,s),e.render(t,l),n.texture.generateMipmaps=_,e.setRenderTarget(n,5,s),e.render(t,u),e.setRenderTarget(h,d,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Dd extends Nt{constructor(e,t,n,s,r,o,a,c,l,u){e=e!==void 0?e:[],t=t!==void 0?t:Ls,super(e,t,n,s,r,o,a,c,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Sm extends Ki{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new Dd(s,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:hn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new li(5,5,5),r=new oi({name:"CubemapFromEquirect",uniforms:ks(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:on,blending:bi});r.uniforms.tEquirect.value=t;const o=new G(s,r),a=t.minFilter;return t.minFilter===ti&&(t.minFilter=hn),new Mm(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,s){const r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}}const Aa=new R,wm=new R,bm=new Ke;class Vi{constructor(e=new R(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=Aa.subVectors(n,t).cross(wm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(Aa),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||bm.getNormalMatrix(e),s=this.coplanarPoint(Aa).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ki=new zn,no=new R;class _l{constructor(e=new Vi,t=new Vi,n=new Vi,s=new Vi,r=new Vi,o=new Vi){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ni){const n=this.planes,s=e.elements,r=s[0],o=s[1],a=s[2],c=s[3],l=s[4],u=s[5],h=s[6],d=s[7],f=s[8],g=s[9],_=s[10],m=s[11],p=s[12],M=s[13],v=s[14],x=s[15];if(n[0].setComponents(c-r,d-l,m-f,x-p).normalize(),n[1].setComponents(c+r,d+l,m+f,x+p).normalize(),n[2].setComponents(c+o,d+u,m+g,x+M).normalize(),n[3].setComponents(c-o,d-u,m-g,x-M).normalize(),n[4].setComponents(c-a,d-h,m-_,x-v).normalize(),t===ni)n[5].setComponents(c+a,d+h,m+_,x+v).normalize();else if(t===Uo)n[5].setComponents(a,h,_,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ki.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ki.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ki)}intersectsSprite(e){return ki.center.set(0,0,0),ki.radius=.7071067811865476,ki.applyMatrix4(e.matrixWorld),this.intersectsSphere(ki)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(no.x=s.normal.x>0?e.max.x:e.min.x,no.y=s.normal.y>0?e.max.y:e.min.y,no.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(no)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Nd(){let i=null,e=!1,t=null,n=null;function s(r,o){t(r,o),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function Em(i){const e=new WeakMap;function t(a,c){const l=a.array,u=a.usage,h=l.byteLength,d=i.createBuffer();i.bindBuffer(c,d),i.bufferData(c,l,u),a.onUploadCallback();let f;if(l instanceof Float32Array)f=i.FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(l instanceof Int16Array)f=i.SHORT;else if(l instanceof Uint32Array)f=i.UNSIGNED_INT;else if(l instanceof Int32Array)f=i.INT;else if(l instanceof Int8Array)f=i.BYTE;else if(l instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:d,type:f,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:h}}function n(a,c,l){const u=c.array,h=c.updateRanges;if(i.bindBuffer(l,a),h.length===0)i.bufferSubData(l,0,u);else{h.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<h.length;f++){const g=h[d],_=h[f];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++d,h[d]=_)}h.length=d+1;for(let f=0,g=h.length;f<g;f++){const _=h[f];i.bufferSubData(l,_.start*u.BYTES_PER_ELEMENT,u,_.start,_.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=e.get(a);c&&(i.deleteBuffer(c.buffer),e.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const u=e.get(a);(!u||u.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=e.get(a);if(l===void 0)e.set(a,t(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,a,c),l.version=a.version}}return{get:s,remove:r,update:o}}class kn extends Tt{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const r=e/2,o=t/2,a=Math.floor(n),c=Math.floor(s),l=a+1,u=c+1,h=e/a,d=t/c,f=[],g=[],_=[],m=[];for(let p=0;p<u;p++){const M=p*d-o;for(let v=0;v<l;v++){const x=v*h-r;g.push(x,-M,0),_.push(0,0,1),m.push(v/a),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let M=0;M<a;M++){const v=M+l*p,x=M+l*(p+1),I=M+1+l*(p+1),A=M+1+l*p;f.push(v,x,A),f.push(x,I,A)}this.setIndex(f),this.setAttribute("position",new Ze(g,3)),this.setAttribute("normal",new Ze(_,3)),this.setAttribute("uv",new Ze(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new kn(e.width,e.height,e.widthSegments,e.heightSegments)}}var Tm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Am=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Rm=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Cm=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Pm=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Lm=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Im=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Dm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Nm=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Um=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,km=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Fm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Om=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Bm=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,zm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Hm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Vm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Gm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Wm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Xm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,qm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,$m=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Ym=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,jm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Km=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Zm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Jm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Qm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,e0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,t0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,n0="gl_FragColor = linearToOutputTexel( gl_FragColor );",i0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,s0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,r0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,o0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,a0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,c0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,l0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,u0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,h0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,d0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,f0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,p0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,m0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,g0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,_0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,x0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,v0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,y0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,M0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,S0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,w0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,b0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,E0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,T0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,A0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,R0=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,C0=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,P0=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,L0=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,I0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,D0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,N0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,U0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,k0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,F0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,O0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,B0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,z0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,H0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,V0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,G0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,W0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,X0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,q0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,$0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Y0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,j0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,K0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Z0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,J0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Q0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,eg=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,tg=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,ng=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,ig=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,sg=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,rg=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,og=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,ag=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,cg=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,lg=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,ug=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,hg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,dg=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,fg=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,pg=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,mg=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,gg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,_g=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,xg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,vg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,yg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Mg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Sg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,wg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,bg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Eg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Tg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ag=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Rg=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Cg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Pg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Lg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Ig=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Dg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Ng=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Ug=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,kg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Fg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Og=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Bg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,zg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Vg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Wg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,qg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,$g=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Yg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Kg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Jg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,e_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,t_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,n_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,i_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,s_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,et={alphahash_fragment:Tm,alphahash_pars_fragment:Am,alphamap_fragment:Rm,alphamap_pars_fragment:Cm,alphatest_fragment:Pm,alphatest_pars_fragment:Lm,aomap_fragment:Im,aomap_pars_fragment:Dm,batching_pars_vertex:Nm,batching_vertex:Um,begin_vertex:km,beginnormal_vertex:Fm,bsdfs:Om,iridescence_fragment:Bm,bumpmap_pars_fragment:zm,clipping_planes_fragment:Hm,clipping_planes_pars_fragment:Vm,clipping_planes_pars_vertex:Gm,clipping_planes_vertex:Wm,color_fragment:Xm,color_pars_fragment:qm,color_pars_vertex:$m,color_vertex:Ym,common:jm,cube_uv_reflection_fragment:Km,defaultnormal_vertex:Zm,displacementmap_pars_vertex:Jm,displacementmap_vertex:Qm,emissivemap_fragment:e0,emissivemap_pars_fragment:t0,colorspace_fragment:n0,colorspace_pars_fragment:i0,envmap_fragment:s0,envmap_common_pars_fragment:r0,envmap_pars_fragment:o0,envmap_pars_vertex:a0,envmap_physical_pars_fragment:x0,envmap_vertex:c0,fog_vertex:l0,fog_pars_vertex:u0,fog_fragment:h0,fog_pars_fragment:d0,gradientmap_pars_fragment:f0,lightmap_pars_fragment:p0,lights_lambert_fragment:m0,lights_lambert_pars_fragment:g0,lights_pars_begin:_0,lights_toon_fragment:v0,lights_toon_pars_fragment:y0,lights_phong_fragment:M0,lights_phong_pars_fragment:S0,lights_physical_fragment:w0,lights_physical_pars_fragment:b0,lights_fragment_begin:E0,lights_fragment_maps:T0,lights_fragment_end:A0,logdepthbuf_fragment:R0,logdepthbuf_pars_fragment:C0,logdepthbuf_pars_vertex:P0,logdepthbuf_vertex:L0,map_fragment:I0,map_pars_fragment:D0,map_particle_fragment:N0,map_particle_pars_fragment:U0,metalnessmap_fragment:k0,metalnessmap_pars_fragment:F0,morphinstance_vertex:O0,morphcolor_vertex:B0,morphnormal_vertex:z0,morphtarget_pars_vertex:H0,morphtarget_vertex:V0,normal_fragment_begin:G0,normal_fragment_maps:W0,normal_pars_fragment:X0,normal_pars_vertex:q0,normal_vertex:$0,normalmap_pars_fragment:Y0,clearcoat_normal_fragment_begin:j0,clearcoat_normal_fragment_maps:K0,clearcoat_pars_fragment:Z0,iridescence_pars_fragment:J0,opaque_fragment:Q0,packing:eg,premultiplied_alpha_fragment:tg,project_vertex:ng,dithering_fragment:ig,dithering_pars_fragment:sg,roughnessmap_fragment:rg,roughnessmap_pars_fragment:og,shadowmap_pars_fragment:ag,shadowmap_pars_vertex:cg,shadowmap_vertex:lg,shadowmask_pars_fragment:ug,skinbase_vertex:hg,skinning_pars_vertex:dg,skinning_vertex:fg,skinnormal_vertex:pg,specularmap_fragment:mg,specularmap_pars_fragment:gg,tonemapping_fragment:_g,tonemapping_pars_fragment:xg,transmission_fragment:vg,transmission_pars_fragment:yg,uv_pars_fragment:Mg,uv_pars_vertex:Sg,uv_vertex:wg,worldpos_vertex:bg,background_vert:Eg,background_frag:Tg,backgroundCube_vert:Ag,backgroundCube_frag:Rg,cube_vert:Cg,cube_frag:Pg,depth_vert:Lg,depth_frag:Ig,distanceRGBA_vert:Dg,distanceRGBA_frag:Ng,equirect_vert:Ug,equirect_frag:kg,linedashed_vert:Fg,linedashed_frag:Og,meshbasic_vert:Bg,meshbasic_frag:zg,meshlambert_vert:Hg,meshlambert_frag:Vg,meshmatcap_vert:Gg,meshmatcap_frag:Wg,meshnormal_vert:Xg,meshnormal_frag:qg,meshphong_vert:$g,meshphong_frag:Yg,meshphysical_vert:jg,meshphysical_frag:Kg,meshtoon_vert:Zg,meshtoon_frag:Jg,points_vert:Qg,points_frag:e_,shadow_vert:t_,shadow_frag:n_,sprite_vert:i_,sprite_frag:s_},fe={common:{diffuse:{value:new Fe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ke},alphaMap:{value:null},alphaMapTransform:{value:new Ke},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ke}},envmap:{envMap:{value:null},envMapRotation:{value:new Ke},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ke}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ke}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ke},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ke},normalScale:{value:new se(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ke},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ke}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ke}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ke}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Fe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Fe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ke},alphaTest:{value:0},uvTransform:{value:new Ke}},sprite:{diffuse:{value:new Fe(16777215)},opacity:{value:1},center:{value:new se(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ke},alphaMap:{value:null},alphaMapTransform:{value:new Ke},alphaTest:{value:0}}},On={basic:{uniforms:Zt([fe.common,fe.specularmap,fe.envmap,fe.aomap,fe.lightmap,fe.fog]),vertexShader:et.meshbasic_vert,fragmentShader:et.meshbasic_frag},lambert:{uniforms:Zt([fe.common,fe.specularmap,fe.envmap,fe.aomap,fe.lightmap,fe.emissivemap,fe.bumpmap,fe.normalmap,fe.displacementmap,fe.fog,fe.lights,{emissive:{value:new Fe(0)}}]),vertexShader:et.meshlambert_vert,fragmentShader:et.meshlambert_frag},phong:{uniforms:Zt([fe.common,fe.specularmap,fe.envmap,fe.aomap,fe.lightmap,fe.emissivemap,fe.bumpmap,fe.normalmap,fe.displacementmap,fe.fog,fe.lights,{emissive:{value:new Fe(0)},specular:{value:new Fe(1118481)},shininess:{value:30}}]),vertexShader:et.meshphong_vert,fragmentShader:et.meshphong_frag},standard:{uniforms:Zt([fe.common,fe.envmap,fe.aomap,fe.lightmap,fe.emissivemap,fe.bumpmap,fe.normalmap,fe.displacementmap,fe.roughnessmap,fe.metalnessmap,fe.fog,fe.lights,{emissive:{value:new Fe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:et.meshphysical_vert,fragmentShader:et.meshphysical_frag},toon:{uniforms:Zt([fe.common,fe.aomap,fe.lightmap,fe.emissivemap,fe.bumpmap,fe.normalmap,fe.displacementmap,fe.gradientmap,fe.fog,fe.lights,{emissive:{value:new Fe(0)}}]),vertexShader:et.meshtoon_vert,fragmentShader:et.meshtoon_frag},matcap:{uniforms:Zt([fe.common,fe.bumpmap,fe.normalmap,fe.displacementmap,fe.fog,{matcap:{value:null}}]),vertexShader:et.meshmatcap_vert,fragmentShader:et.meshmatcap_frag},points:{uniforms:Zt([fe.points,fe.fog]),vertexShader:et.points_vert,fragmentShader:et.points_frag},dashed:{uniforms:Zt([fe.common,fe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:et.linedashed_vert,fragmentShader:et.linedashed_frag},depth:{uniforms:Zt([fe.common,fe.displacementmap]),vertexShader:et.depth_vert,fragmentShader:et.depth_frag},normal:{uniforms:Zt([fe.common,fe.bumpmap,fe.normalmap,fe.displacementmap,{opacity:{value:1}}]),vertexShader:et.meshnormal_vert,fragmentShader:et.meshnormal_frag},sprite:{uniforms:Zt([fe.sprite,fe.fog]),vertexShader:et.sprite_vert,fragmentShader:et.sprite_frag},background:{uniforms:{uvTransform:{value:new Ke},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:et.background_vert,fragmentShader:et.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ke}},vertexShader:et.backgroundCube_vert,fragmentShader:et.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:et.cube_vert,fragmentShader:et.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:et.equirect_vert,fragmentShader:et.equirect_frag},distanceRGBA:{uniforms:Zt([fe.common,fe.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:et.distanceRGBA_vert,fragmentShader:et.distanceRGBA_frag},shadow:{uniforms:Zt([fe.lights,fe.fog,{color:{value:new Fe(0)},opacity:{value:1}}]),vertexShader:et.shadow_vert,fragmentShader:et.shadow_frag}};On.physical={uniforms:Zt([On.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ke},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ke},clearcoatNormalScale:{value:new se(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ke},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ke},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ke},sheen:{value:0},sheenColor:{value:new Fe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ke},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ke},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ke},transmissionSamplerSize:{value:new se},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ke},attenuationDistance:{value:0},attenuationColor:{value:new Fe(0)},specularColor:{value:new Fe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ke},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ke},anisotropyVector:{value:new se},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ke}}]),vertexShader:et.meshphysical_vert,fragmentShader:et.meshphysical_frag};const io={r:0,b:0,g:0},Fi=new fn,r_=new He;function o_(i,e,t,n,s,r,o){const a=new Fe(0);let c=r===!0?0:1,l,u,h=null,d=0,f=null;function g(M){let v=M.isScene===!0?M.background:null;return v&&v.isTexture&&(v=(M.backgroundBlurriness>0?t:e).get(v)),v}function _(M){let v=!1;const x=g(M);x===null?p(a,c):x&&x.isColor&&(p(x,1),v=!0);const I=i.xr.getEnvironmentBlendMode();I==="additive"?n.buffers.color.setClear(0,0,0,1,o):I==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(M,v){const x=g(v);x&&(x.isCubeTexture||x.mapping===Xo)?(u===void 0&&(u=new G(new li(1,1,1),new oi({name:"BackgroundCubeMaterial",uniforms:ks(On.backgroundCube.uniforms),vertexShader:On.backgroundCube.vertexShader,fragmentShader:On.backgroundCube.fragmentShader,side:on,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(I,A,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),Fi.copy(v.backgroundRotation),Fi.x*=-1,Fi.y*=-1,Fi.z*=-1,x.isCubeTexture&&x.isRenderTargetTexture===!1&&(Fi.y*=-1,Fi.z*=-1),u.material.uniforms.envMap.value=x,u.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,u.material.uniforms.backgroundRotation.value.setFromMatrix4(r_.makeRotationFromEuler(Fi)),u.material.toneMapped=st.getTransfer(x.colorSpace)!==pt,(h!==x||d!==x.version||f!==i.toneMapping)&&(u.material.needsUpdate=!0,h=x,d=x.version,f=i.toneMapping),u.layers.enableAll(),M.unshift(u,u.geometry,u.material,0,0,null)):x&&x.isTexture&&(l===void 0&&(l=new G(new kn(2,2),new oi({name:"BackgroundMaterial",uniforms:ks(On.background.uniforms),vertexShader:On.background.vertexShader,fragmentShader:On.background.fragmentShader,side:si,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=x,l.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,l.material.toneMapped=st.getTransfer(x.colorSpace)!==pt,x.matrixAutoUpdate===!0&&x.updateMatrix(),l.material.uniforms.uvTransform.value.copy(x.matrix),(h!==x||d!==x.version||f!==i.toneMapping)&&(l.material.needsUpdate=!0,h=x,d=x.version,f=i.toneMapping),l.layers.enableAll(),M.unshift(l,l.geometry,l.material,0,0,null))}function p(M,v){M.getRGB(io,Ld(i)),n.buffers.color.setClear(io.r,io.g,io.b,v,o)}return{getClearColor:function(){return a},setClearColor:function(M,v=1){a.set(M),c=v,p(a,c)},getClearAlpha:function(){return c},setClearAlpha:function(M){c=M,p(a,c)},render:_,addToRenderList:m}}function a_(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null);let r=s,o=!1;function a(w,D,z,O,Y){let q=!1;const j=h(O,z,D);r!==j&&(r=j,l(r.object)),q=f(w,O,z,Y),q&&g(w,O,z,Y),Y!==null&&e.update(Y,i.ELEMENT_ARRAY_BUFFER),(q||o)&&(o=!1,x(w,D,z,O),Y!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(Y).buffer))}function c(){return i.createVertexArray()}function l(w){return i.bindVertexArray(w)}function u(w){return i.deleteVertexArray(w)}function h(w,D,z){const O=z.wireframe===!0;let Y=n[w.id];Y===void 0&&(Y={},n[w.id]=Y);let q=Y[D.id];q===void 0&&(q={},Y[D.id]=q);let j=q[O];return j===void 0&&(j=d(c()),q[O]=j),j}function d(w){const D=[],z=[],O=[];for(let Y=0;Y<t;Y++)D[Y]=0,z[Y]=0,O[Y]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:D,enabledAttributes:z,attributeDivisors:O,object:w,attributes:{},index:null}}function f(w,D,z,O){const Y=r.attributes,q=D.attributes;let j=0;const Q=z.getAttributes();for(const W in Q)if(Q[W].location>=0){const pe=Y[W];let Me=q[W];if(Me===void 0&&(W==="instanceMatrix"&&w.instanceMatrix&&(Me=w.instanceMatrix),W==="instanceColor"&&w.instanceColor&&(Me=w.instanceColor)),pe===void 0||pe.attribute!==Me||Me&&pe.data!==Me.data)return!0;j++}return r.attributesNum!==j||r.index!==O}function g(w,D,z,O){const Y={},q=D.attributes;let j=0;const Q=z.getAttributes();for(const W in Q)if(Q[W].location>=0){let pe=q[W];pe===void 0&&(W==="instanceMatrix"&&w.instanceMatrix&&(pe=w.instanceMatrix),W==="instanceColor"&&w.instanceColor&&(pe=w.instanceColor));const Me={};Me.attribute=pe,pe&&pe.data&&(Me.data=pe.data),Y[W]=Me,j++}r.attributes=Y,r.attributesNum=j,r.index=O}function _(){const w=r.newAttributes;for(let D=0,z=w.length;D<z;D++)w[D]=0}function m(w){p(w,0)}function p(w,D){const z=r.newAttributes,O=r.enabledAttributes,Y=r.attributeDivisors;z[w]=1,O[w]===0&&(i.enableVertexAttribArray(w),O[w]=1),Y[w]!==D&&(i.vertexAttribDivisor(w,D),Y[w]=D)}function M(){const w=r.newAttributes,D=r.enabledAttributes;for(let z=0,O=D.length;z<O;z++)D[z]!==w[z]&&(i.disableVertexAttribArray(z),D[z]=0)}function v(w,D,z,O,Y,q,j){j===!0?i.vertexAttribIPointer(w,D,z,Y,q):i.vertexAttribPointer(w,D,z,O,Y,q)}function x(w,D,z,O){_();const Y=O.attributes,q=z.getAttributes(),j=D.defaultAttributeValues;for(const Q in q){const W=q[Q];if(W.location>=0){let le=Y[Q];if(le===void 0&&(Q==="instanceMatrix"&&w.instanceMatrix&&(le=w.instanceMatrix),Q==="instanceColor"&&w.instanceColor&&(le=w.instanceColor)),le!==void 0){const pe=le.normalized,Me=le.itemSize,Le=e.get(le);if(Le===void 0)continue;const qe=Le.buffer,J=Le.type,ae=Le.bytesPerElement,we=J===i.INT||J===i.UNSIGNED_INT||le.gpuType===al;if(le.isInterleavedBufferAttribute){const X=le.data,he=X.stride,Ae=le.offset;if(X.isInstancedInterleavedBuffer){for(let Ie=0;Ie<W.locationSize;Ie++)p(W.location+Ie,X.meshPerAttribute);w.isInstancedMesh!==!0&&O._maxInstanceCount===void 0&&(O._maxInstanceCount=X.meshPerAttribute*X.count)}else for(let Ie=0;Ie<W.locationSize;Ie++)m(W.location+Ie);i.bindBuffer(i.ARRAY_BUFFER,qe);for(let Ie=0;Ie<W.locationSize;Ie++)v(W.location+Ie,Me/W.locationSize,J,pe,he*ae,(Ae+Me/W.locationSize*Ie)*ae,we)}else{if(le.isInstancedBufferAttribute){for(let X=0;X<W.locationSize;X++)p(W.location+X,le.meshPerAttribute);w.isInstancedMesh!==!0&&O._maxInstanceCount===void 0&&(O._maxInstanceCount=le.meshPerAttribute*le.count)}else for(let X=0;X<W.locationSize;X++)m(W.location+X);i.bindBuffer(i.ARRAY_BUFFER,qe);for(let X=0;X<W.locationSize;X++)v(W.location+X,Me/W.locationSize,J,pe,Me*ae,Me/W.locationSize*X*ae,we)}}else if(j!==void 0){const pe=j[Q];if(pe!==void 0)switch(pe.length){case 2:i.vertexAttrib2fv(W.location,pe);break;case 3:i.vertexAttrib3fv(W.location,pe);break;case 4:i.vertexAttrib4fv(W.location,pe);break;default:i.vertexAttrib1fv(W.location,pe)}}}}M()}function I(){P();for(const w in n){const D=n[w];for(const z in D){const O=D[z];for(const Y in O)u(O[Y].object),delete O[Y];delete D[z]}delete n[w]}}function A(w){if(n[w.id]===void 0)return;const D=n[w.id];for(const z in D){const O=D[z];for(const Y in O)u(O[Y].object),delete O[Y];delete D[z]}delete n[w.id]}function T(w){for(const D in n){const z=n[D];if(z[w.id]===void 0)continue;const O=z[w.id];for(const Y in O)u(O[Y].object),delete O[Y];delete z[w.id]}}function P(){b(),o=!0,r!==s&&(r=s,l(r.object))}function b(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:P,resetDefaultState:b,dispose:I,releaseStatesOfGeometry:A,releaseStatesOfProgram:T,initAttributes:_,enableAttribute:m,disableUnusedAttributes:M}}function c_(i,e,t){let n;function s(l){n=l}function r(l,u){i.drawArrays(n,l,u),t.update(u,n,1)}function o(l,u,h){h!==0&&(i.drawArraysInstanced(n,l,u,h),t.update(u,n,h))}function a(l,u,h){if(h===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,u,0,h);let f=0;for(let g=0;g<h;g++)f+=u[g];t.update(f,n,1)}function c(l,u,h,d){if(h===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<l.length;g++)o(l[g],u[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,l,0,u,0,d,0,h);let g=0;for(let _=0;_<h;_++)g+=u[_]*d[_];t.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=c}function l_(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const T=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(T){return!(T!==Mn&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){const P=T===Ir&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(T!==ri&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==Dn&&!P)}function c(T){if(T==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=t.precision!==void 0?t.precision:"highp";const u=c(l);u!==l&&(console.warn("THREE.WebGLRenderer:",l,"not supported, using",u,"instead."),l=u);const h=t.logarithmicDepthBuffer===!0,d=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),M=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),v=i.getParameter(i.MAX_VARYING_VECTORS),x=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),I=g>0,A=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:h,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:M,maxVaryings:v,maxFragmentUniforms:x,vertexTextures:I,maxSamples:A}}function u_(i){const e=this;let t=null,n=0,s=!1,r=!1;const o=new Vi,a=new Ke,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(h,d){const f=h.length!==0||d||n!==0||s;return s=d,n=h.length,f},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(h,d){t=u(h,d,0)},this.setState=function(h,d,f){const g=h.clippingPlanes,_=h.clipIntersection,m=h.clipShadows,p=i.get(h);if(!s||g===null||g.length===0||r&&!m)r?u(null):l();else{const M=r?0:n,v=M*4;let x=p.clippingState||null;c.value=x,x=u(g,d,v,f);for(let I=0;I!==v;++I)x[I]=t[I];p.clippingState=x,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=M}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function u(h,d,f,g){const _=h!==null?h.length:0;let m=null;if(_!==0){if(m=c.value,g!==!0||m===null){const p=f+_*4,M=d.matrixWorldInverse;a.getNormalMatrix(M),(m===null||m.length<p)&&(m=new Float32Array(p));for(let v=0,x=f;v!==_;++v,x+=4)o.copy(h[v]).applyMatrix4(M,a),o.normal.toArray(m,x),m[x+3]=o.constant}c.value=m,c.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,m}}function h_(i){let e=new WeakMap;function t(o,a){return a===cc?o.mapping=Ls:a===lc&&(o.mapping=Is),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===cc||a===lc)if(e.has(o)){const c=e.get(o).texture;return t(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const l=new Sm(c.height);return l.fromEquirectangularTexture(i,o),e.set(o,l),o.addEventListener("dispose",s),t(l.texture,o.mapping)}else return null}}return o}function s(o){const a=o.target;a.removeEventListener("dispose",s);const c=e.get(a);c!==void 0&&(e.delete(a),c.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}class xl extends Id{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-e,o=n+e,a=s+t,c=s-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,o=r+l*this.view.width,a-=u*this.view.offsetY,c=a-u*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const Ss=4,Lu=[.125,.215,.35,.446,.526,.582],Xi=20,Ra=new xl,Iu=new Fe;let Ca=null,Pa=0,La=0,Ia=!1;const Gi=(1+Math.sqrt(5))/2,gs=1/Gi,Du=[new R(-Gi,gs,0),new R(Gi,gs,0),new R(-gs,0,Gi),new R(gs,0,Gi),new R(0,Gi,-gs),new R(0,Gi,gs),new R(-1,1,-1),new R(1,1,-1),new R(-1,1,1),new R(1,1,1)];class Nu{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100){Ca=this._renderer.getRenderTarget(),Pa=this._renderer.getActiveCubeFace(),La=this._renderer.getActiveMipmapLevel(),Ia=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,n,s,r),t>0&&this._blur(r,0,0,t),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Fu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ku(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Ca,Pa,La),this._renderer.xr.enabled=Ia,e.scissorTest=!1,so(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Ls||e.mapping===Is?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Ca=this._renderer.getRenderTarget(),Pa=this._renderer.getActiveCubeFace(),La=this._renderer.getActiveMipmapLevel(),Ia=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:hn,minFilter:hn,generateMipmaps:!1,type:Ir,format:Mn,colorSpace:nn,depthBuffer:!1},s=Uu(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Uu(e,t,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=d_(r)),this._blurMaterial=f_(r,e,t)}return s}_compileMaterial(e){const t=new G(this._lodPlanes[0],e);this._renderer.compile(t,Ra)}_sceneToCubeUV(e,t,n,s){const a=new Qt(90,1,t,n),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],u=this._renderer,h=u.autoClear,d=u.toneMapping;u.getClearColor(Iu),u.toneMapping=Ei,u.autoClear=!1;const f=new Dt({name:"PMREM.Background",side:on,depthWrite:!1,depthTest:!1}),g=new G(new li,f);let _=!1;const m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,_=!0):(f.color.copy(Iu),_=!0);for(let p=0;p<6;p++){const M=p%3;M===0?(a.up.set(0,c[p],0),a.lookAt(l[p],0,0)):M===1?(a.up.set(0,0,c[p]),a.lookAt(0,l[p],0)):(a.up.set(0,c[p],0),a.lookAt(0,0,l[p]));const v=this._cubeSize;so(s,M*v,p>2?v:0,v,v),u.setRenderTarget(s),_&&u.render(g,a),u.render(e,a)}g.geometry.dispose(),g.material.dispose(),u.toneMapping=d,u.autoClear=h,e.background=m}_textureToCubeUV(e,t){const n=this._renderer,s=e.mapping===Ls||e.mapping===Is;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Fu()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=ku());const r=s?this._cubemapMaterial:this._equirectMaterial,o=new G(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=e;const c=this._cubeSize;so(t,0,0,3*c,2*c),n.setRenderTarget(t),n.render(o,Ra)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=Du[(s-r-1)%Du.length];this._blur(e,r-1,r,o,a)}t.autoClear=n}_blur(e,t,n,s,r){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,s,"latitudinal",r),this._halfBlur(o,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,o,a){const c=this._renderer,l=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const u=3,h=new G(this._lodPlanes[s],l),d=l.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*Xi-1),_=r/g,m=isFinite(r)?1+Math.floor(u*_):Xi;m>Xi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Xi}`);const p=[];let M=0;for(let T=0;T<Xi;++T){const P=T/_,b=Math.exp(-P*P/2);p.push(b),T===0?M+=b:T<m&&(M+=2*b)}for(let T=0;T<p.length;T++)p[T]=p[T]/M;d.envMap.value=e.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:v}=this;d.dTheta.value=g,d.mipInt.value=v-n;const x=this._sizeLods[s],I=3*x*(s>v-Ss?s-v+Ss:0),A=4*(this._cubeSize-x);so(t,I,A,3*x,2*x),c.setRenderTarget(t),c.render(h,Ra)}}function d_(i){const e=[],t=[],n=[];let s=i;const r=i-Ss+1+Lu.length;for(let o=0;o<r;o++){const a=Math.pow(2,s);t.push(a);let c=1/a;o>i-Ss?c=Lu[o-i+Ss-1]:o===0&&(c=0),n.push(c);const l=1/(a-2),u=-l,h=1+l,d=[u,u,h,u,h,h,u,u,h,h,u,h],f=6,g=6,_=3,m=2,p=1,M=new Float32Array(_*g*f),v=new Float32Array(m*g*f),x=new Float32Array(p*g*f);for(let A=0;A<f;A++){const T=A%3*2/3-1,P=A>2?0:-1,b=[T,P,0,T+2/3,P,0,T+2/3,P+1,0,T,P,0,T+2/3,P+1,0,T,P+1,0];M.set(b,_*g*A),v.set(d,m*g*A);const w=[A,A,A,A,A,A];x.set(w,p*g*A)}const I=new Tt;I.setAttribute("position",new jt(M,_)),I.setAttribute("uv",new jt(v,m)),I.setAttribute("faceIndex",new jt(x,p)),e.push(I),s>Ss&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function Uu(i,e,t){const n=new Ki(i,e,t);return n.texture.mapping=Xo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function so(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function f_(i,e,t){const n=new Float32Array(Xi),s=new R(0,1,0);return new oi({name:"SphericalGaussianBlur",defines:{n:Xi,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:vl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:bi,depthTest:!1,depthWrite:!1})}function ku(){return new oi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:vl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:bi,depthTest:!1,depthWrite:!1})}function Fu(){return new oi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:vl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:bi,depthTest:!1,depthWrite:!1})}function vl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function p_(i){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){const c=a.mapping,l=c===cc||c===lc,u=c===Ls||c===Is;if(l||u){let h=e.get(a);const d=h!==void 0?h.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return t===null&&(t=new Nu(i)),h=l?t.fromEquirectangular(a,h):t.fromCubemap(a,h),h.texture.pmremVersion=a.pmremVersion,e.set(a,h),h.texture;if(h!==void 0)return h.texture;{const f=a.image;return l&&f&&f.height>0||u&&f&&s(f)?(t===null&&(t=new Nu(i)),h=l?t.fromEquirectangular(a):t.fromCubemap(a),h.texture.pmremVersion=a.pmremVersion,e.set(a,h),a.addEventListener("dispose",r),h.texture):null}}}return a}function s(a){let c=0;const l=6;for(let u=0;u<l;u++)a[u]!==void 0&&c++;return c===l}function r(a){const c=a.target;c.removeEventListener("dispose",r);const l=e.get(c);l!==void 0&&(e.delete(c),l.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function m_(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&dr("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function g_(i,e,t,n){const s={},r=new WeakMap;function o(h){const d=h.target;d.index!==null&&e.remove(d.index);for(const g in d.attributes)e.remove(d.attributes[g]);for(const g in d.morphAttributes){const _=d.morphAttributes[g];for(let m=0,p=_.length;m<p;m++)e.remove(_[m])}d.removeEventListener("dispose",o),delete s[d.id];const f=r.get(d);f&&(e.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(h,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,t.memory.geometries++),d}function c(h){const d=h.attributes;for(const g in d)e.update(d[g],i.ARRAY_BUFFER);const f=h.morphAttributes;for(const g in f){const _=f[g];for(let m=0,p=_.length;m<p;m++)e.update(_[m],i.ARRAY_BUFFER)}}function l(h){const d=[],f=h.index,g=h.attributes.position;let _=0;if(f!==null){const M=f.array;_=f.version;for(let v=0,x=M.length;v<x;v+=3){const I=M[v+0],A=M[v+1],T=M[v+2];d.push(I,A,A,T,T,I)}}else if(g!==void 0){const M=g.array;_=g.version;for(let v=0,x=M.length/3-1;v<x;v+=3){const I=v+0,A=v+1,T=v+2;d.push(I,A,A,T,T,I)}}else return;const m=new(bd(d)?Pd:Cd)(d,1);m.version=_;const p=r.get(h);p&&e.remove(p),r.set(h,m)}function u(h){const d=r.get(h);if(d){const f=h.index;f!==null&&d.version<f.version&&l(h)}else l(h);return r.get(h)}return{get:a,update:c,getWireframeAttribute:u}}function __(i,e,t){let n;function s(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function c(d,f){i.drawElements(n,f,r,d*o),t.update(f,n,1)}function l(d,f,g){g!==0&&(i.drawElementsInstanced(n,f,r,d*o,g),t.update(f,n,g))}function u(d,f,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];t.update(m,n,1)}function h(d,f,g,_){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)l(d[p]/o,f[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,_,0,g);let p=0;for(let M=0;M<g;M++)p+=f[M]*_[M];t.update(p,n,1)}}this.setMode=s,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=u,this.renderMultiDrawInstances=h}function x_(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(r/3);break;case i.LINES:t.lines+=a*(r/2);break;case i.LINE_STRIP:t.lines+=a*(r-1);break;case i.LINE_LOOP:t.lines+=a*r;break;case i.POINTS:t.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function v_(i,e,t){const n=new WeakMap,s=new at;function r(o,a,c){const l=o.morphTargetInfluences,u=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,h=u!==void 0?u.length:0;let d=n.get(a);if(d===void 0||d.count!==h){let w=function(){P.dispose(),n.delete(a),a.removeEventListener("dispose",w)};var f=w;d!==void 0&&d.texture.dispose();const g=a.morphAttributes.position!==void 0,_=a.morphAttributes.normal!==void 0,m=a.morphAttributes.color!==void 0,p=a.morphAttributes.position||[],M=a.morphAttributes.normal||[],v=a.morphAttributes.color||[];let x=0;g===!0&&(x=1),_===!0&&(x=2),m===!0&&(x=3);let I=a.attributes.position.count*x,A=1;I>e.maxTextureSize&&(A=Math.ceil(I/e.maxTextureSize),I=e.maxTextureSize);const T=new Float32Array(I*A*4*h),P=new Td(T,I,A,h);P.type=Dn,P.needsUpdate=!0;const b=x*4;for(let D=0;D<h;D++){const z=p[D],O=M[D],Y=v[D],q=I*A*4*D;for(let j=0;j<z.count;j++){const Q=j*b;g===!0&&(s.fromBufferAttribute(z,j),T[q+Q+0]=s.x,T[q+Q+1]=s.y,T[q+Q+2]=s.z,T[q+Q+3]=0),_===!0&&(s.fromBufferAttribute(O,j),T[q+Q+4]=s.x,T[q+Q+5]=s.y,T[q+Q+6]=s.z,T[q+Q+7]=0),m===!0&&(s.fromBufferAttribute(Y,j),T[q+Q+8]=s.x,T[q+Q+9]=s.y,T[q+Q+10]=s.z,T[q+Q+11]=Y.itemSize===4?s.w:1)}}d={count:h,texture:P,size:new se(I,A)},n.set(a,d),a.addEventListener("dispose",w)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let g=0;for(let m=0;m<l.length;m++)g+=l[m];const _=a.morphTargetsRelative?1:1-g;c.getUniforms().setValue(i,"morphTargetBaseInfluence",_),c.getUniforms().setValue(i,"morphTargetInfluences",l)}c.getUniforms().setValue(i,"morphTargetsTexture",d.texture,t),c.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function y_(i,e,t,n){let s=new WeakMap;function r(c){const l=n.render.frame,u=c.geometry,h=e.get(c,u);if(s.get(h)!==l&&(e.update(h),s.set(h,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",a)===!1&&c.addEventListener("dispose",a),s.get(c)!==l&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){const d=c.skeleton;s.get(d)!==l&&(d.update(),s.set(d,l))}return h}function o(){s=new WeakMap}function a(c){const l=c.target;l.removeEventListener("dispose",a),t.remove(l.instanceMatrix),l.instanceColor!==null&&t.remove(l.instanceColor)}return{update:r,dispose:o}}class Ud extends Nt{constructor(e,t,n,s,r,o,a,c,l,u=bs){if(u!==bs&&u!==Ns)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&u===bs&&(n=ji),n===void 0&&u===Ns&&(n=Ds),super(null,s,r,o,a,c,u,n,l),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:en,this.minFilter=c!==void 0?c:en,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const kd=new Nt,Ou=new Ud(1,1),Fd=new Td,Od=new om,Bd=new Dd,Bu=[],zu=[],Hu=new Float32Array(16),Vu=new Float32Array(9),Gu=new Float32Array(4);function Gs(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let r=Bu[s];if(r===void 0&&(r=new Float32Array(s),Bu[s]=r),e!==0){n.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(r,a)}return r}function Ut(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function kt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function Yo(i,e){let t=zu[e];t===void 0&&(t=new Int32Array(e),zu[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function M_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function S_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ut(t,e))return;i.uniform2fv(this.addr,e),kt(t,e)}}function w_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Ut(t,e))return;i.uniform3fv(this.addr,e),kt(t,e)}}function b_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ut(t,e))return;i.uniform4fv(this.addr,e),kt(t,e)}}function E_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Ut(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),kt(t,e)}else{if(Ut(t,n))return;Gu.set(n),i.uniformMatrix2fv(this.addr,!1,Gu),kt(t,n)}}function T_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Ut(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),kt(t,e)}else{if(Ut(t,n))return;Vu.set(n),i.uniformMatrix3fv(this.addr,!1,Vu),kt(t,n)}}function A_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Ut(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),kt(t,e)}else{if(Ut(t,n))return;Hu.set(n),i.uniformMatrix4fv(this.addr,!1,Hu),kt(t,n)}}function R_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function C_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ut(t,e))return;i.uniform2iv(this.addr,e),kt(t,e)}}function P_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Ut(t,e))return;i.uniform3iv(this.addr,e),kt(t,e)}}function L_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ut(t,e))return;i.uniform4iv(this.addr,e),kt(t,e)}}function I_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function D_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ut(t,e))return;i.uniform2uiv(this.addr,e),kt(t,e)}}function N_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Ut(t,e))return;i.uniform3uiv(this.addr,e),kt(t,e)}}function U_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ut(t,e))return;i.uniform4uiv(this.addr,e),kt(t,e)}}function k_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(Ou.compareFunction=wd,r=Ou):r=kd,t.setTexture2D(e||r,s)}function F_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||Od,s)}function O_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||Bd,s)}function B_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||Fd,s)}function z_(i){switch(i){case 5126:return M_;case 35664:return S_;case 35665:return w_;case 35666:return b_;case 35674:return E_;case 35675:return T_;case 35676:return A_;case 5124:case 35670:return R_;case 35667:case 35671:return C_;case 35668:case 35672:return P_;case 35669:case 35673:return L_;case 5125:return I_;case 36294:return D_;case 36295:return N_;case 36296:return U_;case 35678:case 36198:case 36298:case 36306:case 35682:return k_;case 35679:case 36299:case 36307:return F_;case 35680:case 36300:case 36308:case 36293:return O_;case 36289:case 36303:case 36311:case 36292:return B_}}function H_(i,e){i.uniform1fv(this.addr,e)}function V_(i,e){const t=Gs(e,this.size,2);i.uniform2fv(this.addr,t)}function G_(i,e){const t=Gs(e,this.size,3);i.uniform3fv(this.addr,t)}function W_(i,e){const t=Gs(e,this.size,4);i.uniform4fv(this.addr,t)}function X_(i,e){const t=Gs(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function q_(i,e){const t=Gs(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function $_(i,e){const t=Gs(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function Y_(i,e){i.uniform1iv(this.addr,e)}function j_(i,e){i.uniform2iv(this.addr,e)}function K_(i,e){i.uniform3iv(this.addr,e)}function Z_(i,e){i.uniform4iv(this.addr,e)}function J_(i,e){i.uniform1uiv(this.addr,e)}function Q_(i,e){i.uniform2uiv(this.addr,e)}function ex(i,e){i.uniform3uiv(this.addr,e)}function tx(i,e){i.uniform4uiv(this.addr,e)}function nx(i,e,t){const n=this.cache,s=e.length,r=Yo(t,s);Ut(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||kd,r[o])}function ix(i,e,t){const n=this.cache,s=e.length,r=Yo(t,s);Ut(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||Od,r[o])}function sx(i,e,t){const n=this.cache,s=e.length,r=Yo(t,s);Ut(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Bd,r[o])}function rx(i,e,t){const n=this.cache,s=e.length,r=Yo(t,s);Ut(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||Fd,r[o])}function ox(i){switch(i){case 5126:return H_;case 35664:return V_;case 35665:return G_;case 35666:return W_;case 35674:return X_;case 35675:return q_;case 35676:return $_;case 5124:case 35670:return Y_;case 35667:case 35671:return j_;case 35668:case 35672:return K_;case 35669:case 35673:return Z_;case 5125:return J_;case 36294:return Q_;case 36295:return ex;case 36296:return tx;case 35678:case 36198:case 36298:case 36306:case 35682:return nx;case 35679:case 36299:case 36307:return ix;case 35680:case 36300:case 36308:case 36293:return sx;case 36289:case 36303:case 36311:case 36292:return rx}}class ax{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=z_(t.type)}}class cx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=ox(t.type)}}class lx{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const a=s[r];a.setValue(e,t[a.id],n)}}}const Da=/(\w+)(\])?(\[|\.)?/g;function Wu(i,e){i.seq.push(e),i.map[e.id]=e}function ux(i,e,t){const n=i.name,s=n.length;for(Da.lastIndex=0;;){const r=Da.exec(n),o=Da.lastIndex;let a=r[1];const c=r[2]==="]",l=r[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===s){Wu(t,l===void 0?new ax(a,i,e):new cx(a,i,e));break}else{let h=t.map[a];h===void 0&&(h=new lx(a),Wu(t,h)),t=h}}}class Lo{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);ux(r,o,this)}}setValue(e,t,n,s){const r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){const a=t[r],c=n[a.id];c.needsUpdate!==!1&&a.setValue(e,c.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,r=e.length;s!==r;++s){const o=e[s];o.id in t&&n.push(o)}return n}}function Xu(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const hx=37297;let dx=0;function fx(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){const a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}const qu=new Ke;function px(i){st._getMatrix(qu,st.workingColorSpace,i);const e=`mat3( ${qu.elements.map(t=>t.toFixed(4))} )`;switch(st.getTransfer(i)){case qo:return[e,"LinearTransferOETF"];case pt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function $u(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=i.getShaderInfoLog(e).trim();if(n&&s==="")return"";const r=/ERROR: 0:(\d+)/.exec(s);if(r){const o=parseInt(r[1]);return t.toUpperCase()+`

`+s+`

`+fx(i.getShaderSource(e),o)}else return s}function mx(i,e){const t=px(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function gx(i,e){let t;switch(e){case _p:t="Linear";break;case xp:t="Reinhard";break;case vp:t="Cineon";break;case ud:t="ACESFilmic";break;case Mp:t="AgX";break;case Sp:t="Neutral";break;case yp:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const ro=new R;function _x(){st.getLuminanceCoefficients(ro);const i=ro.x.toFixed(4),e=ro.y.toFixed(4),t=ro.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function xx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(fr).join(`
`)}function vx(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function yx(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s),o=r.name;let a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function fr(i){return i!==""}function Yu(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function ju(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Mx=/^[ \t]*#include +<([\w\d./]+)>/gm;function Oc(i){return i.replace(Mx,wx)}const Sx=new Map;function wx(i,e){let t=et[e];if(t===void 0){const n=Sx.get(e);if(n!==void 0)t=et[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Oc(t)}const bx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Ku(i){return i.replace(bx,Ex)}function Ex(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Zu(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Tx(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===cd?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===ld?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===Jn&&(e="SHADOWMAP_TYPE_VSM"),e}function Ax(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Ls:case Is:e="ENVMAP_TYPE_CUBE";break;case Xo:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Rx(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Is:e="ENVMAP_MODE_REFRACTION";break}return e}function Cx(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case ol:e="ENVMAP_BLENDING_MULTIPLY";break;case mp:e="ENVMAP_BLENDING_MIX";break;case gp:e="ENVMAP_BLENDING_ADD";break}return e}function Px(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function Lx(i,e,t,n){const s=i.getContext(),r=t.defines;let o=t.vertexShader,a=t.fragmentShader;const c=Tx(t),l=Ax(t),u=Rx(t),h=Cx(t),d=Px(t),f=xx(t),g=vx(r),_=s.createProgram();let m,p,M=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(fr).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(fr).join(`
`),p.length>0&&(p+=`
`)):(m=[Zu(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(fr).join(`
`),p=[Zu(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+u:"",t.envMap?"#define "+h:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ei?"#define TONE_MAPPING":"",t.toneMapping!==Ei?et.tonemapping_pars_fragment:"",t.toneMapping!==Ei?gx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",et.colorspace_pars_fragment,mx("linearToOutputTexel",t.outputColorSpace),_x(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(fr).join(`
`)),o=Oc(o),o=Yu(o,t),o=ju(o,t),a=Oc(a),a=Yu(a,t),a=ju(a,t),o=Ku(o),a=Ku(a),t.isRawShaderMaterial!==!0&&(M=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===lu?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===lu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const v=M+m+o,x=M+p+a,I=Xu(s,s.VERTEX_SHADER,v),A=Xu(s,s.FRAGMENT_SHADER,x);s.attachShader(_,I),s.attachShader(_,A),t.index0AttributeName!==void 0?s.bindAttribLocation(_,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function T(D){if(i.debug.checkShaderErrors){const z=s.getProgramInfoLog(_).trim(),O=s.getShaderInfoLog(I).trim(),Y=s.getShaderInfoLog(A).trim();let q=!0,j=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(q=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,I,A);else{const Q=$u(s,I,"vertex"),W=$u(s,A,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+D.name+`
Material Type: `+D.type+`

Program Info Log: `+z+`
`+Q+`
`+W)}else z!==""?console.warn("THREE.WebGLProgram: Program Info Log:",z):(O===""||Y==="")&&(j=!1);j&&(D.diagnostics={runnable:q,programLog:z,vertexShader:{log:O,prefix:m},fragmentShader:{log:Y,prefix:p}})}s.deleteShader(I),s.deleteShader(A),P=new Lo(s,_),b=yx(s,_)}let P;this.getUniforms=function(){return P===void 0&&T(this),P};let b;this.getAttributes=function(){return b===void 0&&T(this),b};let w=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return w===!1&&(w=s.getProgramParameter(_,hx)),w},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=dx++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=I,this.fragmentShader=A,this}let Ix=0;class Dx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new Nx(e),t.set(e,n)),n}}class Nx{constructor(e){this.id=Ix++,this.code=e,this.usedTimes=0}}function Ux(i,e,t,n,s,r,o){const a=new Ad,c=new Dx,l=new Set,u=[],h=s.logarithmicDepthBuffer,d=s.vertexTextures;let f=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(b){return l.add(b),b===0?"uv":`uv${b}`}function m(b,w,D,z,O){const Y=z.fog,q=O.geometry,j=b.isMeshStandardMaterial?z.environment:null,Q=(b.isMeshStandardMaterial?t:e).get(b.envMap||j),W=Q&&Q.mapping===Xo?Q.image.height:null,le=g[b.type];b.precision!==null&&(f=s.getMaxPrecision(b.precision),f!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",f,"instead."));const pe=q.morphAttributes.position||q.morphAttributes.normal||q.morphAttributes.color,Me=pe!==void 0?pe.length:0;let Le=0;q.morphAttributes.position!==void 0&&(Le=1),q.morphAttributes.normal!==void 0&&(Le=2),q.morphAttributes.color!==void 0&&(Le=3);let qe,J,ae,we;if(le){const ut=On[le];qe=ut.vertexShader,J=ut.fragmentShader}else qe=b.vertexShader,J=b.fragmentShader,c.update(b),ae=c.getVertexShaderID(b),we=c.getFragmentShaderID(b);const X=i.getRenderTarget(),he=i.state.buffers.depth.getReversed(),Ae=O.isInstancedMesh===!0,Ie=O.isBatchedMesh===!0,Je=!!b.map,ee=!!b.matcap,re=!!Q,C=!!b.aoMap,Te=!!b.lightMap,ie=!!b.bumpMap,_e=!!b.normalMap,ue=!!b.displacementMap,Oe=!!b.emissiveMap,L=!!b.metalnessMap,S=!!b.roughnessMap,y=b.anisotropy>0,N=b.clearcoat>0,B=b.dispersion>0,K=b.iridescence>0,$=b.sheen>0,Ee=b.transmission>0,de=y&&!!b.anisotropyMap,Se=N&&!!b.clearcoatMap,$e=N&&!!b.clearcoatNormalMap,oe=N&&!!b.clearcoatRoughnessMap,me=K&&!!b.iridescenceMap,Ue=K&&!!b.iridescenceThicknessMap,Ge=$&&!!b.sheenColorMap,be=$&&!!b.sheenRoughnessMap,it=!!b.specularMap,Qe=!!b.specularColorMap,_t=!!b.specularIntensityMap,U=Ee&&!!b.transmissionMap,ge=Ee&&!!b.thicknessMap,Z=!!b.gradientMap,ne=!!b.alphaMap,ye=b.alphaTest>0,xe=!!b.alphaHash,Ye=!!b.extensions;let At=Ei;b.toneMapped&&(X===null||X.isXRRenderTarget===!0)&&(At=i.toneMapping);const Gt={shaderID:le,shaderType:b.type,shaderName:b.name,vertexShader:qe,fragmentShader:J,defines:b.defines,customVertexShaderID:ae,customFragmentShaderID:we,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:f,batching:Ie,batchingColor:Ie&&O._colorsTexture!==null,instancing:Ae,instancingColor:Ae&&O.instanceColor!==null,instancingMorph:Ae&&O.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:X===null?i.outputColorSpace:X.isXRRenderTarget===!0?X.texture.colorSpace:nn,alphaToCoverage:!!b.alphaToCoverage,map:Je,matcap:ee,envMap:re,envMapMode:re&&Q.mapping,envMapCubeUVHeight:W,aoMap:C,lightMap:Te,bumpMap:ie,normalMap:_e,displacementMap:d&&ue,emissiveMap:Oe,normalMapObjectSpace:_e&&b.normalMapType===Rp,normalMapTangentSpace:_e&&b.normalMapType===pl,metalnessMap:L,roughnessMap:S,anisotropy:y,anisotropyMap:de,clearcoat:N,clearcoatMap:Se,clearcoatNormalMap:$e,clearcoatRoughnessMap:oe,dispersion:B,iridescence:K,iridescenceMap:me,iridescenceThicknessMap:Ue,sheen:$,sheenColorMap:Ge,sheenRoughnessMap:be,specularMap:it,specularColorMap:Qe,specularIntensityMap:_t,transmission:Ee,transmissionMap:U,thicknessMap:ge,gradientMap:Z,opaque:b.transparent===!1&&b.blending===$i&&b.alphaToCoverage===!1,alphaMap:ne,alphaTest:ye,alphaHash:xe,combine:b.combine,mapUv:Je&&_(b.map.channel),aoMapUv:C&&_(b.aoMap.channel),lightMapUv:Te&&_(b.lightMap.channel),bumpMapUv:ie&&_(b.bumpMap.channel),normalMapUv:_e&&_(b.normalMap.channel),displacementMapUv:ue&&_(b.displacementMap.channel),emissiveMapUv:Oe&&_(b.emissiveMap.channel),metalnessMapUv:L&&_(b.metalnessMap.channel),roughnessMapUv:S&&_(b.roughnessMap.channel),anisotropyMapUv:de&&_(b.anisotropyMap.channel),clearcoatMapUv:Se&&_(b.clearcoatMap.channel),clearcoatNormalMapUv:$e&&_(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:oe&&_(b.clearcoatRoughnessMap.channel),iridescenceMapUv:me&&_(b.iridescenceMap.channel),iridescenceThicknessMapUv:Ue&&_(b.iridescenceThicknessMap.channel),sheenColorMapUv:Ge&&_(b.sheenColorMap.channel),sheenRoughnessMapUv:be&&_(b.sheenRoughnessMap.channel),specularMapUv:it&&_(b.specularMap.channel),specularColorMapUv:Qe&&_(b.specularColorMap.channel),specularIntensityMapUv:_t&&_(b.specularIntensityMap.channel),transmissionMapUv:U&&_(b.transmissionMap.channel),thicknessMapUv:ge&&_(b.thicknessMap.channel),alphaMapUv:ne&&_(b.alphaMap.channel),vertexTangents:!!q.attributes.tangent&&(_e||y),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!q.attributes.color&&q.attributes.color.itemSize===4,pointsUvs:O.isPoints===!0&&!!q.attributes.uv&&(Je||ne),fog:!!Y,useFog:b.fog===!0,fogExp2:!!Y&&Y.isFogExp2,flatShading:b.flatShading===!0,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:h,reverseDepthBuffer:he,skinning:O.isSkinnedMesh===!0,morphTargets:q.morphAttributes.position!==void 0,morphNormals:q.morphAttributes.normal!==void 0,morphColors:q.morphAttributes.color!==void 0,morphTargetsCount:Me,morphTextureStride:Le,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:b.dithering,shadowMapEnabled:i.shadowMap.enabled&&D.length>0,shadowMapType:i.shadowMap.type,toneMapping:At,decodeVideoTexture:Je&&b.map.isVideoTexture===!0&&st.getTransfer(b.map.colorSpace)===pt,decodeVideoTextureEmissive:Oe&&b.emissiveMap.isVideoTexture===!0&&st.getTransfer(b.emissiveMap.colorSpace)===pt,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===Bt,flipSided:b.side===on,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionClipCullDistance:Ye&&b.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ye&&b.extensions.multiDraw===!0||Ie)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()};return Gt.vertexUv1s=l.has(1),Gt.vertexUv2s=l.has(2),Gt.vertexUv3s=l.has(3),l.clear(),Gt}function p(b){const w=[];if(b.shaderID?w.push(b.shaderID):(w.push(b.customVertexShaderID),w.push(b.customFragmentShaderID)),b.defines!==void 0)for(const D in b.defines)w.push(D),w.push(b.defines[D]);return b.isRawShaderMaterial===!1&&(M(w,b),v(w,b),w.push(i.outputColorSpace)),w.push(b.customProgramCacheKey),w.join()}function M(b,w){b.push(w.precision),b.push(w.outputColorSpace),b.push(w.envMapMode),b.push(w.envMapCubeUVHeight),b.push(w.mapUv),b.push(w.alphaMapUv),b.push(w.lightMapUv),b.push(w.aoMapUv),b.push(w.bumpMapUv),b.push(w.normalMapUv),b.push(w.displacementMapUv),b.push(w.emissiveMapUv),b.push(w.metalnessMapUv),b.push(w.roughnessMapUv),b.push(w.anisotropyMapUv),b.push(w.clearcoatMapUv),b.push(w.clearcoatNormalMapUv),b.push(w.clearcoatRoughnessMapUv),b.push(w.iridescenceMapUv),b.push(w.iridescenceThicknessMapUv),b.push(w.sheenColorMapUv),b.push(w.sheenRoughnessMapUv),b.push(w.specularMapUv),b.push(w.specularColorMapUv),b.push(w.specularIntensityMapUv),b.push(w.transmissionMapUv),b.push(w.thicknessMapUv),b.push(w.combine),b.push(w.fogExp2),b.push(w.sizeAttenuation),b.push(w.morphTargetsCount),b.push(w.morphAttributeCount),b.push(w.numDirLights),b.push(w.numPointLights),b.push(w.numSpotLights),b.push(w.numSpotLightMaps),b.push(w.numHemiLights),b.push(w.numRectAreaLights),b.push(w.numDirLightShadows),b.push(w.numPointLightShadows),b.push(w.numSpotLightShadows),b.push(w.numSpotLightShadowsWithMaps),b.push(w.numLightProbes),b.push(w.shadowMapType),b.push(w.toneMapping),b.push(w.numClippingPlanes),b.push(w.numClipIntersection),b.push(w.depthPacking)}function v(b,w){a.disableAll(),w.supportsVertexTextures&&a.enable(0),w.instancing&&a.enable(1),w.instancingColor&&a.enable(2),w.instancingMorph&&a.enable(3),w.matcap&&a.enable(4),w.envMap&&a.enable(5),w.normalMapObjectSpace&&a.enable(6),w.normalMapTangentSpace&&a.enable(7),w.clearcoat&&a.enable(8),w.iridescence&&a.enable(9),w.alphaTest&&a.enable(10),w.vertexColors&&a.enable(11),w.vertexAlphas&&a.enable(12),w.vertexUv1s&&a.enable(13),w.vertexUv2s&&a.enable(14),w.vertexUv3s&&a.enable(15),w.vertexTangents&&a.enable(16),w.anisotropy&&a.enable(17),w.alphaHash&&a.enable(18),w.batching&&a.enable(19),w.dispersion&&a.enable(20),w.batchingColor&&a.enable(21),b.push(a.mask),a.disableAll(),w.fog&&a.enable(0),w.useFog&&a.enable(1),w.flatShading&&a.enable(2),w.logarithmicDepthBuffer&&a.enable(3),w.reverseDepthBuffer&&a.enable(4),w.skinning&&a.enable(5),w.morphTargets&&a.enable(6),w.morphNormals&&a.enable(7),w.morphColors&&a.enable(8),w.premultipliedAlpha&&a.enable(9),w.shadowMapEnabled&&a.enable(10),w.doubleSided&&a.enable(11),w.flipSided&&a.enable(12),w.useDepthPacking&&a.enable(13),w.dithering&&a.enable(14),w.transmission&&a.enable(15),w.sheen&&a.enable(16),w.opaque&&a.enable(17),w.pointsUvs&&a.enable(18),w.decodeVideoTexture&&a.enable(19),w.decodeVideoTextureEmissive&&a.enable(20),w.alphaToCoverage&&a.enable(21),b.push(a.mask)}function x(b){const w=g[b.type];let D;if(w){const z=On[w];D=xm.clone(z.uniforms)}else D=b.uniforms;return D}function I(b,w){let D;for(let z=0,O=u.length;z<O;z++){const Y=u[z];if(Y.cacheKey===w){D=Y,++D.usedTimes;break}}return D===void 0&&(D=new Lx(i,w,b,r),u.push(D)),D}function A(b){if(--b.usedTimes===0){const w=u.indexOf(b);u[w]=u[u.length-1],u.pop(),b.destroy()}}function T(b){c.remove(b)}function P(){c.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:x,acquireProgram:I,releaseProgram:A,releaseShaderCache:T,programs:u,dispose:P}}function kx(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,c){i.get(o)[a]=c}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function Fx(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Ju(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Qu(){const i=[];let e=0;const t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(h,d,f,g,_,m){let p=i[e];return p===void 0?(p={id:h.id,object:h,geometry:d,material:f,groupOrder:g,renderOrder:h.renderOrder,z:_,group:m},i[e]=p):(p.id=h.id,p.object=h,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=h.renderOrder,p.z=_,p.group=m),e++,p}function a(h,d,f,g,_,m){const p=o(h,d,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):t.push(p)}function c(h,d,f,g,_,m){const p=o(h,d,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):t.unshift(p)}function l(h,d){t.length>1&&t.sort(h||Fx),n.length>1&&n.sort(d||Ju),s.length>1&&s.sort(d||Ju)}function u(){for(let h=e,d=i.length;h<d;h++){const f=i[h];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:a,unshift:c,finish:u,sort:l}}function Ox(){let i=new WeakMap;function e(n,s){const r=i.get(n);let o;return r===void 0?(o=new Qu,i.set(n,[o])):s>=r.length?(o=new Qu,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function Bx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new R,color:new Fe};break;case"SpotLight":t={position:new R,direction:new R,color:new Fe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new R,color:new Fe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new R,skyColor:new Fe,groundColor:new Fe};break;case"RectAreaLight":t={color:new Fe,position:new R,halfWidth:new R,halfHeight:new R};break}return i[e.id]=t,t}}}function zx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new se};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new se};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new se,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let Hx=0;function Vx(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Gx(i){const e=new Bx,t=zx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new R);const s=new R,r=new He,o=new He;function a(l){let u=0,h=0,d=0;for(let b=0;b<9;b++)n.probe[b].set(0,0,0);let f=0,g=0,_=0,m=0,p=0,M=0,v=0,x=0,I=0,A=0,T=0;l.sort(Vx);for(let b=0,w=l.length;b<w;b++){const D=l[b],z=D.color,O=D.intensity,Y=D.distance,q=D.shadow&&D.shadow.map?D.shadow.map.texture:null;if(D.isAmbientLight)u+=z.r*O,h+=z.g*O,d+=z.b*O;else if(D.isLightProbe){for(let j=0;j<9;j++)n.probe[j].addScaledVector(D.sh.coefficients[j],O);T++}else if(D.isDirectionalLight){const j=e.get(D);if(j.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const Q=D.shadow,W=t.get(D);W.shadowIntensity=Q.intensity,W.shadowBias=Q.bias,W.shadowNormalBias=Q.normalBias,W.shadowRadius=Q.radius,W.shadowMapSize=Q.mapSize,n.directionalShadow[f]=W,n.directionalShadowMap[f]=q,n.directionalShadowMatrix[f]=D.shadow.matrix,M++}n.directional[f]=j,f++}else if(D.isSpotLight){const j=e.get(D);j.position.setFromMatrixPosition(D.matrixWorld),j.color.copy(z).multiplyScalar(O),j.distance=Y,j.coneCos=Math.cos(D.angle),j.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),j.decay=D.decay,n.spot[_]=j;const Q=D.shadow;if(D.map&&(n.spotLightMap[I]=D.map,I++,Q.updateMatrices(D),D.castShadow&&A++),n.spotLightMatrix[_]=Q.matrix,D.castShadow){const W=t.get(D);W.shadowIntensity=Q.intensity,W.shadowBias=Q.bias,W.shadowNormalBias=Q.normalBias,W.shadowRadius=Q.radius,W.shadowMapSize=Q.mapSize,n.spotShadow[_]=W,n.spotShadowMap[_]=q,x++}_++}else if(D.isRectAreaLight){const j=e.get(D);j.color.copy(z).multiplyScalar(O),j.halfWidth.set(D.width*.5,0,0),j.halfHeight.set(0,D.height*.5,0),n.rectArea[m]=j,m++}else if(D.isPointLight){const j=e.get(D);if(j.color.copy(D.color).multiplyScalar(D.intensity),j.distance=D.distance,j.decay=D.decay,D.castShadow){const Q=D.shadow,W=t.get(D);W.shadowIntensity=Q.intensity,W.shadowBias=Q.bias,W.shadowNormalBias=Q.normalBias,W.shadowRadius=Q.radius,W.shadowMapSize=Q.mapSize,W.shadowCameraNear=Q.camera.near,W.shadowCameraFar=Q.camera.far,n.pointShadow[g]=W,n.pointShadowMap[g]=q,n.pointShadowMatrix[g]=D.shadow.matrix,v++}n.point[g]=j,g++}else if(D.isHemisphereLight){const j=e.get(D);j.skyColor.copy(D.color).multiplyScalar(O),j.groundColor.copy(D.groundColor).multiplyScalar(O),n.hemi[p]=j,p++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=fe.LTC_FLOAT_1,n.rectAreaLTC2=fe.LTC_FLOAT_2):(n.rectAreaLTC1=fe.LTC_HALF_1,n.rectAreaLTC2=fe.LTC_HALF_2)),n.ambient[0]=u,n.ambient[1]=h,n.ambient[2]=d;const P=n.hash;(P.directionalLength!==f||P.pointLength!==g||P.spotLength!==_||P.rectAreaLength!==m||P.hemiLength!==p||P.numDirectionalShadows!==M||P.numPointShadows!==v||P.numSpotShadows!==x||P.numSpotMaps!==I||P.numLightProbes!==T)&&(n.directional.length=f,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=M,n.directionalShadowMap.length=M,n.pointShadow.length=v,n.pointShadowMap.length=v,n.spotShadow.length=x,n.spotShadowMap.length=x,n.directionalShadowMatrix.length=M,n.pointShadowMatrix.length=v,n.spotLightMatrix.length=x+I-A,n.spotLightMap.length=I,n.numSpotLightShadowsWithMaps=A,n.numLightProbes=T,P.directionalLength=f,P.pointLength=g,P.spotLength=_,P.rectAreaLength=m,P.hemiLength=p,P.numDirectionalShadows=M,P.numPointShadows=v,P.numSpotShadows=x,P.numSpotMaps=I,P.numLightProbes=T,n.version=Hx++)}function c(l,u){let h=0,d=0,f=0,g=0,_=0;const m=u.matrixWorldInverse;for(let p=0,M=l.length;p<M;p++){const v=l[p];if(v.isDirectionalLight){const x=n.directional[h];x.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),x.direction.sub(s),x.direction.transformDirection(m),h++}else if(v.isSpotLight){const x=n.spot[f];x.position.setFromMatrixPosition(v.matrixWorld),x.position.applyMatrix4(m),x.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),x.direction.sub(s),x.direction.transformDirection(m),f++}else if(v.isRectAreaLight){const x=n.rectArea[g];x.position.setFromMatrixPosition(v.matrixWorld),x.position.applyMatrix4(m),o.identity(),r.copy(v.matrixWorld),r.premultiply(m),o.extractRotation(r),x.halfWidth.set(v.width*.5,0,0),x.halfHeight.set(0,v.height*.5,0),x.halfWidth.applyMatrix4(o),x.halfHeight.applyMatrix4(o),g++}else if(v.isPointLight){const x=n.point[d];x.position.setFromMatrixPosition(v.matrixWorld),x.position.applyMatrix4(m),d++}else if(v.isHemisphereLight){const x=n.hemi[_];x.direction.setFromMatrixPosition(v.matrixWorld),x.direction.transformDirection(m),_++}}}return{setup:a,setupView:c,state:n}}function eh(i){const e=new Gx(i),t=[],n=[];function s(u){l.camera=u,t.length=0,n.length=0}function r(u){t.push(u)}function o(u){n.push(u)}function a(){e.setup(t)}function c(u){e.setupView(t,u)}const l={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:l,setupLights:a,setupLightsView:c,pushLight:r,pushShadow:o}}function Wx(i){let e=new WeakMap;function t(s,r=0){const o=e.get(s);let a;return o===void 0?(a=new eh(i),e.set(s,[a])):r>=o.length?(a=new eh(i),o.push(a)):a=o[r],a}function n(){e=new WeakMap}return{get:t,dispose:n}}class Xx extends bn{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=Tp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class qx extends bn{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const $x=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Yx=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function jx(i,e,t){let n=new _l;const s=new se,r=new se,o=new at,a=new Xx({depthPacking:Ap}),c=new qx,l={},u=t.maxTextureSize,h={[si]:on,[on]:si,[Bt]:Bt},d=new oi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new se},radius:{value:4}},vertexShader:$x,fragmentShader:Yx}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const g=new Tt;g.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new G(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=cd;let p=this.type;this.render=function(A,T,P){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||A.length===0)return;const b=i.getRenderTarget(),w=i.getActiveCubeFace(),D=i.getActiveMipmapLevel(),z=i.state;z.setBlending(bi),z.buffers.color.setClear(1,1,1,1),z.buffers.depth.setTest(!0),z.setScissorTest(!1);const O=p!==Jn&&this.type===Jn,Y=p===Jn&&this.type!==Jn;for(let q=0,j=A.length;q<j;q++){const Q=A[q],W=Q.shadow;if(W===void 0){console.warn("THREE.WebGLShadowMap:",Q,"has no shadow.");continue}if(W.autoUpdate===!1&&W.needsUpdate===!1)continue;s.copy(W.mapSize);const le=W.getFrameExtents();if(s.multiply(le),r.copy(W.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/le.x),s.x=r.x*le.x,W.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/le.y),s.y=r.y*le.y,W.mapSize.y=r.y)),W.map===null||O===!0||Y===!0){const Me=this.type!==Jn?{minFilter:en,magFilter:en}:{};W.map!==null&&W.map.dispose(),W.map=new Ki(s.x,s.y,Me),W.map.texture.name=Q.name+".shadowMap",W.camera.updateProjectionMatrix()}i.setRenderTarget(W.map),i.clear();const pe=W.getViewportCount();for(let Me=0;Me<pe;Me++){const Le=W.getViewport(Me);o.set(r.x*Le.x,r.y*Le.y,r.x*Le.z,r.y*Le.w),z.viewport(o),W.updateMatrices(Q,Me),n=W.getFrustum(),x(T,P,W.camera,Q,this.type)}W.isPointLightShadow!==!0&&this.type===Jn&&M(W,P),W.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(b,w,D)};function M(A,T){const P=e.update(_);d.defines.VSM_SAMPLES!==A.blurSamples&&(d.defines.VSM_SAMPLES=A.blurSamples,f.defines.VSM_SAMPLES=A.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),A.mapPass===null&&(A.mapPass=new Ki(s.x,s.y)),d.uniforms.shadow_pass.value=A.map.texture,d.uniforms.resolution.value=A.mapSize,d.uniforms.radius.value=A.radius,i.setRenderTarget(A.mapPass),i.clear(),i.renderBufferDirect(T,null,P,d,_,null),f.uniforms.shadow_pass.value=A.mapPass.texture,f.uniforms.resolution.value=A.mapSize,f.uniforms.radius.value=A.radius,i.setRenderTarget(A.map),i.clear(),i.renderBufferDirect(T,null,P,f,_,null)}function v(A,T,P,b){let w=null;const D=P.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(D!==void 0)w=D;else if(w=P.isPointLight===!0?c:a,i.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0){const z=w.uuid,O=T.uuid;let Y=l[z];Y===void 0&&(Y={},l[z]=Y);let q=Y[O];q===void 0&&(q=w.clone(),Y[O]=q,T.addEventListener("dispose",I)),w=q}if(w.visible=T.visible,w.wireframe=T.wireframe,b===Jn?w.side=T.shadowSide!==null?T.shadowSide:T.side:w.side=T.shadowSide!==null?T.shadowSide:h[T.side],w.alphaMap=T.alphaMap,w.alphaTest=T.alphaTest,w.map=T.map,w.clipShadows=T.clipShadows,w.clippingPlanes=T.clippingPlanes,w.clipIntersection=T.clipIntersection,w.displacementMap=T.displacementMap,w.displacementScale=T.displacementScale,w.displacementBias=T.displacementBias,w.wireframeLinewidth=T.wireframeLinewidth,w.linewidth=T.linewidth,P.isPointLight===!0&&w.isMeshDistanceMaterial===!0){const z=i.properties.get(w);z.light=P}return w}function x(A,T,P,b,w){if(A.visible===!1)return;if(A.layers.test(T.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&w===Jn)&&(!A.frustumCulled||n.intersectsObject(A))){A.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,A.matrixWorld);const O=e.update(A),Y=A.material;if(Array.isArray(Y)){const q=O.groups;for(let j=0,Q=q.length;j<Q;j++){const W=q[j],le=Y[W.materialIndex];if(le&&le.visible){const pe=v(A,le,b,w);A.onBeforeShadow(i,A,T,P,O,pe,W),i.renderBufferDirect(P,null,O,pe,A,W),A.onAfterShadow(i,A,T,P,O,pe,W)}}}else if(Y.visible){const q=v(A,Y,b,w);A.onBeforeShadow(i,A,T,P,O,q,null),i.renderBufferDirect(P,null,O,q,A,null),A.onAfterShadow(i,A,T,P,O,q,null)}}const z=A.children;for(let O=0,Y=z.length;O<Y;O++)x(z[O],T,P,b,w)}function I(A){A.target.removeEventListener("dispose",I);for(const P in l){const b=l[P],w=A.target.uuid;w in b&&(b[w].dispose(),delete b[w])}}}const Kx={[tc]:nc,[ic]:oc,[sc]:ac,[Ps]:rc,[nc]:tc,[oc]:ic,[ac]:sc,[rc]:Ps};function Zx(i,e){function t(){let U=!1;const ge=new at;let Z=null;const ne=new at(0,0,0,0);return{setMask:function(ye){Z!==ye&&!U&&(i.colorMask(ye,ye,ye,ye),Z=ye)},setLocked:function(ye){U=ye},setClear:function(ye,xe,Ye,At,Gt){Gt===!0&&(ye*=At,xe*=At,Ye*=At),ge.set(ye,xe,Ye,At),ne.equals(ge)===!1&&(i.clearColor(ye,xe,Ye,At),ne.copy(ge))},reset:function(){U=!1,Z=null,ne.set(-1,0,0,0)}}}function n(){let U=!1,ge=!1,Z=null,ne=null,ye=null;return{setReversed:function(xe){if(ge!==xe){const Ye=e.get("EXT_clip_control");ge?Ye.clipControlEXT(Ye.LOWER_LEFT_EXT,Ye.ZERO_TO_ONE_EXT):Ye.clipControlEXT(Ye.LOWER_LEFT_EXT,Ye.NEGATIVE_ONE_TO_ONE_EXT);const At=ye;ye=null,this.setClear(At)}ge=xe},getReversed:function(){return ge},setTest:function(xe){xe?X(i.DEPTH_TEST):he(i.DEPTH_TEST)},setMask:function(xe){Z!==xe&&!U&&(i.depthMask(xe),Z=xe)},setFunc:function(xe){if(ge&&(xe=Kx[xe]),ne!==xe){switch(xe){case tc:i.depthFunc(i.NEVER);break;case nc:i.depthFunc(i.ALWAYS);break;case ic:i.depthFunc(i.LESS);break;case Ps:i.depthFunc(i.LEQUAL);break;case sc:i.depthFunc(i.EQUAL);break;case rc:i.depthFunc(i.GEQUAL);break;case oc:i.depthFunc(i.GREATER);break;case ac:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ne=xe}},setLocked:function(xe){U=xe},setClear:function(xe){ye!==xe&&(ge&&(xe=1-xe),i.clearDepth(xe),ye=xe)},reset:function(){U=!1,Z=null,ne=null,ye=null,ge=!1}}}function s(){let U=!1,ge=null,Z=null,ne=null,ye=null,xe=null,Ye=null,At=null,Gt=null;return{setTest:function(ut){U||(ut?X(i.STENCIL_TEST):he(i.STENCIL_TEST))},setMask:function(ut){ge!==ut&&!U&&(i.stencilMask(ut),ge=ut)},setFunc:function(ut,En,Wn){(Z!==ut||ne!==En||ye!==Wn)&&(i.stencilFunc(ut,En,Wn),Z=ut,ne=En,ye=Wn)},setOp:function(ut,En,Wn){(xe!==ut||Ye!==En||At!==Wn)&&(i.stencilOp(ut,En,Wn),xe=ut,Ye=En,At=Wn)},setLocked:function(ut){U=ut},setClear:function(ut){Gt!==ut&&(i.clearStencil(ut),Gt=ut)},reset:function(){U=!1,ge=null,Z=null,ne=null,ye=null,xe=null,Ye=null,At=null,Gt=null}}}const r=new t,o=new n,a=new s,c=new WeakMap,l=new WeakMap;let u={},h={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,M=null,v=null,x=null,I=null,A=null,T=new Fe(0,0,0),P=0,b=!1,w=null,D=null,z=null,O=null,Y=null;const q=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let j=!1,Q=0;const W=i.getParameter(i.VERSION);W.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(W)[1]),j=Q>=1):W.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(W)[1]),j=Q>=2);let le=null,pe={};const Me=i.getParameter(i.SCISSOR_BOX),Le=i.getParameter(i.VIEWPORT),qe=new at().fromArray(Me),J=new at().fromArray(Le);function ae(U,ge,Z,ne){const ye=new Uint8Array(4),xe=i.createTexture();i.bindTexture(U,xe),i.texParameteri(U,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(U,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ye=0;Ye<Z;Ye++)U===i.TEXTURE_3D||U===i.TEXTURE_2D_ARRAY?i.texImage3D(ge,0,i.RGBA,1,1,ne,0,i.RGBA,i.UNSIGNED_BYTE,ye):i.texImage2D(ge+Ye,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ye);return xe}const we={};we[i.TEXTURE_2D]=ae(i.TEXTURE_2D,i.TEXTURE_2D,1),we[i.TEXTURE_CUBE_MAP]=ae(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),we[i.TEXTURE_2D_ARRAY]=ae(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),we[i.TEXTURE_3D]=ae(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),X(i.DEPTH_TEST),o.setFunc(Ps),ie(!1),_e(tu),X(i.CULL_FACE),C(bi);function X(U){u[U]!==!0&&(i.enable(U),u[U]=!0)}function he(U){u[U]!==!1&&(i.disable(U),u[U]=!1)}function Ae(U,ge){return h[U]!==ge?(i.bindFramebuffer(U,ge),h[U]=ge,U===i.DRAW_FRAMEBUFFER&&(h[i.FRAMEBUFFER]=ge),U===i.FRAMEBUFFER&&(h[i.DRAW_FRAMEBUFFER]=ge),!0):!1}function Ie(U,ge){let Z=f,ne=!1;if(U){Z=d.get(ge),Z===void 0&&(Z=[],d.set(ge,Z));const ye=U.textures;if(Z.length!==ye.length||Z[0]!==i.COLOR_ATTACHMENT0){for(let xe=0,Ye=ye.length;xe<Ye;xe++)Z[xe]=i.COLOR_ATTACHMENT0+xe;Z.length=ye.length,ne=!0}}else Z[0]!==i.BACK&&(Z[0]=i.BACK,ne=!0);ne&&i.drawBuffers(Z)}function Je(U){return g!==U?(i.useProgram(U),g=U,!0):!1}const ee={[Wi]:i.FUNC_ADD,[Jf]:i.FUNC_SUBTRACT,[Qf]:i.FUNC_REVERSE_SUBTRACT};ee[ep]=i.MIN,ee[tp]=i.MAX;const re={[np]:i.ZERO,[ip]:i.ONE,[sp]:i.SRC_COLOR,[Qa]:i.SRC_ALPHA,[up]:i.SRC_ALPHA_SATURATE,[cp]:i.DST_COLOR,[op]:i.DST_ALPHA,[rp]:i.ONE_MINUS_SRC_COLOR,[ec]:i.ONE_MINUS_SRC_ALPHA,[lp]:i.ONE_MINUS_DST_COLOR,[ap]:i.ONE_MINUS_DST_ALPHA,[hp]:i.CONSTANT_COLOR,[dp]:i.ONE_MINUS_CONSTANT_COLOR,[fp]:i.CONSTANT_ALPHA,[pp]:i.ONE_MINUS_CONSTANT_ALPHA};function C(U,ge,Z,ne,ye,xe,Ye,At,Gt,ut){if(U===bi){_===!0&&(he(i.BLEND),_=!1);return}if(_===!1&&(X(i.BLEND),_=!0),U!==Zf){if(U!==m||ut!==b){if((p!==Wi||x!==Wi)&&(i.blendEquation(i.FUNC_ADD),p=Wi,x=Wi),ut)switch(U){case $i:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Cs:i.blendFunc(i.ONE,i.ONE);break;case nu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case iu:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case $i:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Cs:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case nu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case iu:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}M=null,v=null,I=null,A=null,T.set(0,0,0),P=0,m=U,b=ut}return}ye=ye||ge,xe=xe||Z,Ye=Ye||ne,(ge!==p||ye!==x)&&(i.blendEquationSeparate(ee[ge],ee[ye]),p=ge,x=ye),(Z!==M||ne!==v||xe!==I||Ye!==A)&&(i.blendFuncSeparate(re[Z],re[ne],re[xe],re[Ye]),M=Z,v=ne,I=xe,A=Ye),(At.equals(T)===!1||Gt!==P)&&(i.blendColor(At.r,At.g,At.b,Gt),T.copy(At),P=Gt),m=U,b=!1}function Te(U,ge){U.side===Bt?he(i.CULL_FACE):X(i.CULL_FACE);let Z=U.side===on;ge&&(Z=!Z),ie(Z),U.blending===$i&&U.transparent===!1?C(bi):C(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),o.setFunc(U.depthFunc),o.setTest(U.depthTest),o.setMask(U.depthWrite),r.setMask(U.colorWrite);const ne=U.stencilWrite;a.setTest(ne),ne&&(a.setMask(U.stencilWriteMask),a.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),a.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),Oe(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?X(i.SAMPLE_ALPHA_TO_COVERAGE):he(i.SAMPLE_ALPHA_TO_COVERAGE)}function ie(U){w!==U&&(U?i.frontFace(i.CW):i.frontFace(i.CCW),w=U)}function _e(U){U!==jf?(X(i.CULL_FACE),U!==D&&(U===tu?i.cullFace(i.BACK):U===Kf?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):he(i.CULL_FACE),D=U}function ue(U){U!==z&&(j&&i.lineWidth(U),z=U)}function Oe(U,ge,Z){U?(X(i.POLYGON_OFFSET_FILL),(O!==ge||Y!==Z)&&(i.polygonOffset(ge,Z),O=ge,Y=Z)):he(i.POLYGON_OFFSET_FILL)}function L(U){U?X(i.SCISSOR_TEST):he(i.SCISSOR_TEST)}function S(U){U===void 0&&(U=i.TEXTURE0+q-1),le!==U&&(i.activeTexture(U),le=U)}function y(U,ge,Z){Z===void 0&&(le===null?Z=i.TEXTURE0+q-1:Z=le);let ne=pe[Z];ne===void 0&&(ne={type:void 0,texture:void 0},pe[Z]=ne),(ne.type!==U||ne.texture!==ge)&&(le!==Z&&(i.activeTexture(Z),le=Z),i.bindTexture(U,ge||we[U]),ne.type=U,ne.texture=ge)}function N(){const U=pe[le];U!==void 0&&U.type!==void 0&&(i.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function B(){try{i.compressedTexImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function K(){try{i.compressedTexImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function $(){try{i.texSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ee(){try{i.texSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function de(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Se(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function $e(){try{i.texStorage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function oe(){try{i.texStorage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function me(){try{i.texImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ue(){try{i.texImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ge(U){qe.equals(U)===!1&&(i.scissor(U.x,U.y,U.z,U.w),qe.copy(U))}function be(U){J.equals(U)===!1&&(i.viewport(U.x,U.y,U.z,U.w),J.copy(U))}function it(U,ge){let Z=l.get(ge);Z===void 0&&(Z=new WeakMap,l.set(ge,Z));let ne=Z.get(U);ne===void 0&&(ne=i.getUniformBlockIndex(ge,U.name),Z.set(U,ne))}function Qe(U,ge){const ne=l.get(ge).get(U);c.get(ge)!==ne&&(i.uniformBlockBinding(ge,ne,U.__bindingPointIndex),c.set(ge,ne))}function _t(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),u={},le=null,pe={},h={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,M=null,v=null,x=null,I=null,A=null,T=new Fe(0,0,0),P=0,b=!1,w=null,D=null,z=null,O=null,Y=null,qe.set(0,0,i.canvas.width,i.canvas.height),J.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:X,disable:he,bindFramebuffer:Ae,drawBuffers:Ie,useProgram:Je,setBlending:C,setMaterial:Te,setFlipSided:ie,setCullFace:_e,setLineWidth:ue,setPolygonOffset:Oe,setScissorTest:L,activeTexture:S,bindTexture:y,unbindTexture:N,compressedTexImage2D:B,compressedTexImage3D:K,texImage2D:me,texImage3D:Ue,updateUBOMapping:it,uniformBlockBinding:Qe,texStorage2D:$e,texStorage3D:oe,texSubImage2D:$,texSubImage3D:Ee,compressedTexSubImage2D:de,compressedTexSubImage3D:Se,scissor:Ge,viewport:be,reset:_t}}function th(i,e,t,n){const s=Jx(n);switch(t){case gd:return i*e;case xd:return i*e;case vd:return i*e*2;case ul:return i*e/s.components*s.byteLength;case hl:return i*e/s.components*s.byteLength;case yd:return i*e*2/s.components*s.byteLength;case dl:return i*e*2/s.components*s.byteLength;case _d:return i*e*3/s.components*s.byteLength;case Mn:return i*e*4/s.components*s.byteLength;case fl:return i*e*4/s.components*s.byteLength;case To:case Ao:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Ro:case Co:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case hc:case fc:return Math.max(i,16)*Math.max(e,8)/4;case uc:case dc:return Math.max(i,8)*Math.max(e,8)/2;case pc:case mc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case gc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case _c:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case xc:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case vc:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case yc:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Mc:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Sc:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case wc:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case bc:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Ec:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Tc:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Ac:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Rc:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Cc:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Pc:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Po:case Lc:case Ic:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Md:case Dc:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Nc:case Uc:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Jx(i){switch(i){case ri:case fd:return{byteLength:1,components:1};case yr:case pd:case Ir:return{byteLength:2,components:1};case cl:case ll:return{byteLength:2,components:4};case ji:case al:case Dn:return{byteLength:4,components:1};case md:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function Qx(i,e,t,n,s,r,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new se,u=new WeakMap;let h;const d=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(S,y){return f?new OffscreenCanvas(S,y):wr("canvas")}function _(S,y,N){let B=1;const K=L(S);if((K.width>N||K.height>N)&&(B=N/Math.max(K.width,K.height)),B<1)if(typeof HTMLImageElement<"u"&&S instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&S instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&S instanceof ImageBitmap||typeof VideoFrame<"u"&&S instanceof VideoFrame){const $=Math.floor(B*K.width),Ee=Math.floor(B*K.height);h===void 0&&(h=g($,Ee));const de=y?g($,Ee):h;return de.width=$,de.height=Ee,de.getContext("2d").drawImage(S,0,0,$,Ee),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+K.width+"x"+K.height+") to ("+$+"x"+Ee+")."),de}else return"data"in S&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+K.width+"x"+K.height+")."),S;return S}function m(S){return S.generateMipmaps}function p(S){i.generateMipmap(S)}function M(S){return S.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:S.isWebGL3DRenderTarget?i.TEXTURE_3D:S.isWebGLArrayRenderTarget||S.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function v(S,y,N,B,K=!1){if(S!==null){if(i[S]!==void 0)return i[S];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+S+"'")}let $=y;if(y===i.RED&&(N===i.FLOAT&&($=i.R32F),N===i.HALF_FLOAT&&($=i.R16F),N===i.UNSIGNED_BYTE&&($=i.R8)),y===i.RED_INTEGER&&(N===i.UNSIGNED_BYTE&&($=i.R8UI),N===i.UNSIGNED_SHORT&&($=i.R16UI),N===i.UNSIGNED_INT&&($=i.R32UI),N===i.BYTE&&($=i.R8I),N===i.SHORT&&($=i.R16I),N===i.INT&&($=i.R32I)),y===i.RG&&(N===i.FLOAT&&($=i.RG32F),N===i.HALF_FLOAT&&($=i.RG16F),N===i.UNSIGNED_BYTE&&($=i.RG8)),y===i.RG_INTEGER&&(N===i.UNSIGNED_BYTE&&($=i.RG8UI),N===i.UNSIGNED_SHORT&&($=i.RG16UI),N===i.UNSIGNED_INT&&($=i.RG32UI),N===i.BYTE&&($=i.RG8I),N===i.SHORT&&($=i.RG16I),N===i.INT&&($=i.RG32I)),y===i.RGB_INTEGER&&(N===i.UNSIGNED_BYTE&&($=i.RGB8UI),N===i.UNSIGNED_SHORT&&($=i.RGB16UI),N===i.UNSIGNED_INT&&($=i.RGB32UI),N===i.BYTE&&($=i.RGB8I),N===i.SHORT&&($=i.RGB16I),N===i.INT&&($=i.RGB32I)),y===i.RGBA_INTEGER&&(N===i.UNSIGNED_BYTE&&($=i.RGBA8UI),N===i.UNSIGNED_SHORT&&($=i.RGBA16UI),N===i.UNSIGNED_INT&&($=i.RGBA32UI),N===i.BYTE&&($=i.RGBA8I),N===i.SHORT&&($=i.RGBA16I),N===i.INT&&($=i.RGBA32I)),y===i.RGB&&N===i.UNSIGNED_INT_5_9_9_9_REV&&($=i.RGB9_E5),y===i.RGBA){const Ee=K?qo:st.getTransfer(B);N===i.FLOAT&&($=i.RGBA32F),N===i.HALF_FLOAT&&($=i.RGBA16F),N===i.UNSIGNED_BYTE&&($=Ee===pt?i.SRGB8_ALPHA8:i.RGBA8),N===i.UNSIGNED_SHORT_4_4_4_4&&($=i.RGBA4),N===i.UNSIGNED_SHORT_5_5_5_1&&($=i.RGB5_A1)}return($===i.R16F||$===i.R32F||$===i.RG16F||$===i.RG32F||$===i.RGBA16F||$===i.RGBA32F)&&e.get("EXT_color_buffer_float"),$}function x(S,y){let N;return S?y===null||y===ji||y===Ds?N=i.DEPTH24_STENCIL8:y===Dn?N=i.DEPTH32F_STENCIL8:y===yr&&(N=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):y===null||y===ji||y===Ds?N=i.DEPTH_COMPONENT24:y===Dn?N=i.DEPTH_COMPONENT32F:y===yr&&(N=i.DEPTH_COMPONENT16),N}function I(S,y){return m(S)===!0||S.isFramebufferTexture&&S.minFilter!==en&&S.minFilter!==hn?Math.log2(Math.max(y.width,y.height))+1:S.mipmaps!==void 0&&S.mipmaps.length>0?S.mipmaps.length:S.isCompressedTexture&&Array.isArray(S.image)?y.mipmaps.length:1}function A(S){const y=S.target;y.removeEventListener("dispose",A),P(y),y.isVideoTexture&&u.delete(y)}function T(S){const y=S.target;y.removeEventListener("dispose",T),w(y)}function P(S){const y=n.get(S);if(y.__webglInit===void 0)return;const N=S.source,B=d.get(N);if(B){const K=B[y.__cacheKey];K.usedTimes--,K.usedTimes===0&&b(S),Object.keys(B).length===0&&d.delete(N)}n.remove(S)}function b(S){const y=n.get(S);i.deleteTexture(y.__webglTexture);const N=S.source,B=d.get(N);delete B[y.__cacheKey],o.memory.textures--}function w(S){const y=n.get(S);if(S.depthTexture&&(S.depthTexture.dispose(),n.remove(S.depthTexture)),S.isWebGLCubeRenderTarget)for(let B=0;B<6;B++){if(Array.isArray(y.__webglFramebuffer[B]))for(let K=0;K<y.__webglFramebuffer[B].length;K++)i.deleteFramebuffer(y.__webglFramebuffer[B][K]);else i.deleteFramebuffer(y.__webglFramebuffer[B]);y.__webglDepthbuffer&&i.deleteRenderbuffer(y.__webglDepthbuffer[B])}else{if(Array.isArray(y.__webglFramebuffer))for(let B=0;B<y.__webglFramebuffer.length;B++)i.deleteFramebuffer(y.__webglFramebuffer[B]);else i.deleteFramebuffer(y.__webglFramebuffer);if(y.__webglDepthbuffer&&i.deleteRenderbuffer(y.__webglDepthbuffer),y.__webglMultisampledFramebuffer&&i.deleteFramebuffer(y.__webglMultisampledFramebuffer),y.__webglColorRenderbuffer)for(let B=0;B<y.__webglColorRenderbuffer.length;B++)y.__webglColorRenderbuffer[B]&&i.deleteRenderbuffer(y.__webglColorRenderbuffer[B]);y.__webglDepthRenderbuffer&&i.deleteRenderbuffer(y.__webglDepthRenderbuffer)}const N=S.textures;for(let B=0,K=N.length;B<K;B++){const $=n.get(N[B]);$.__webglTexture&&(i.deleteTexture($.__webglTexture),o.memory.textures--),n.remove(N[B])}n.remove(S)}let D=0;function z(){D=0}function O(){const S=D;return S>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+S+" texture units while this GPU supports only "+s.maxTextures),D+=1,S}function Y(S){const y=[];return y.push(S.wrapS),y.push(S.wrapT),y.push(S.wrapR||0),y.push(S.magFilter),y.push(S.minFilter),y.push(S.anisotropy),y.push(S.internalFormat),y.push(S.format),y.push(S.type),y.push(S.generateMipmaps),y.push(S.premultiplyAlpha),y.push(S.flipY),y.push(S.unpackAlignment),y.push(S.colorSpace),y.join()}function q(S,y){const N=n.get(S);if(S.isVideoTexture&&ue(S),S.isRenderTargetTexture===!1&&S.version>0&&N.__version!==S.version){const B=S.image;if(B===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(B.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{J(N,S,y);return}}t.bindTexture(i.TEXTURE_2D,N.__webglTexture,i.TEXTURE0+y)}function j(S,y){const N=n.get(S);if(S.version>0&&N.__version!==S.version){J(N,S,y);return}t.bindTexture(i.TEXTURE_2D_ARRAY,N.__webglTexture,i.TEXTURE0+y)}function Q(S,y){const N=n.get(S);if(S.version>0&&N.__version!==S.version){J(N,S,y);return}t.bindTexture(i.TEXTURE_3D,N.__webglTexture,i.TEXTURE0+y)}function W(S,y){const N=n.get(S);if(S.version>0&&N.__version!==S.version){ae(N,S,y);return}t.bindTexture(i.TEXTURE_CUBE_MAP,N.__webglTexture,i.TEXTURE0+y)}const le={[Yi]:i.REPEAT,[Si]:i.CLAMP_TO_EDGE,[No]:i.MIRRORED_REPEAT},pe={[en]:i.NEAREST,[dd]:i.NEAREST_MIPMAP_NEAREST,[hr]:i.NEAREST_MIPMAP_LINEAR,[hn]:i.LINEAR,[Eo]:i.LINEAR_MIPMAP_NEAREST,[ti]:i.LINEAR_MIPMAP_LINEAR},Me={[Cp]:i.NEVER,[Up]:i.ALWAYS,[Pp]:i.LESS,[wd]:i.LEQUAL,[Lp]:i.EQUAL,[Np]:i.GEQUAL,[Ip]:i.GREATER,[Dp]:i.NOTEQUAL};function Le(S,y){if(y.type===Dn&&e.has("OES_texture_float_linear")===!1&&(y.magFilter===hn||y.magFilter===Eo||y.magFilter===hr||y.magFilter===ti||y.minFilter===hn||y.minFilter===Eo||y.minFilter===hr||y.minFilter===ti)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(S,i.TEXTURE_WRAP_S,le[y.wrapS]),i.texParameteri(S,i.TEXTURE_WRAP_T,le[y.wrapT]),(S===i.TEXTURE_3D||S===i.TEXTURE_2D_ARRAY)&&i.texParameteri(S,i.TEXTURE_WRAP_R,le[y.wrapR]),i.texParameteri(S,i.TEXTURE_MAG_FILTER,pe[y.magFilter]),i.texParameteri(S,i.TEXTURE_MIN_FILTER,pe[y.minFilter]),y.compareFunction&&(i.texParameteri(S,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(S,i.TEXTURE_COMPARE_FUNC,Me[y.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(y.magFilter===en||y.minFilter!==hr&&y.minFilter!==ti||y.type===Dn&&e.has("OES_texture_float_linear")===!1)return;if(y.anisotropy>1||n.get(y).__currentAnisotropy){const N=e.get("EXT_texture_filter_anisotropic");i.texParameterf(S,N.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,s.getMaxAnisotropy())),n.get(y).__currentAnisotropy=y.anisotropy}}}function qe(S,y){let N=!1;S.__webglInit===void 0&&(S.__webglInit=!0,y.addEventListener("dispose",A));const B=y.source;let K=d.get(B);K===void 0&&(K={},d.set(B,K));const $=Y(y);if($!==S.__cacheKey){K[$]===void 0&&(K[$]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,N=!0),K[$].usedTimes++;const Ee=K[S.__cacheKey];Ee!==void 0&&(K[S.__cacheKey].usedTimes--,Ee.usedTimes===0&&b(y)),S.__cacheKey=$,S.__webglTexture=K[$].texture}return N}function J(S,y,N){let B=i.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(B=i.TEXTURE_2D_ARRAY),y.isData3DTexture&&(B=i.TEXTURE_3D);const K=qe(S,y),$=y.source;t.bindTexture(B,S.__webglTexture,i.TEXTURE0+N);const Ee=n.get($);if($.version!==Ee.__version||K===!0){t.activeTexture(i.TEXTURE0+N);const de=st.getPrimaries(st.workingColorSpace),Se=y.colorSpace===yi?null:st.getPrimaries(y.colorSpace),$e=y.colorSpace===yi||de===Se?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,y.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,y.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,$e);let oe=_(y.image,!1,s.maxTextureSize);oe=Oe(y,oe);const me=r.convert(y.format,y.colorSpace),Ue=r.convert(y.type);let Ge=v(y.internalFormat,me,Ue,y.colorSpace,y.isVideoTexture);Le(B,y);let be;const it=y.mipmaps,Qe=y.isVideoTexture!==!0,_t=Ee.__version===void 0||K===!0,U=$.dataReady,ge=I(y,oe);if(y.isDepthTexture)Ge=x(y.format===Ns,y.type),_t&&(Qe?t.texStorage2D(i.TEXTURE_2D,1,Ge,oe.width,oe.height):t.texImage2D(i.TEXTURE_2D,0,Ge,oe.width,oe.height,0,me,Ue,null));else if(y.isDataTexture)if(it.length>0){Qe&&_t&&t.texStorage2D(i.TEXTURE_2D,ge,Ge,it[0].width,it[0].height);for(let Z=0,ne=it.length;Z<ne;Z++)be=it[Z],Qe?U&&t.texSubImage2D(i.TEXTURE_2D,Z,0,0,be.width,be.height,me,Ue,be.data):t.texImage2D(i.TEXTURE_2D,Z,Ge,be.width,be.height,0,me,Ue,be.data);y.generateMipmaps=!1}else Qe?(_t&&t.texStorage2D(i.TEXTURE_2D,ge,Ge,oe.width,oe.height),U&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,oe.width,oe.height,me,Ue,oe.data)):t.texImage2D(i.TEXTURE_2D,0,Ge,oe.width,oe.height,0,me,Ue,oe.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){Qe&&_t&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ge,Ge,it[0].width,it[0].height,oe.depth);for(let Z=0,ne=it.length;Z<ne;Z++)if(be=it[Z],y.format!==Mn)if(me!==null)if(Qe){if(U)if(y.layerUpdates.size>0){const ye=th(be.width,be.height,y.format,y.type);for(const xe of y.layerUpdates){const Ye=be.data.subarray(xe*ye/be.data.BYTES_PER_ELEMENT,(xe+1)*ye/be.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,Z,0,0,xe,be.width,be.height,1,me,Ye)}y.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,Z,0,0,0,be.width,be.height,oe.depth,me,be.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,Z,Ge,be.width,be.height,oe.depth,0,be.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Qe?U&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,Z,0,0,0,be.width,be.height,oe.depth,me,Ue,be.data):t.texImage3D(i.TEXTURE_2D_ARRAY,Z,Ge,be.width,be.height,oe.depth,0,me,Ue,be.data)}else{Qe&&_t&&t.texStorage2D(i.TEXTURE_2D,ge,Ge,it[0].width,it[0].height);for(let Z=0,ne=it.length;Z<ne;Z++)be=it[Z],y.format!==Mn?me!==null?Qe?U&&t.compressedTexSubImage2D(i.TEXTURE_2D,Z,0,0,be.width,be.height,me,be.data):t.compressedTexImage2D(i.TEXTURE_2D,Z,Ge,be.width,be.height,0,be.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Qe?U&&t.texSubImage2D(i.TEXTURE_2D,Z,0,0,be.width,be.height,me,Ue,be.data):t.texImage2D(i.TEXTURE_2D,Z,Ge,be.width,be.height,0,me,Ue,be.data)}else if(y.isDataArrayTexture)if(Qe){if(_t&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ge,Ge,oe.width,oe.height,oe.depth),U)if(y.layerUpdates.size>0){const Z=th(oe.width,oe.height,y.format,y.type);for(const ne of y.layerUpdates){const ye=oe.data.subarray(ne*Z/oe.data.BYTES_PER_ELEMENT,(ne+1)*Z/oe.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,ne,oe.width,oe.height,1,me,Ue,ye)}y.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,oe.width,oe.height,oe.depth,me,Ue,oe.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Ge,oe.width,oe.height,oe.depth,0,me,Ue,oe.data);else if(y.isData3DTexture)Qe?(_t&&t.texStorage3D(i.TEXTURE_3D,ge,Ge,oe.width,oe.height,oe.depth),U&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,oe.width,oe.height,oe.depth,me,Ue,oe.data)):t.texImage3D(i.TEXTURE_3D,0,Ge,oe.width,oe.height,oe.depth,0,me,Ue,oe.data);else if(y.isFramebufferTexture){if(_t)if(Qe)t.texStorage2D(i.TEXTURE_2D,ge,Ge,oe.width,oe.height);else{let Z=oe.width,ne=oe.height;for(let ye=0;ye<ge;ye++)t.texImage2D(i.TEXTURE_2D,ye,Ge,Z,ne,0,me,Ue,null),Z>>=1,ne>>=1}}else if(it.length>0){if(Qe&&_t){const Z=L(it[0]);t.texStorage2D(i.TEXTURE_2D,ge,Ge,Z.width,Z.height)}for(let Z=0,ne=it.length;Z<ne;Z++)be=it[Z],Qe?U&&t.texSubImage2D(i.TEXTURE_2D,Z,0,0,me,Ue,be):t.texImage2D(i.TEXTURE_2D,Z,Ge,me,Ue,be);y.generateMipmaps=!1}else if(Qe){if(_t){const Z=L(oe);t.texStorage2D(i.TEXTURE_2D,ge,Ge,Z.width,Z.height)}U&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,me,Ue,oe)}else t.texImage2D(i.TEXTURE_2D,0,Ge,me,Ue,oe);m(y)&&p(B),Ee.__version=$.version,y.onUpdate&&y.onUpdate(y)}S.__version=y.version}function ae(S,y,N){if(y.image.length!==6)return;const B=qe(S,y),K=y.source;t.bindTexture(i.TEXTURE_CUBE_MAP,S.__webglTexture,i.TEXTURE0+N);const $=n.get(K);if(K.version!==$.__version||B===!0){t.activeTexture(i.TEXTURE0+N);const Ee=st.getPrimaries(st.workingColorSpace),de=y.colorSpace===yi?null:st.getPrimaries(y.colorSpace),Se=y.colorSpace===yi||Ee===de?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,y.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,y.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Se);const $e=y.isCompressedTexture||y.image[0].isCompressedTexture,oe=y.image[0]&&y.image[0].isDataTexture,me=[];for(let ne=0;ne<6;ne++)!$e&&!oe?me[ne]=_(y.image[ne],!0,s.maxCubemapSize):me[ne]=oe?y.image[ne].image:y.image[ne],me[ne]=Oe(y,me[ne]);const Ue=me[0],Ge=r.convert(y.format,y.colorSpace),be=r.convert(y.type),it=v(y.internalFormat,Ge,be,y.colorSpace),Qe=y.isVideoTexture!==!0,_t=$.__version===void 0||B===!0,U=K.dataReady;let ge=I(y,Ue);Le(i.TEXTURE_CUBE_MAP,y);let Z;if($e){Qe&&_t&&t.texStorage2D(i.TEXTURE_CUBE_MAP,ge,it,Ue.width,Ue.height);for(let ne=0;ne<6;ne++){Z=me[ne].mipmaps;for(let ye=0;ye<Z.length;ye++){const xe=Z[ye];y.format!==Mn?Ge!==null?Qe?U&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye,0,0,xe.width,xe.height,Ge,xe.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye,it,xe.width,xe.height,0,xe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Qe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye,0,0,xe.width,xe.height,Ge,be,xe.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye,it,xe.width,xe.height,0,Ge,be,xe.data)}}}else{if(Z=y.mipmaps,Qe&&_t){Z.length>0&&ge++;const ne=L(me[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,ge,it,ne.width,ne.height)}for(let ne=0;ne<6;ne++)if(oe){Qe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,0,0,me[ne].width,me[ne].height,Ge,be,me[ne].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,it,me[ne].width,me[ne].height,0,Ge,be,me[ne].data);for(let ye=0;ye<Z.length;ye++){const Ye=Z[ye].image[ne].image;Qe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye+1,0,0,Ye.width,Ye.height,Ge,be,Ye.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye+1,it,Ye.width,Ye.height,0,Ge,be,Ye.data)}}else{Qe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,0,0,Ge,be,me[ne]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,it,Ge,be,me[ne]);for(let ye=0;ye<Z.length;ye++){const xe=Z[ye];Qe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye+1,0,0,Ge,be,xe.image[ne]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,ye+1,it,Ge,be,xe.image[ne])}}}m(y)&&p(i.TEXTURE_CUBE_MAP),$.__version=K.version,y.onUpdate&&y.onUpdate(y)}S.__version=y.version}function we(S,y,N,B,K,$){const Ee=r.convert(N.format,N.colorSpace),de=r.convert(N.type),Se=v(N.internalFormat,Ee,de,N.colorSpace),$e=n.get(y),oe=n.get(N);if(oe.__renderTarget=y,!$e.__hasExternalTextures){const me=Math.max(1,y.width>>$),Ue=Math.max(1,y.height>>$);K===i.TEXTURE_3D||K===i.TEXTURE_2D_ARRAY?t.texImage3D(K,$,Se,me,Ue,y.depth,0,Ee,de,null):t.texImage2D(K,$,Se,me,Ue,0,Ee,de,null)}t.bindFramebuffer(i.FRAMEBUFFER,S),_e(y)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,B,K,oe.__webglTexture,0,ie(y)):(K===i.TEXTURE_2D||K>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&K<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,B,K,oe.__webglTexture,$),t.bindFramebuffer(i.FRAMEBUFFER,null)}function X(S,y,N){if(i.bindRenderbuffer(i.RENDERBUFFER,S),y.depthBuffer){const B=y.depthTexture,K=B&&B.isDepthTexture?B.type:null,$=x(y.stencilBuffer,K),Ee=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,de=ie(y);_e(y)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,de,$,y.width,y.height):N?i.renderbufferStorageMultisample(i.RENDERBUFFER,de,$,y.width,y.height):i.renderbufferStorage(i.RENDERBUFFER,$,y.width,y.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Ee,i.RENDERBUFFER,S)}else{const B=y.textures;for(let K=0;K<B.length;K++){const $=B[K],Ee=r.convert($.format,$.colorSpace),de=r.convert($.type),Se=v($.internalFormat,Ee,de,$.colorSpace),$e=ie(y);N&&_e(y)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,$e,Se,y.width,y.height):_e(y)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,$e,Se,y.width,y.height):i.renderbufferStorage(i.RENDERBUFFER,Se,y.width,y.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function he(S,y){if(y&&y.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,S),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const B=n.get(y.depthTexture);B.__renderTarget=y,(!B.__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),q(y.depthTexture,0);const K=B.__webglTexture,$=ie(y);if(y.depthTexture.format===bs)_e(y)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,K,0,$):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,K,0);else if(y.depthTexture.format===Ns)_e(y)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,K,0,$):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,K,0);else throw new Error("Unknown depthTexture format")}function Ae(S){const y=n.get(S),N=S.isWebGLCubeRenderTarget===!0;if(y.__boundDepthTexture!==S.depthTexture){const B=S.depthTexture;if(y.__depthDisposeCallback&&y.__depthDisposeCallback(),B){const K=()=>{delete y.__boundDepthTexture,delete y.__depthDisposeCallback,B.removeEventListener("dispose",K)};B.addEventListener("dispose",K),y.__depthDisposeCallback=K}y.__boundDepthTexture=B}if(S.depthTexture&&!y.__autoAllocateDepthBuffer){if(N)throw new Error("target.depthTexture not supported in Cube render targets");he(y.__webglFramebuffer,S)}else if(N){y.__webglDepthbuffer=[];for(let B=0;B<6;B++)if(t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer[B]),y.__webglDepthbuffer[B]===void 0)y.__webglDepthbuffer[B]=i.createRenderbuffer(),X(y.__webglDepthbuffer[B],S,!1);else{const K=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,$=y.__webglDepthbuffer[B];i.bindRenderbuffer(i.RENDERBUFFER,$),i.framebufferRenderbuffer(i.FRAMEBUFFER,K,i.RENDERBUFFER,$)}}else if(t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer===void 0)y.__webglDepthbuffer=i.createRenderbuffer(),X(y.__webglDepthbuffer,S,!1);else{const B=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,K=y.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,K),i.framebufferRenderbuffer(i.FRAMEBUFFER,B,i.RENDERBUFFER,K)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function Ie(S,y,N){const B=n.get(S);y!==void 0&&we(B.__webglFramebuffer,S,S.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),N!==void 0&&Ae(S)}function Je(S){const y=S.texture,N=n.get(S),B=n.get(y);S.addEventListener("dispose",T);const K=S.textures,$=S.isWebGLCubeRenderTarget===!0,Ee=K.length>1;if(Ee||(B.__webglTexture===void 0&&(B.__webglTexture=i.createTexture()),B.__version=y.version,o.memory.textures++),$){N.__webglFramebuffer=[];for(let de=0;de<6;de++)if(y.mipmaps&&y.mipmaps.length>0){N.__webglFramebuffer[de]=[];for(let Se=0;Se<y.mipmaps.length;Se++)N.__webglFramebuffer[de][Se]=i.createFramebuffer()}else N.__webglFramebuffer[de]=i.createFramebuffer()}else{if(y.mipmaps&&y.mipmaps.length>0){N.__webglFramebuffer=[];for(let de=0;de<y.mipmaps.length;de++)N.__webglFramebuffer[de]=i.createFramebuffer()}else N.__webglFramebuffer=i.createFramebuffer();if(Ee)for(let de=0,Se=K.length;de<Se;de++){const $e=n.get(K[de]);$e.__webglTexture===void 0&&($e.__webglTexture=i.createTexture(),o.memory.textures++)}if(S.samples>0&&_e(S)===!1){N.__webglMultisampledFramebuffer=i.createFramebuffer(),N.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,N.__webglMultisampledFramebuffer);for(let de=0;de<K.length;de++){const Se=K[de];N.__webglColorRenderbuffer[de]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,N.__webglColorRenderbuffer[de]);const $e=r.convert(Se.format,Se.colorSpace),oe=r.convert(Se.type),me=v(Se.internalFormat,$e,oe,Se.colorSpace,S.isXRRenderTarget===!0),Ue=ie(S);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ue,me,S.width,S.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.RENDERBUFFER,N.__webglColorRenderbuffer[de])}i.bindRenderbuffer(i.RENDERBUFFER,null),S.depthBuffer&&(N.__webglDepthRenderbuffer=i.createRenderbuffer(),X(N.__webglDepthRenderbuffer,S,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if($){t.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture),Le(i.TEXTURE_CUBE_MAP,y);for(let de=0;de<6;de++)if(y.mipmaps&&y.mipmaps.length>0)for(let Se=0;Se<y.mipmaps.length;Se++)we(N.__webglFramebuffer[de][Se],S,y,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+de,Se);else we(N.__webglFramebuffer[de],S,y,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0);m(y)&&p(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ee){for(let de=0,Se=K.length;de<Se;de++){const $e=K[de],oe=n.get($e);t.bindTexture(i.TEXTURE_2D,oe.__webglTexture),Le(i.TEXTURE_2D,$e),we(N.__webglFramebuffer,S,$e,i.COLOR_ATTACHMENT0+de,i.TEXTURE_2D,0),m($e)&&p(i.TEXTURE_2D)}t.unbindTexture()}else{let de=i.TEXTURE_2D;if((S.isWebGL3DRenderTarget||S.isWebGLArrayRenderTarget)&&(de=S.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(de,B.__webglTexture),Le(de,y),y.mipmaps&&y.mipmaps.length>0)for(let Se=0;Se<y.mipmaps.length;Se++)we(N.__webglFramebuffer[Se],S,y,i.COLOR_ATTACHMENT0,de,Se);else we(N.__webglFramebuffer,S,y,i.COLOR_ATTACHMENT0,de,0);m(y)&&p(de),t.unbindTexture()}S.depthBuffer&&Ae(S)}function ee(S){const y=S.textures;for(let N=0,B=y.length;N<B;N++){const K=y[N];if(m(K)){const $=M(S),Ee=n.get(K).__webglTexture;t.bindTexture($,Ee),p($),t.unbindTexture()}}}const re=[],C=[];function Te(S){if(S.samples>0){if(_e(S)===!1){const y=S.textures,N=S.width,B=S.height;let K=i.COLOR_BUFFER_BIT;const $=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ee=n.get(S),de=y.length>1;if(de)for(let Se=0;Se<y.length;Se++)t.bindFramebuffer(i.FRAMEBUFFER,Ee.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,Ee.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,Ee.__webglMultisampledFramebuffer),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ee.__webglFramebuffer);for(let Se=0;Se<y.length;Se++){if(S.resolveDepthBuffer&&(S.depthBuffer&&(K|=i.DEPTH_BUFFER_BIT),S.stencilBuffer&&S.resolveStencilBuffer&&(K|=i.STENCIL_BUFFER_BIT)),de){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Ee.__webglColorRenderbuffer[Se]);const $e=n.get(y[Se]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,$e,0)}i.blitFramebuffer(0,0,N,B,0,0,N,B,K,i.NEAREST),c===!0&&(re.length=0,C.length=0,re.push(i.COLOR_ATTACHMENT0+Se),S.depthBuffer&&S.resolveDepthBuffer===!1&&(re.push($),C.push($),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,C)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,re))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),de)for(let Se=0;Se<y.length;Se++){t.bindFramebuffer(i.FRAMEBUFFER,Ee.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.RENDERBUFFER,Ee.__webglColorRenderbuffer[Se]);const $e=n.get(y[Se]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,Ee.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.TEXTURE_2D,$e,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ee.__webglMultisampledFramebuffer)}else if(S.depthBuffer&&S.resolveDepthBuffer===!1&&c){const y=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[y])}}}function ie(S){return Math.min(s.maxSamples,S.samples)}function _e(S){const y=n.get(S);return S.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function ue(S){const y=o.render.frame;u.get(S)!==y&&(u.set(S,y),S.update())}function Oe(S,y){const N=S.colorSpace,B=S.format,K=S.type;return S.isCompressedTexture===!0||S.isVideoTexture===!0||N!==nn&&N!==yi&&(st.getTransfer(N)===pt?(B!==Mn||K!==ri)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",N)),y}function L(S){return typeof HTMLImageElement<"u"&&S instanceof HTMLImageElement?(l.width=S.naturalWidth||S.width,l.height=S.naturalHeight||S.height):typeof VideoFrame<"u"&&S instanceof VideoFrame?(l.width=S.displayWidth,l.height=S.displayHeight):(l.width=S.width,l.height=S.height),l}this.allocateTextureUnit=O,this.resetTextureUnits=z,this.setTexture2D=q,this.setTexture2DArray=j,this.setTexture3D=Q,this.setTextureCube=W,this.rebindTextures=Ie,this.setupRenderTarget=Je,this.updateRenderTargetMipmap=ee,this.updateMultisampleRenderTarget=Te,this.setupDepthRenderbuffer=Ae,this.setupFrameBufferTexture=we,this.useMultisampledRTT=_e}function ev(i,e){function t(n,s=yi){let r;const o=st.getTransfer(s);if(n===ri)return i.UNSIGNED_BYTE;if(n===cl)return i.UNSIGNED_SHORT_4_4_4_4;if(n===ll)return i.UNSIGNED_SHORT_5_5_5_1;if(n===md)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===fd)return i.BYTE;if(n===pd)return i.SHORT;if(n===yr)return i.UNSIGNED_SHORT;if(n===al)return i.INT;if(n===ji)return i.UNSIGNED_INT;if(n===Dn)return i.FLOAT;if(n===Ir)return i.HALF_FLOAT;if(n===gd)return i.ALPHA;if(n===_d)return i.RGB;if(n===Mn)return i.RGBA;if(n===xd)return i.LUMINANCE;if(n===vd)return i.LUMINANCE_ALPHA;if(n===bs)return i.DEPTH_COMPONENT;if(n===Ns)return i.DEPTH_STENCIL;if(n===ul)return i.RED;if(n===hl)return i.RED_INTEGER;if(n===yd)return i.RG;if(n===dl)return i.RG_INTEGER;if(n===fl)return i.RGBA_INTEGER;if(n===To||n===Ao||n===Ro||n===Co)if(o===pt)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===To)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ao)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Ro)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Co)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===To)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ao)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Ro)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Co)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===uc||n===hc||n===dc||n===fc)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===uc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===hc)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===dc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===fc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===pc||n===mc||n===gc)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===pc||n===mc)return o===pt?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===gc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===_c||n===xc||n===vc||n===yc||n===Mc||n===Sc||n===wc||n===bc||n===Ec||n===Tc||n===Ac||n===Rc||n===Cc||n===Pc)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===_c)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===xc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===vc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===yc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Mc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Sc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===wc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===bc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Ec)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Tc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Ac)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Rc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Cc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Pc)return o===pt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Po||n===Lc||n===Ic)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===Po)return o===pt?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Lc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Ic)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Md||n===Dc||n===Nc||n===Uc)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===Po)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Dc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Nc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Uc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ds?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}class tv extends Qt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class ze extends St{constructor(){super(),this.isGroup=!0,this.type="Group"}}const nv={type:"move"};class Na{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new ze,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new ze,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new ze,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null;const a=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){o=!0;for(const _ of e.hand.values()){const m=t.getJointPose(_,n),p=this._getHandJoint(l,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const u=l.joints["index-finger-tip"],h=l.joints["thumb-tip"],d=u.position.distanceTo(h.position),f=.02,g=.005;l.inputState.pinching&&d>f+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&d<=f-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(nv)))}return a!==null&&(a.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new ze;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const iv=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,sv=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class rv{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){const s=new Nt,r=e.properties.get(s);r.__webglTexture=t.texture,(t.depthNear!=n.depthNear||t.depthFar!=n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new oi({vertexShader:iv,fragmentShader:sv,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new G(new kn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class ov extends Vs{constructor(e,t){super();const n=this;let s=null,r=1,o=null,a="local-floor",c=1,l=null,u=null,h=null,d=null,f=null,g=null;const _=new rv,m=t.getContextAttributes();let p=null,M=null;const v=[],x=[],I=new se;let A=null;const T=new Qt;T.viewport=new at;const P=new Qt;P.viewport=new at;const b=[T,P],w=new tv;let D=null,z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let ae=v[J];return ae===void 0&&(ae=new Na,v[J]=ae),ae.getTargetRaySpace()},this.getControllerGrip=function(J){let ae=v[J];return ae===void 0&&(ae=new Na,v[J]=ae),ae.getGripSpace()},this.getHand=function(J){let ae=v[J];return ae===void 0&&(ae=new Na,v[J]=ae),ae.getHandSpace()};function O(J){const ae=x.indexOf(J.inputSource);if(ae===-1)return;const we=v[ae];we!==void 0&&(we.update(J.inputSource,J.frame,l||o),we.dispatchEvent({type:J.type,data:J.inputSource}))}function Y(){s.removeEventListener("select",O),s.removeEventListener("selectstart",O),s.removeEventListener("selectend",O),s.removeEventListener("squeeze",O),s.removeEventListener("squeezestart",O),s.removeEventListener("squeezeend",O),s.removeEventListener("end",Y),s.removeEventListener("inputsourceschange",q);for(let J=0;J<v.length;J++){const ae=x[J];ae!==null&&(x[J]=null,v[J].disconnect(ae))}D=null,z=null,_.reset(),e.setRenderTarget(p),f=null,d=null,h=null,s=null,M=null,qe.stop(),n.isPresenting=!1,e.setPixelRatio(A),e.setSize(I.width,I.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){r=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){a=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function(J){l=J},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return h},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(J){if(s=J,s!==null){if(p=e.getRenderTarget(),s.addEventListener("select",O),s.addEventListener("selectstart",O),s.addEventListener("selectend",O),s.addEventListener("squeeze",O),s.addEventListener("squeezestart",O),s.addEventListener("squeezeend",O),s.addEventListener("end",Y),s.addEventListener("inputsourceschange",q),m.xrCompatible!==!0&&await t.makeXRCompatible(),A=e.getPixelRatio(),e.getSize(I),s.renderState.layers===void 0){const ae={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,ae),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),M=new Ki(f.framebufferWidth,f.framebufferHeight,{format:Mn,type:ri,colorSpace:e.outputColorSpace,stencilBuffer:m.stencil})}else{let ae=null,we=null,X=null;m.depth&&(X=m.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ae=m.stencil?Ns:bs,we=m.stencil?Ds:ji);const he={colorFormat:t.RGBA8,depthFormat:X,scaleFactor:r};h=new XRWebGLBinding(s,t),d=h.createProjectionLayer(he),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),M=new Ki(d.textureWidth,d.textureHeight,{format:Mn,type:ri,depthTexture:new Ud(d.textureWidth,d.textureHeight,we,void 0,void 0,void 0,void 0,void 0,void 0,ae),stencilBuffer:m.stencil,colorSpace:e.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await s.requestReferenceSpace(a),qe.setContext(s),qe.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function q(J){for(let ae=0;ae<J.removed.length;ae++){const we=J.removed[ae],X=x.indexOf(we);X>=0&&(x[X]=null,v[X].disconnect(we))}for(let ae=0;ae<J.added.length;ae++){const we=J.added[ae];let X=x.indexOf(we);if(X===-1){for(let Ae=0;Ae<v.length;Ae++)if(Ae>=x.length){x.push(we),X=Ae;break}else if(x[Ae]===null){x[Ae]=we,X=Ae;break}if(X===-1)break}const he=v[X];he&&he.connect(we)}}const j=new R,Q=new R;function W(J,ae,we){j.setFromMatrixPosition(ae.matrixWorld),Q.setFromMatrixPosition(we.matrixWorld);const X=j.distanceTo(Q),he=ae.projectionMatrix.elements,Ae=we.projectionMatrix.elements,Ie=he[14]/(he[10]-1),Je=he[14]/(he[10]+1),ee=(he[9]+1)/he[5],re=(he[9]-1)/he[5],C=(he[8]-1)/he[0],Te=(Ae[8]+1)/Ae[0],ie=Ie*C,_e=Ie*Te,ue=X/(-C+Te),Oe=ue*-C;if(ae.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(Oe),J.translateZ(ue),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert(),he[10]===-1)J.projectionMatrix.copy(ae.projectionMatrix),J.projectionMatrixInverse.copy(ae.projectionMatrixInverse);else{const L=Ie+ue,S=Je+ue,y=ie-Oe,N=_e+(X-Oe),B=ee*Je/S*L,K=re*Je/S*L;J.projectionMatrix.makePerspective(y,N,B,K,L,S),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}}function le(J,ae){ae===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(ae.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(s===null)return;let ae=J.near,we=J.far;_.texture!==null&&(_.depthNear>0&&(ae=_.depthNear),_.depthFar>0&&(we=_.depthFar)),w.near=P.near=T.near=ae,w.far=P.far=T.far=we,(D!==w.near||z!==w.far)&&(s.updateRenderState({depthNear:w.near,depthFar:w.far}),D=w.near,z=w.far),T.layers.mask=J.layers.mask|2,P.layers.mask=J.layers.mask|4,w.layers.mask=T.layers.mask|P.layers.mask;const X=J.parent,he=w.cameras;le(w,X);for(let Ae=0;Ae<he.length;Ae++)le(he[Ae],X);he.length===2?W(w,T,P):w.projectionMatrix.copy(T.projectionMatrix),pe(J,w,X)};function pe(J,ae,we){we===null?J.matrix.copy(ae.matrixWorld):(J.matrix.copy(we.matrixWorld),J.matrix.invert(),J.matrix.multiply(ae.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(ae.projectionMatrix),J.projectionMatrixInverse.copy(ae.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=Us*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return w},this.getFoveation=function(){if(!(d===null&&f===null))return c},this.setFoveation=function(J){c=J,d!==null&&(d.fixedFoveation=J),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=J)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(w)};let Me=null;function Le(J,ae){if(u=ae.getViewerPose(l||o),g=ae,u!==null){const we=u.views;f!==null&&(e.setRenderTargetFramebuffer(M,f.framebuffer),e.setRenderTarget(M));let X=!1;we.length!==w.cameras.length&&(w.cameras.length=0,X=!0);for(let Ae=0;Ae<we.length;Ae++){const Ie=we[Ae];let Je=null;if(f!==null)Je=f.getViewport(Ie);else{const re=h.getViewSubImage(d,Ie);Je=re.viewport,Ae===0&&(e.setRenderTargetTextures(M,re.colorTexture,d.ignoreDepthValues?void 0:re.depthStencilTexture),e.setRenderTarget(M))}let ee=b[Ae];ee===void 0&&(ee=new Qt,ee.layers.enable(Ae),ee.viewport=new at,b[Ae]=ee),ee.matrix.fromArray(Ie.transform.matrix),ee.matrix.decompose(ee.position,ee.quaternion,ee.scale),ee.projectionMatrix.fromArray(Ie.projectionMatrix),ee.projectionMatrixInverse.copy(ee.projectionMatrix).invert(),ee.viewport.set(Je.x,Je.y,Je.width,Je.height),Ae===0&&(w.matrix.copy(ee.matrix),w.matrix.decompose(w.position,w.quaternion,w.scale)),X===!0&&w.cameras.push(ee)}const he=s.enabledFeatures;if(he&&he.includes("depth-sensing")){const Ae=h.getDepthInformation(we[0]);Ae&&Ae.isValid&&Ae.texture&&_.init(e,Ae,s.renderState)}}for(let we=0;we<v.length;we++){const X=x[we],he=v[we];X!==null&&he!==void 0&&he.update(X,ae,l||o)}Me&&Me(J,ae),ae.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ae}),g=null}const qe=new Nd;qe.setAnimationLoop(Le),this.setAnimationLoop=function(J){Me=J},this.dispose=function(){}}}const Oi=new fn,av=new He;function cv(i,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Ld(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,M,v,x){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),h(m,p)):p.isMeshPhongMaterial?(r(m,p),u(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,x)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?c(m,p,M,v):p.isSpriteMaterial?l(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===on&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===on&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const M=e.get(p),v=M.envMap,x=M.envMapRotation;v&&(m.envMap.value=v,Oi.copy(x),Oi.x*=-1,Oi.y*=-1,Oi.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(Oi.y*=-1,Oi.z*=-1),m.envMapRotation.value.setFromMatrix4(av.makeRotationFromEuler(Oi)),m.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,M,v){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*M,m.scale.value=v*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function l(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function u(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function h(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,M){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===on&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=M.texture,m.transmissionSamplerSize.value.set(M.width,M.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){const M=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(M.matrixWorld),m.nearDistance.value=M.shadow.camera.near,m.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function lv(i,e,t,n){let s={},r={},o=[];const a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function c(M,v){const x=v.program;n.uniformBlockBinding(M,x)}function l(M,v){let x=s[M.id];x===void 0&&(g(M),x=u(M),s[M.id]=x,M.addEventListener("dispose",m));const I=v.program;n.updateUBOMapping(M,I);const A=e.render.frame;r[M.id]!==A&&(d(M),r[M.id]=A)}function u(M){const v=h();M.__bindingPointIndex=v;const x=i.createBuffer(),I=M.__size,A=M.usage;return i.bindBuffer(i.UNIFORM_BUFFER,x),i.bufferData(i.UNIFORM_BUFFER,I,A),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,v,x),x}function h(){for(let M=0;M<a;M++)if(o.indexOf(M)===-1)return o.push(M),M;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(M){const v=s[M.id],x=M.uniforms,I=M.__cache;i.bindBuffer(i.UNIFORM_BUFFER,v);for(let A=0,T=x.length;A<T;A++){const P=Array.isArray(x[A])?x[A]:[x[A]];for(let b=0,w=P.length;b<w;b++){const D=P[b];if(f(D,A,b,I)===!0){const z=D.__offset,O=Array.isArray(D.value)?D.value:[D.value];let Y=0;for(let q=0;q<O.length;q++){const j=O[q],Q=_(j);typeof j=="number"||typeof j=="boolean"?(D.__data[0]=j,i.bufferSubData(i.UNIFORM_BUFFER,z+Y,D.__data)):j.isMatrix3?(D.__data[0]=j.elements[0],D.__data[1]=j.elements[1],D.__data[2]=j.elements[2],D.__data[3]=0,D.__data[4]=j.elements[3],D.__data[5]=j.elements[4],D.__data[6]=j.elements[5],D.__data[7]=0,D.__data[8]=j.elements[6],D.__data[9]=j.elements[7],D.__data[10]=j.elements[8],D.__data[11]=0):(j.toArray(D.__data,Y),Y+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,z,D.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(M,v,x,I){const A=M.value,T=v+"_"+x;if(I[T]===void 0)return typeof A=="number"||typeof A=="boolean"?I[T]=A:I[T]=A.clone(),!0;{const P=I[T];if(typeof A=="number"||typeof A=="boolean"){if(P!==A)return I[T]=A,!0}else if(P.equals(A)===!1)return P.copy(A),!0}return!1}function g(M){const v=M.uniforms;let x=0;const I=16;for(let T=0,P=v.length;T<P;T++){const b=Array.isArray(v[T])?v[T]:[v[T]];for(let w=0,D=b.length;w<D;w++){const z=b[w],O=Array.isArray(z.value)?z.value:[z.value];for(let Y=0,q=O.length;Y<q;Y++){const j=O[Y],Q=_(j),W=x%I,le=W%Q.boundary,pe=W+le;x+=le,pe!==0&&I-pe<Q.storage&&(x+=I-pe),z.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),z.__offset=x,x+=Q.storage}}}const A=x%I;return A>0&&(x+=I-A),M.__size=x,M.__cache={},this}function _(M){const v={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(v.boundary=4,v.storage=4):M.isVector2?(v.boundary=8,v.storage=8):M.isVector3||M.isColor?(v.boundary=16,v.storage=12):M.isVector4?(v.boundary=16,v.storage=16):M.isMatrix3?(v.boundary=48,v.storage=48):M.isMatrix4?(v.boundary=64,v.storage=64):M.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",M),v}function m(M){const v=M.target;v.removeEventListener("dispose",m);const x=o.indexOf(v.__bindingPointIndex);o.splice(x,1),i.deleteBuffer(s[v.id]),delete s[v.id],delete r[v.id]}function p(){for(const M in s)i.deleteBuffer(s[M]);o=[],s={},r={}}return{bind:c,update:l,dispose:p}}class uv{constructor(e={}){const{canvas:t=Jp(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:h=!1,reverseDepthBuffer:d=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const g=new Uint32Array(4),_=new Int32Array(4);let m=null,p=null;const M=[],v=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Lt,this.toneMapping=Ei,this.toneMappingExposure=1;const x=this;let I=!1,A=0,T=0,P=null,b=-1,w=null;const D=new at,z=new at;let O=null;const Y=new Fe(0);let q=0,j=t.width,Q=t.height,W=1,le=null,pe=null;const Me=new at(0,0,j,Q),Le=new at(0,0,j,Q);let qe=!1;const J=new _l;let ae=!1,we=!1;const X=new He,he=new He,Ae=new R,Ie=new at,Je={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ee=!1;function re(){return P===null?W:1}let C=n;function Te(E,k){return t.getContext(E,k)}try{const E={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${rl}`),t.addEventListener("webglcontextlost",ne,!1),t.addEventListener("webglcontextrestored",ye,!1),t.addEventListener("webglcontextcreationerror",xe,!1),C===null){const k="webgl2";if(C=Te(k,E),C===null)throw Te(k)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(E){throw console.error("THREE.WebGLRenderer: "+E.message),E}let ie,_e,ue,Oe,L,S,y,N,B,K,$,Ee,de,Se,$e,oe,me,Ue,Ge,be,it,Qe,_t,U;function ge(){ie=new m_(C),ie.init(),Qe=new ev(C,ie),_e=new l_(C,ie,e,Qe),ue=new Zx(C,ie),_e.reverseDepthBuffer&&d&&ue.buffers.depth.setReversed(!0),Oe=new x_(C),L=new kx,S=new Qx(C,ie,ue,L,_e,Qe,Oe),y=new h_(x),N=new p_(x),B=new Em(C),_t=new a_(C,B),K=new g_(C,B,Oe,_t),$=new y_(C,K,B,Oe),Ge=new v_(C,_e,S),oe=new u_(L),Ee=new Ux(x,y,N,ie,_e,_t,oe),de=new cv(x,L),Se=new Ox,$e=new Wx(ie),Ue=new o_(x,y,N,ue,$,f,c),me=new jx(x,$,_e),U=new lv(C,Oe,_e,ue),be=new c_(C,ie,Oe),it=new __(C,ie,Oe),Oe.programs=Ee.programs,x.capabilities=_e,x.extensions=ie,x.properties=L,x.renderLists=Se,x.shadowMap=me,x.state=ue,x.info=Oe}ge();const Z=new ov(x,C);this.xr=Z,this.getContext=function(){return C},this.getContextAttributes=function(){return C.getContextAttributes()},this.forceContextLoss=function(){const E=ie.get("WEBGL_lose_context");E&&E.loseContext()},this.forceContextRestore=function(){const E=ie.get("WEBGL_lose_context");E&&E.restoreContext()},this.getPixelRatio=function(){return W},this.setPixelRatio=function(E){E!==void 0&&(W=E,this.setSize(j,Q,!1))},this.getSize=function(E){return E.set(j,Q)},this.setSize=function(E,k,H=!0){if(Z.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}j=E,Q=k,t.width=Math.floor(E*W),t.height=Math.floor(k*W),H===!0&&(t.style.width=E+"px",t.style.height=k+"px"),this.setViewport(0,0,E,k)},this.getDrawingBufferSize=function(E){return E.set(j*W,Q*W).floor()},this.setDrawingBufferSize=function(E,k,H){j=E,Q=k,W=H,t.width=Math.floor(E*H),t.height=Math.floor(k*H),this.setViewport(0,0,E,k)},this.getCurrentViewport=function(E){return E.copy(D)},this.getViewport=function(E){return E.copy(Me)},this.setViewport=function(E,k,H,V){E.isVector4?Me.set(E.x,E.y,E.z,E.w):Me.set(E,k,H,V),ue.viewport(D.copy(Me).multiplyScalar(W).round())},this.getScissor=function(E){return E.copy(Le)},this.setScissor=function(E,k,H,V){E.isVector4?Le.set(E.x,E.y,E.z,E.w):Le.set(E,k,H,V),ue.scissor(z.copy(Le).multiplyScalar(W).round())},this.getScissorTest=function(){return qe},this.setScissorTest=function(E){ue.setScissorTest(qe=E)},this.setOpaqueSort=function(E){le=E},this.setTransparentSort=function(E){pe=E},this.getClearColor=function(E){return E.copy(Ue.getClearColor())},this.setClearColor=function(){Ue.setClearColor.apply(Ue,arguments)},this.getClearAlpha=function(){return Ue.getClearAlpha()},this.setClearAlpha=function(){Ue.setClearAlpha.apply(Ue,arguments)},this.clear=function(E=!0,k=!0,H=!0){let V=0;if(E){let F=!1;if(P!==null){const ce=P.texture.format;F=ce===fl||ce===dl||ce===hl}if(F){const ce=P.texture.type,ve=ce===ri||ce===ji||ce===yr||ce===Ds||ce===cl||ce===ll,Re=Ue.getClearColor(),Ce=Ue.getClearAlpha(),Xe=Re.r,je=Re.g,Pe=Re.b;ve?(g[0]=Xe,g[1]=je,g[2]=Pe,g[3]=Ce,C.clearBufferuiv(C.COLOR,0,g)):(_[0]=Xe,_[1]=je,_[2]=Pe,_[3]=Ce,C.clearBufferiv(C.COLOR,0,_))}else V|=C.COLOR_BUFFER_BIT}k&&(V|=C.DEPTH_BUFFER_BIT),H&&(V|=C.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),C.clear(V)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ne,!1),t.removeEventListener("webglcontextrestored",ye,!1),t.removeEventListener("webglcontextcreationerror",xe,!1),Se.dispose(),$e.dispose(),L.dispose(),y.dispose(),N.dispose(),$.dispose(),_t.dispose(),U.dispose(),Ee.dispose(),Z.dispose(),Z.removeEventListener("sessionstart",$l),Z.removeEventListener("sessionend",Yl),Ii.stop()};function ne(E){E.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),I=!0}function ye(){console.log("THREE.WebGLRenderer: Context Restored."),I=!1;const E=Oe.autoReset,k=me.enabled,H=me.autoUpdate,V=me.needsUpdate,F=me.type;ge(),Oe.autoReset=E,me.enabled=k,me.autoUpdate=H,me.needsUpdate=V,me.type=F}function xe(E){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",E.statusMessage)}function Ye(E){const k=E.target;k.removeEventListener("dispose",Ye),At(k)}function At(E){Gt(E),L.remove(E)}function Gt(E){const k=L.get(E).programs;k!==void 0&&(k.forEach(function(H){Ee.releaseProgram(H)}),E.isShaderMaterial&&Ee.releaseShaderCache(E))}this.renderBufferDirect=function(E,k,H,V,F,ce){k===null&&(k=Je);const ve=F.isMesh&&F.matrixWorld.determinant()<0,Re=Wf(E,k,H,V,F);ue.setMaterial(V,ve);let Ce=H.index,Xe=1;if(V.wireframe===!0){if(Ce=K.getWireframeAttribute(H),Ce===void 0)return;Xe=2}const je=H.drawRange,Pe=H.attributes.position;let ot=je.start*Xe,xt=(je.start+je.count)*Xe;ce!==null&&(ot=Math.max(ot,ce.start*Xe),xt=Math.min(xt,(ce.start+ce.count)*Xe)),Ce!==null?(ot=Math.max(ot,0),xt=Math.min(xt,Ce.count)):Pe!=null&&(ot=Math.max(ot,0),xt=Math.min(xt,Pe.count));const vt=xt-ot;if(vt<0||vt===1/0)return;_t.setup(F,V,Re,H,Ce);let sn,ct=be;if(Ce!==null&&(sn=B.get(Ce),ct=it,ct.setIndex(sn)),F.isMesh)V.wireframe===!0?(ue.setLineWidth(V.wireframeLinewidth*re()),ct.setMode(C.LINES)):ct.setMode(C.TRIANGLES);else if(F.isLine){let Ne=V.linewidth;Ne===void 0&&(Ne=1),ue.setLineWidth(Ne*re()),F.isLineSegments?ct.setMode(C.LINES):F.isLineLoop?ct.setMode(C.LINE_LOOP):ct.setMode(C.LINE_STRIP)}else F.isPoints?ct.setMode(C.POINTS):F.isSprite&&ct.setMode(C.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)ct.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(ie.get("WEBGL_multi_draw"))ct.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{const Ne=F._multiDrawStarts,Xn=F._multiDrawCounts,lt=F._multiDrawCount,Tn=Ce?B.get(Ce).bytesPerElement:1,ns=L.get(V).currentProgram.getUniforms();for(let an=0;an<lt;an++)ns.setValue(C,"_gl_DrawID",an),ct.render(Ne[an]/Tn,Xn[an])}else if(F.isInstancedMesh)ct.renderInstances(ot,vt,F.count);else if(H.isInstancedBufferGeometry){const Ne=H._maxInstanceCount!==void 0?H._maxInstanceCount:1/0,Xn=Math.min(H.instanceCount,Ne);ct.renderInstances(ot,vt,Xn)}else ct.render(ot,vt)};function ut(E,k,H){E.transparent===!0&&E.side===Bt&&E.forceSinglePass===!1?(E.side=on,E.needsUpdate=!0,Br(E,k,H),E.side=si,E.needsUpdate=!0,Br(E,k,H),E.side=Bt):Br(E,k,H)}this.compile=function(E,k,H=null){H===null&&(H=E),p=$e.get(H),p.init(k),v.push(p),H.traverseVisible(function(F){F.isLight&&F.layers.test(k.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),E!==H&&E.traverseVisible(function(F){F.isLight&&F.layers.test(k.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),p.setupLights();const V=new Set;return E.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;const ce=F.material;if(ce)if(Array.isArray(ce))for(let ve=0;ve<ce.length;ve++){const Re=ce[ve];ut(Re,H,F),V.add(Re)}else ut(ce,H,F),V.add(ce)}),v.pop(),p=null,V},this.compileAsync=function(E,k,H=null){const V=this.compile(E,k,H);return new Promise(F=>{function ce(){if(V.forEach(function(ve){L.get(ve).currentProgram.isReady()&&V.delete(ve)}),V.size===0){F(E);return}setTimeout(ce,10)}ie.get("KHR_parallel_shader_compile")!==null?ce():setTimeout(ce,10)})};let En=null;function Wn(E){En&&En(E)}function $l(){Ii.stop()}function Yl(){Ii.start()}const Ii=new Nd;Ii.setAnimationLoop(Wn),typeof self<"u"&&Ii.setContext(self),this.setAnimationLoop=function(E){En=E,Z.setAnimationLoop(E),E===null?Ii.stop():Ii.start()},Z.addEventListener("sessionstart",$l),Z.addEventListener("sessionend",Yl),this.render=function(E,k){if(k!==void 0&&k.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(I===!0)return;if(E.matrixWorldAutoUpdate===!0&&E.updateMatrixWorld(),k.parent===null&&k.matrixWorldAutoUpdate===!0&&k.updateMatrixWorld(),Z.enabled===!0&&Z.isPresenting===!0&&(Z.cameraAutoUpdate===!0&&Z.updateCamera(k),k=Z.getCamera()),E.isScene===!0&&E.onBeforeRender(x,E,k,P),p=$e.get(E,v.length),p.init(k),v.push(p),he.multiplyMatrices(k.projectionMatrix,k.matrixWorldInverse),J.setFromProjectionMatrix(he),we=this.localClippingEnabled,ae=oe.init(this.clippingPlanes,we),m=Se.get(E,M.length),m.init(),M.push(m),Z.enabled===!0&&Z.isPresenting===!0){const ce=x.xr.getDepthSensingMesh();ce!==null&&oa(ce,k,-1/0,x.sortObjects)}oa(E,k,0,x.sortObjects),m.finish(),x.sortObjects===!0&&m.sort(le,pe),ee=Z.enabled===!1||Z.isPresenting===!1||Z.hasDepthSensing()===!1,ee&&Ue.addToRenderList(m,E),this.info.render.frame++,ae===!0&&oe.beginShadows();const H=p.state.shadowsArray;me.render(H,E,k),ae===!0&&oe.endShadows(),this.info.autoReset===!0&&this.info.reset();const V=m.opaque,F=m.transmissive;if(p.setupLights(),k.isArrayCamera){const ce=k.cameras;if(F.length>0)for(let ve=0,Re=ce.length;ve<Re;ve++){const Ce=ce[ve];Kl(V,F,E,Ce)}ee&&Ue.render(E);for(let ve=0,Re=ce.length;ve<Re;ve++){const Ce=ce[ve];jl(m,E,Ce,Ce.viewport)}}else F.length>0&&Kl(V,F,E,k),ee&&Ue.render(E),jl(m,E,k);P!==null&&(S.updateMultisampleRenderTarget(P),S.updateRenderTargetMipmap(P)),E.isScene===!0&&E.onAfterRender(x,E,k),_t.resetDefaultState(),b=-1,w=null,v.pop(),v.length>0?(p=v[v.length-1],ae===!0&&oe.setGlobalState(x.clippingPlanes,p.state.camera)):p=null,M.pop(),M.length>0?m=M[M.length-1]:m=null};function oa(E,k,H,V){if(E.visible===!1)return;if(E.layers.test(k.layers)){if(E.isGroup)H=E.renderOrder;else if(E.isLOD)E.autoUpdate===!0&&E.update(k);else if(E.isLight)p.pushLight(E),E.castShadow&&p.pushShadow(E);else if(E.isSprite){if(!E.frustumCulled||J.intersectsSprite(E)){V&&Ie.setFromMatrixPosition(E.matrixWorld).applyMatrix4(he);const ve=$.update(E),Re=E.material;Re.visible&&m.push(E,ve,Re,H,Ie.z,null)}}else if((E.isMesh||E.isLine||E.isPoints)&&(!E.frustumCulled||J.intersectsObject(E))){const ve=$.update(E),Re=E.material;if(V&&(E.boundingSphere!==void 0?(E.boundingSphere===null&&E.computeBoundingSphere(),Ie.copy(E.boundingSphere.center)):(ve.boundingSphere===null&&ve.computeBoundingSphere(),Ie.copy(ve.boundingSphere.center)),Ie.applyMatrix4(E.matrixWorld).applyMatrix4(he)),Array.isArray(Re)){const Ce=ve.groups;for(let Xe=0,je=Ce.length;Xe<je;Xe++){const Pe=Ce[Xe],ot=Re[Pe.materialIndex];ot&&ot.visible&&m.push(E,ve,ot,H,Ie.z,Pe)}}else Re.visible&&m.push(E,ve,Re,H,Ie.z,null)}}const ce=E.children;for(let ve=0,Re=ce.length;ve<Re;ve++)oa(ce[ve],k,H,V)}function jl(E,k,H,V){const F=E.opaque,ce=E.transmissive,ve=E.transparent;p.setupLightsView(H),ae===!0&&oe.setGlobalState(x.clippingPlanes,H),V&&ue.viewport(D.copy(V)),F.length>0&&Or(F,k,H),ce.length>0&&Or(ce,k,H),ve.length>0&&Or(ve,k,H),ue.buffers.depth.setTest(!0),ue.buffers.depth.setMask(!0),ue.buffers.color.setMask(!0),ue.setPolygonOffset(!1)}function Kl(E,k,H,V){if((H.isScene===!0?H.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[V.id]===void 0&&(p.state.transmissionRenderTarget[V.id]=new Ki(1,1,{generateMipmaps:!0,type:ie.has("EXT_color_buffer_half_float")||ie.has("EXT_color_buffer_float")?Ir:ri,minFilter:ti,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:st.workingColorSpace}));const ce=p.state.transmissionRenderTarget[V.id],ve=V.viewport||D;ce.setSize(ve.z,ve.w);const Re=x.getRenderTarget();x.setRenderTarget(ce),x.getClearColor(Y),q=x.getClearAlpha(),q<1&&x.setClearColor(16777215,.5),x.clear(),ee&&Ue.render(H);const Ce=x.toneMapping;x.toneMapping=Ei;const Xe=V.viewport;if(V.viewport!==void 0&&(V.viewport=void 0),p.setupLightsView(V),ae===!0&&oe.setGlobalState(x.clippingPlanes,V),Or(E,H,V),S.updateMultisampleRenderTarget(ce),S.updateRenderTargetMipmap(ce),ie.has("WEBGL_multisampled_render_to_texture")===!1){let je=!1;for(let Pe=0,ot=k.length;Pe<ot;Pe++){const xt=k[Pe],vt=xt.object,sn=xt.geometry,ct=xt.material,Ne=xt.group;if(ct.side===Bt&&vt.layers.test(V.layers)){const Xn=ct.side;ct.side=on,ct.needsUpdate=!0,Zl(vt,H,V,sn,ct,Ne),ct.side=Xn,ct.needsUpdate=!0,je=!0}}je===!0&&(S.updateMultisampleRenderTarget(ce),S.updateRenderTargetMipmap(ce))}x.setRenderTarget(Re),x.setClearColor(Y,q),Xe!==void 0&&(V.viewport=Xe),x.toneMapping=Ce}function Or(E,k,H){const V=k.isScene===!0?k.overrideMaterial:null;for(let F=0,ce=E.length;F<ce;F++){const ve=E[F],Re=ve.object,Ce=ve.geometry,Xe=V===null?ve.material:V,je=ve.group;Re.layers.test(H.layers)&&Zl(Re,k,H,Ce,Xe,je)}}function Zl(E,k,H,V,F,ce){E.onBeforeRender(x,k,H,V,F,ce),E.modelViewMatrix.multiplyMatrices(H.matrixWorldInverse,E.matrixWorld),E.normalMatrix.getNormalMatrix(E.modelViewMatrix),F.onBeforeRender(x,k,H,V,E,ce),F.transparent===!0&&F.side===Bt&&F.forceSinglePass===!1?(F.side=on,F.needsUpdate=!0,x.renderBufferDirect(H,k,V,F,E,ce),F.side=si,F.needsUpdate=!0,x.renderBufferDirect(H,k,V,F,E,ce),F.side=Bt):x.renderBufferDirect(H,k,V,F,E,ce),E.onAfterRender(x,k,H,V,F,ce)}function Br(E,k,H){k.isScene!==!0&&(k=Je);const V=L.get(E),F=p.state.lights,ce=p.state.shadowsArray,ve=F.state.version,Re=Ee.getParameters(E,F.state,ce,k,H),Ce=Ee.getProgramCacheKey(Re);let Xe=V.programs;V.environment=E.isMeshStandardMaterial?k.environment:null,V.fog=k.fog,V.envMap=(E.isMeshStandardMaterial?N:y).get(E.envMap||V.environment),V.envMapRotation=V.environment!==null&&E.envMap===null?k.environmentRotation:E.envMapRotation,Xe===void 0&&(E.addEventListener("dispose",Ye),Xe=new Map,V.programs=Xe);let je=Xe.get(Ce);if(je!==void 0){if(V.currentProgram===je&&V.lightsStateVersion===ve)return Ql(E,Re),je}else Re.uniforms=Ee.getUniforms(E),E.onBeforeCompile(Re,x),je=Ee.acquireProgram(Re,Ce),Xe.set(Ce,je),V.uniforms=Re.uniforms;const Pe=V.uniforms;return(!E.isShaderMaterial&&!E.isRawShaderMaterial||E.clipping===!0)&&(Pe.clippingPlanes=oe.uniform),Ql(E,Re),V.needsLights=qf(E),V.lightsStateVersion=ve,V.needsLights&&(Pe.ambientLightColor.value=F.state.ambient,Pe.lightProbe.value=F.state.probe,Pe.directionalLights.value=F.state.directional,Pe.directionalLightShadows.value=F.state.directionalShadow,Pe.spotLights.value=F.state.spot,Pe.spotLightShadows.value=F.state.spotShadow,Pe.rectAreaLights.value=F.state.rectArea,Pe.ltc_1.value=F.state.rectAreaLTC1,Pe.ltc_2.value=F.state.rectAreaLTC2,Pe.pointLights.value=F.state.point,Pe.pointLightShadows.value=F.state.pointShadow,Pe.hemisphereLights.value=F.state.hemi,Pe.directionalShadowMap.value=F.state.directionalShadowMap,Pe.directionalShadowMatrix.value=F.state.directionalShadowMatrix,Pe.spotShadowMap.value=F.state.spotShadowMap,Pe.spotLightMatrix.value=F.state.spotLightMatrix,Pe.spotLightMap.value=F.state.spotLightMap,Pe.pointShadowMap.value=F.state.pointShadowMap,Pe.pointShadowMatrix.value=F.state.pointShadowMatrix),V.currentProgram=je,V.uniformsList=null,je}function Jl(E){if(E.uniformsList===null){const k=E.currentProgram.getUniforms();E.uniformsList=Lo.seqWithValue(k.seq,E.uniforms)}return E.uniformsList}function Ql(E,k){const H=L.get(E);H.outputColorSpace=k.outputColorSpace,H.batching=k.batching,H.batchingColor=k.batchingColor,H.instancing=k.instancing,H.instancingColor=k.instancingColor,H.instancingMorph=k.instancingMorph,H.skinning=k.skinning,H.morphTargets=k.morphTargets,H.morphNormals=k.morphNormals,H.morphColors=k.morphColors,H.morphTargetsCount=k.morphTargetsCount,H.numClippingPlanes=k.numClippingPlanes,H.numIntersection=k.numClipIntersection,H.vertexAlphas=k.vertexAlphas,H.vertexTangents=k.vertexTangents,H.toneMapping=k.toneMapping}function Wf(E,k,H,V,F){k.isScene!==!0&&(k=Je),S.resetTextureUnits();const ce=k.fog,ve=V.isMeshStandardMaterial?k.environment:null,Re=P===null?x.outputColorSpace:P.isXRRenderTarget===!0?P.texture.colorSpace:nn,Ce=(V.isMeshStandardMaterial?N:y).get(V.envMap||ve),Xe=V.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,je=!!H.attributes.tangent&&(!!V.normalMap||V.anisotropy>0),Pe=!!H.morphAttributes.position,ot=!!H.morphAttributes.normal,xt=!!H.morphAttributes.color;let vt=Ei;V.toneMapped&&(P===null||P.isXRRenderTarget===!0)&&(vt=x.toneMapping);const sn=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,ct=sn!==void 0?sn.length:0,Ne=L.get(V),Xn=p.state.lights;if(ae===!0&&(we===!0||E!==w)){const pn=E===w&&V.id===b;oe.setState(V,E,pn)}let lt=!1;V.version===Ne.__version?(Ne.needsLights&&Ne.lightsStateVersion!==Xn.state.version||Ne.outputColorSpace!==Re||F.isBatchedMesh&&Ne.batching===!1||!F.isBatchedMesh&&Ne.batching===!0||F.isBatchedMesh&&Ne.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&Ne.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&Ne.instancing===!1||!F.isInstancedMesh&&Ne.instancing===!0||F.isSkinnedMesh&&Ne.skinning===!1||!F.isSkinnedMesh&&Ne.skinning===!0||F.isInstancedMesh&&Ne.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&Ne.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&Ne.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&Ne.instancingMorph===!1&&F.morphTexture!==null||Ne.envMap!==Ce||V.fog===!0&&Ne.fog!==ce||Ne.numClippingPlanes!==void 0&&(Ne.numClippingPlanes!==oe.numPlanes||Ne.numIntersection!==oe.numIntersection)||Ne.vertexAlphas!==Xe||Ne.vertexTangents!==je||Ne.morphTargets!==Pe||Ne.morphNormals!==ot||Ne.morphColors!==xt||Ne.toneMapping!==vt||Ne.morphTargetsCount!==ct)&&(lt=!0):(lt=!0,Ne.__version=V.version);let Tn=Ne.currentProgram;lt===!0&&(Tn=Br(V,k,F));let ns=!1,an=!1,Zs=!1;const yt=Tn.getUniforms(),Fn=Ne.uniforms;if(ue.useProgram(Tn.program)&&(ns=!0,an=!0,Zs=!0),V.id!==b&&(b=V.id,an=!0),ns||w!==E){ue.buffers.depth.getReversed()?(X.copy(E.projectionMatrix),em(X),tm(X),yt.setValue(C,"projectionMatrix",X)):yt.setValue(C,"projectionMatrix",E.projectionMatrix),yt.setValue(C,"viewMatrix",E.matrixWorldInverse);const ui=yt.map.cameraPosition;ui!==void 0&&ui.setValue(C,Ae.setFromMatrixPosition(E.matrixWorld)),_e.logarithmicDepthBuffer&&yt.setValue(C,"logDepthBufFC",2/(Math.log(E.far+1)/Math.LN2)),(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial)&&yt.setValue(C,"isOrthographic",E.isOrthographicCamera===!0),w!==E&&(w=E,an=!0,Zs=!0)}if(F.isSkinnedMesh){yt.setOptional(C,F,"bindMatrix"),yt.setOptional(C,F,"bindMatrixInverse");const pn=F.skeleton;pn&&(pn.boneTexture===null&&pn.computeBoneTexture(),yt.setValue(C,"boneTexture",pn.boneTexture,S))}F.isBatchedMesh&&(yt.setOptional(C,F,"batchingTexture"),yt.setValue(C,"batchingTexture",F._matricesTexture,S),yt.setOptional(C,F,"batchingIdTexture"),yt.setValue(C,"batchingIdTexture",F._indirectTexture,S),yt.setOptional(C,F,"batchingColorTexture"),F._colorsTexture!==null&&yt.setValue(C,"batchingColorTexture",F._colorsTexture,S));const Js=H.morphAttributes;if((Js.position!==void 0||Js.normal!==void 0||Js.color!==void 0)&&Ge.update(F,H,Tn),(an||Ne.receiveShadow!==F.receiveShadow)&&(Ne.receiveShadow=F.receiveShadow,yt.setValue(C,"receiveShadow",F.receiveShadow)),V.isMeshGouraudMaterial&&V.envMap!==null&&(Fn.envMap.value=Ce,Fn.flipEnvMap.value=Ce.isCubeTexture&&Ce.isRenderTargetTexture===!1?-1:1),V.isMeshStandardMaterial&&V.envMap===null&&k.environment!==null&&(Fn.envMapIntensity.value=k.environmentIntensity),an&&(yt.setValue(C,"toneMappingExposure",x.toneMappingExposure),Ne.needsLights&&Xf(Fn,Zs),ce&&V.fog===!0&&de.refreshFogUniforms(Fn,ce),de.refreshMaterialUniforms(Fn,V,W,Q,p.state.transmissionRenderTarget[E.id]),Lo.upload(C,Jl(Ne),Fn,S)),V.isShaderMaterial&&V.uniformsNeedUpdate===!0&&(Lo.upload(C,Jl(Ne),Fn,S),V.uniformsNeedUpdate=!1),V.isSpriteMaterial&&yt.setValue(C,"center",F.center),yt.setValue(C,"modelViewMatrix",F.modelViewMatrix),yt.setValue(C,"normalMatrix",F.normalMatrix),yt.setValue(C,"modelMatrix",F.matrixWorld),V.isShaderMaterial||V.isRawShaderMaterial){const pn=V.uniformsGroups;for(let ui=0,hi=pn.length;ui<hi;ui++){const eu=pn[ui];U.update(eu,Tn),U.bind(eu,Tn)}}return Tn}function Xf(E,k){E.ambientLightColor.needsUpdate=k,E.lightProbe.needsUpdate=k,E.directionalLights.needsUpdate=k,E.directionalLightShadows.needsUpdate=k,E.pointLights.needsUpdate=k,E.pointLightShadows.needsUpdate=k,E.spotLights.needsUpdate=k,E.spotLightShadows.needsUpdate=k,E.rectAreaLights.needsUpdate=k,E.hemisphereLights.needsUpdate=k}function qf(E){return E.isMeshLambertMaterial||E.isMeshToonMaterial||E.isMeshPhongMaterial||E.isMeshStandardMaterial||E.isShadowMaterial||E.isShaderMaterial&&E.lights===!0}this.getActiveCubeFace=function(){return A},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return P},this.setRenderTargetTextures=function(E,k,H){L.get(E.texture).__webglTexture=k,L.get(E.depthTexture).__webglTexture=H;const V=L.get(E);V.__hasExternalTextures=!0,V.__autoAllocateDepthBuffer=H===void 0,V.__autoAllocateDepthBuffer||ie.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),V.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(E,k){const H=L.get(E);H.__webglFramebuffer=k,H.__useDefaultFramebuffer=k===void 0},this.setRenderTarget=function(E,k=0,H=0){P=E,A=k,T=H;let V=!0,F=null,ce=!1,ve=!1;if(E){const Ce=L.get(E);if(Ce.__useDefaultFramebuffer!==void 0)ue.bindFramebuffer(C.FRAMEBUFFER,null),V=!1;else if(Ce.__webglFramebuffer===void 0)S.setupRenderTarget(E);else if(Ce.__hasExternalTextures)S.rebindTextures(E,L.get(E.texture).__webglTexture,L.get(E.depthTexture).__webglTexture);else if(E.depthBuffer){const Pe=E.depthTexture;if(Ce.__boundDepthTexture!==Pe){if(Pe!==null&&L.has(Pe)&&(E.width!==Pe.image.width||E.height!==Pe.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");S.setupDepthRenderbuffer(E)}}const Xe=E.texture;(Xe.isData3DTexture||Xe.isDataArrayTexture||Xe.isCompressedArrayTexture)&&(ve=!0);const je=L.get(E).__webglFramebuffer;E.isWebGLCubeRenderTarget?(Array.isArray(je[k])?F=je[k][H]:F=je[k],ce=!0):E.samples>0&&S.useMultisampledRTT(E)===!1?F=L.get(E).__webglMultisampledFramebuffer:Array.isArray(je)?F=je[H]:F=je,D.copy(E.viewport),z.copy(E.scissor),O=E.scissorTest}else D.copy(Me).multiplyScalar(W).floor(),z.copy(Le).multiplyScalar(W).floor(),O=qe;if(ue.bindFramebuffer(C.FRAMEBUFFER,F)&&V&&ue.drawBuffers(E,F),ue.viewport(D),ue.scissor(z),ue.setScissorTest(O),ce){const Ce=L.get(E.texture);C.framebufferTexture2D(C.FRAMEBUFFER,C.COLOR_ATTACHMENT0,C.TEXTURE_CUBE_MAP_POSITIVE_X+k,Ce.__webglTexture,H)}else if(ve){const Ce=L.get(E.texture),Xe=k||0;C.framebufferTextureLayer(C.FRAMEBUFFER,C.COLOR_ATTACHMENT0,Ce.__webglTexture,H||0,Xe)}b=-1},this.readRenderTargetPixels=function(E,k,H,V,F,ce,ve){if(!(E&&E.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Re=L.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&ve!==void 0&&(Re=Re[ve]),Re){ue.bindFramebuffer(C.FRAMEBUFFER,Re);try{const Ce=E.texture,Xe=Ce.format,je=Ce.type;if(!_e.textureFormatReadable(Xe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!_e.textureTypeReadable(je)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}k>=0&&k<=E.width-V&&H>=0&&H<=E.height-F&&C.readPixels(k,H,V,F,Qe.convert(Xe),Qe.convert(je),ce)}finally{const Ce=P!==null?L.get(P).__webglFramebuffer:null;ue.bindFramebuffer(C.FRAMEBUFFER,Ce)}}},this.readRenderTargetPixelsAsync=async function(E,k,H,V,F,ce,ve){if(!(E&&E.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Re=L.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&ve!==void 0&&(Re=Re[ve]),Re){const Ce=E.texture,Xe=Ce.format,je=Ce.type;if(!_e.textureFormatReadable(Xe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!_e.textureTypeReadable(je))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(k>=0&&k<=E.width-V&&H>=0&&H<=E.height-F){ue.bindFramebuffer(C.FRAMEBUFFER,Re);const Pe=C.createBuffer();C.bindBuffer(C.PIXEL_PACK_BUFFER,Pe),C.bufferData(C.PIXEL_PACK_BUFFER,ce.byteLength,C.STREAM_READ),C.readPixels(k,H,V,F,Qe.convert(Xe),Qe.convert(je),0);const ot=P!==null?L.get(P).__webglFramebuffer:null;ue.bindFramebuffer(C.FRAMEBUFFER,ot);const xt=C.fenceSync(C.SYNC_GPU_COMMANDS_COMPLETE,0);return C.flush(),await Qp(C,xt,4),C.bindBuffer(C.PIXEL_PACK_BUFFER,Pe),C.getBufferSubData(C.PIXEL_PACK_BUFFER,0,ce),C.deleteBuffer(Pe),C.deleteSync(xt),ce}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(E,k=null,H=0){E.isTexture!==!0&&(dr("WebGLRenderer: copyFramebufferToTexture function signature has changed."),k=arguments[0]||null,E=arguments[1]);const V=Math.pow(2,-H),F=Math.floor(E.image.width*V),ce=Math.floor(E.image.height*V),ve=k!==null?k.x:0,Re=k!==null?k.y:0;S.setTexture2D(E,0),C.copyTexSubImage2D(C.TEXTURE_2D,H,0,0,ve,Re,F,ce),ue.unbindTexture()},this.copyTextureToTexture=function(E,k,H=null,V=null,F=0){E.isTexture!==!0&&(dr("WebGLRenderer: copyTextureToTexture function signature has changed."),V=arguments[0]||null,E=arguments[1],k=arguments[2],F=arguments[3]||0,H=null);let ce,ve,Re,Ce,Xe,je,Pe,ot,xt;const vt=E.isCompressedTexture?E.mipmaps[F]:E.image;H!==null?(ce=H.max.x-H.min.x,ve=H.max.y-H.min.y,Re=H.isBox3?H.max.z-H.min.z:1,Ce=H.min.x,Xe=H.min.y,je=H.isBox3?H.min.z:0):(ce=vt.width,ve=vt.height,Re=vt.depth||1,Ce=0,Xe=0,je=0),V!==null?(Pe=V.x,ot=V.y,xt=V.z):(Pe=0,ot=0,xt=0);const sn=Qe.convert(k.format),ct=Qe.convert(k.type);let Ne;k.isData3DTexture?(S.setTexture3D(k,0),Ne=C.TEXTURE_3D):k.isDataArrayTexture||k.isCompressedArrayTexture?(S.setTexture2DArray(k,0),Ne=C.TEXTURE_2D_ARRAY):(S.setTexture2D(k,0),Ne=C.TEXTURE_2D),C.pixelStorei(C.UNPACK_FLIP_Y_WEBGL,k.flipY),C.pixelStorei(C.UNPACK_PREMULTIPLY_ALPHA_WEBGL,k.premultiplyAlpha),C.pixelStorei(C.UNPACK_ALIGNMENT,k.unpackAlignment);const Xn=C.getParameter(C.UNPACK_ROW_LENGTH),lt=C.getParameter(C.UNPACK_IMAGE_HEIGHT),Tn=C.getParameter(C.UNPACK_SKIP_PIXELS),ns=C.getParameter(C.UNPACK_SKIP_ROWS),an=C.getParameter(C.UNPACK_SKIP_IMAGES);C.pixelStorei(C.UNPACK_ROW_LENGTH,vt.width),C.pixelStorei(C.UNPACK_IMAGE_HEIGHT,vt.height),C.pixelStorei(C.UNPACK_SKIP_PIXELS,Ce),C.pixelStorei(C.UNPACK_SKIP_ROWS,Xe),C.pixelStorei(C.UNPACK_SKIP_IMAGES,je);const Zs=E.isDataArrayTexture||E.isData3DTexture,yt=k.isDataArrayTexture||k.isData3DTexture;if(E.isRenderTargetTexture||E.isDepthTexture){const Fn=L.get(E),Js=L.get(k),pn=L.get(Fn.__renderTarget),ui=L.get(Js.__renderTarget);ue.bindFramebuffer(C.READ_FRAMEBUFFER,pn.__webglFramebuffer),ue.bindFramebuffer(C.DRAW_FRAMEBUFFER,ui.__webglFramebuffer);for(let hi=0;hi<Re;hi++)Zs&&C.framebufferTextureLayer(C.READ_FRAMEBUFFER,C.COLOR_ATTACHMENT0,L.get(E).__webglTexture,F,je+hi),E.isDepthTexture?(yt&&C.framebufferTextureLayer(C.DRAW_FRAMEBUFFER,C.COLOR_ATTACHMENT0,L.get(k).__webglTexture,F,xt+hi),C.blitFramebuffer(Ce,Xe,ce,ve,Pe,ot,ce,ve,C.DEPTH_BUFFER_BIT,C.NEAREST)):yt?C.copyTexSubImage3D(Ne,F,Pe,ot,xt+hi,Ce,Xe,ce,ve):C.copyTexSubImage2D(Ne,F,Pe,ot,xt+hi,Ce,Xe,ce,ve);ue.bindFramebuffer(C.READ_FRAMEBUFFER,null),ue.bindFramebuffer(C.DRAW_FRAMEBUFFER,null)}else yt?E.isDataTexture||E.isData3DTexture?C.texSubImage3D(Ne,F,Pe,ot,xt,ce,ve,Re,sn,ct,vt.data):k.isCompressedArrayTexture?C.compressedTexSubImage3D(Ne,F,Pe,ot,xt,ce,ve,Re,sn,vt.data):C.texSubImage3D(Ne,F,Pe,ot,xt,ce,ve,Re,sn,ct,vt):E.isDataTexture?C.texSubImage2D(C.TEXTURE_2D,F,Pe,ot,ce,ve,sn,ct,vt.data):E.isCompressedTexture?C.compressedTexSubImage2D(C.TEXTURE_2D,F,Pe,ot,vt.width,vt.height,sn,vt.data):C.texSubImage2D(C.TEXTURE_2D,F,Pe,ot,ce,ve,sn,ct,vt);C.pixelStorei(C.UNPACK_ROW_LENGTH,Xn),C.pixelStorei(C.UNPACK_IMAGE_HEIGHT,lt),C.pixelStorei(C.UNPACK_SKIP_PIXELS,Tn),C.pixelStorei(C.UNPACK_SKIP_ROWS,ns),C.pixelStorei(C.UNPACK_SKIP_IMAGES,an),F===0&&k.generateMipmaps&&C.generateMipmap(Ne),ue.unbindTexture()},this.copyTextureToTexture3D=function(E,k,H=null,V=null,F=0){return E.isTexture!==!0&&(dr("WebGLRenderer: copyTextureToTexture3D function signature has changed."),H=arguments[0]||null,V=arguments[1]||null,E=arguments[2],k=arguments[3],F=arguments[4]||0),dr('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(E,k,H,V,F)},this.initRenderTarget=function(E){L.get(E).__webglFramebuffer===void 0&&S.setupRenderTarget(E)},this.initTexture=function(E){E.isCubeTexture?S.setTextureCube(E,0):E.isData3DTexture?S.setTexture3D(E,0):E.isDataArrayTexture||E.isCompressedArrayTexture?S.setTexture2DArray(E,0):S.setTexture2D(E,0),ue.unbindTexture()},this.resetState=function(){A=0,T=0,P=null,ue.reset(),_t.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ni}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorspace=st._getDrawingBufferColorSpace(e),t.unpackColorSpace=st._getUnpackColorSpace()}}class yl{constructor(e,t=1,n=1e3){this.isFog=!0,this.name="",this.color=new Fe(e),this.near=t,this.far=n}clone(){return new yl(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class hv extends St{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new fn,this.environmentIntensity=1,this.environmentRotation=new fn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class zd{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Fc,this.updateRanges=[],this.version=0,this.uuid=wn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=wn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=wn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Kt=new R;class br{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.applyMatrix4(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.applyNormalMatrix(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.transformDirection(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=In(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ht(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=In(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=In(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=In(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=In(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=ht(t,this.array),n=ht(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=ht(t,this.array),n=ht(n,this.array),s=ht(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=ht(t,this.array),n=ht(n,this.array),s=ht(s,this.array),r=ht(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new jt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new br(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Ml extends bn{static get type(){return"SpriteMaterial"}constructor(e){super(),this.isSpriteMaterial=!0,this.color=new Fe(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let _s;const ir=new R,xs=new R,vs=new R,ys=new se,sr=new se,Hd=new He,oo=new R,rr=new R,ao=new R,nh=new se,Ua=new se,ih=new se;let Vd=class extends St{constructor(e=new Ml){if(super(),this.isSprite=!0,this.type="Sprite",_s===void 0){_s=new Tt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new zd(t,5);_s.setIndex([0,1,2,0,2,3]),_s.setAttribute("position",new br(n,3,0,!1)),_s.setAttribute("uv",new br(n,2,3,!1))}this.geometry=_s,this.material=e,this.center=new se(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),xs.setFromMatrixScale(this.matrixWorld),Hd.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),vs.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&xs.multiplyScalar(-vs.z);const n=this.material.rotation;let s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));const o=this.center;co(oo.set(-.5,-.5,0),vs,o,xs,s,r),co(rr.set(.5,-.5,0),vs,o,xs,s,r),co(ao.set(.5,.5,0),vs,o,xs,s,r),nh.set(0,0),Ua.set(1,0),ih.set(1,1);let a=e.ray.intersectTriangle(oo,rr,ao,!1,ir);if(a===null&&(co(rr.set(-.5,.5,0),vs,o,xs,s,r),Ua.set(0,1),a=e.ray.intersectTriangle(oo,ao,rr,!1,ir),a===null))return;const c=e.ray.origin.distanceTo(ir);c<e.near||c>e.far||t.push({distance:c,point:ir.clone(),uv:yn.getInterpolation(ir,oo,rr,ao,nh,Ua,ih,new se),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function co(i,e,t,n,s,r){ys.subVectors(i,t).addScalar(.5).multiply(n),s!==void 0?(sr.x=r*ys.x-s*ys.y,sr.y=s*ys.x+r*ys.y):sr.copy(ys),i.copy(e),i.x+=sr.x,i.y+=sr.y,i.applyMatrix4(Hd)}const sh=new R,rh=new at,oh=new at,dv=new R,ah=new He,lo=new R,ka=new zn,ch=new He,Fa=new $o;class fv extends G{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=su,this.bindMatrix=new He,this.bindMatrixInverse=new He,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new Bn),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,lo),this.boundingBox.expandByPoint(lo)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new zn),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,lo),this.boundingSphere.expandByPoint(lo)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ka.copy(this.boundingSphere),ka.applyMatrix4(s),e.ray.intersectsSphere(ka)!==!1&&(ch.copy(s).invert(),Fa.copy(e.ray).applyMatrix4(ch),!(this.boundingBox!==null&&Fa.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Fa)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new at,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);const r=1/e.manhattanLength();r!==1/0?e.multiplyScalar(r):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===su?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===wp?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,s=this.geometry;rh.fromBufferAttribute(s.attributes.skinIndex,e),oh.fromBufferAttribute(s.attributes.skinWeight,e),sh.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let r=0;r<4;r++){const o=oh.getComponent(r);if(o!==0){const a=rh.getComponent(r);ah.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(dv.copy(sh).applyMatrix4(ah),o)}}return t.applyMatrix4(this.bindMatrixInverse)}}class Gd extends St{constructor(){super(),this.isBone=!0,this.type="Bone"}}class Wd extends Nt{constructor(e=null,t=1,n=1,s,r,o,a,c,l=en,u=en,h,d){super(null,o,a,c,l,u,s,r,h,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const lh=new He,pv=new He;class Sl{constructor(e=[],t=[]){this.uuid=wn(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new He)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new He;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let r=0,o=e.length;r<o;r++){const a=e[r]?e[r].matrixWorld:pv;lh.multiplyMatrices(a,t[r]),lh.toArray(n,r*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new Sl(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new Wd(t,e,e,Mn,Dn);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){const r=e.bones[n];let o=t[r];o===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",r),o=new Gd),this.bones.push(o),this.boneInverses.push(new He().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let s=0,r=t.length;s<r;s++){const o=t[s];e.bones.push(o.uuid);const a=n[s];e.boneInverses.push(a.toArray())}return e}}class Bc extends jt{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Ms=new He,uh=new He,uo=[],hh=new Bn,mv=new He,or=new G,ar=new zn;class ko extends G{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Bc(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,mv)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Bn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Ms),hh.copy(e.boundingBox).applyMatrix4(Ms),this.boundingBox.union(hh)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new zn),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Ms),ar.copy(e.boundingSphere).applyMatrix4(Ms),this.boundingSphere.union(ar)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=e*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(or.geometry=this.geometry,or.material=this.material,or.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ar.copy(this.boundingSphere),ar.applyMatrix4(n),e.ray.intersectsSphere(ar)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ms),uh.multiplyMatrices(n,Ms),or.matrixWorld=uh,or.raycast(e,uo);for(let o=0,a=uo.length;o<a;o++){const c=uo[o];c.instanceId=r,c.object=this,t.push(c)}uo.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Bc(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new Wd(new Float32Array(s*this.count),s,this.count,ul,Dn));const r=this.morphTexture.source.data.data;let o=0;for(let l=0;l<n.length;l++)o+=n[l];const a=this.geometry.morphTargetsRelative?1:1-o,c=s*e;r[c]=a,r.set(n,c+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}}class Xd extends bn{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new Fe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Fo=new R,Oo=new R,dh=new He,cr=new $o,ho=new zn,Oa=new R,fh=new R;class wl extends St{constructor(e=new Tt,t=new Xd){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)Fo.fromBufferAttribute(t,s-1),Oo.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=Fo.distanceTo(Oo);e.setAttribute("lineDistance",new Ze(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ho.copy(n.boundingSphere),ho.applyMatrix4(s),ho.radius+=r,e.ray.intersectsSphere(ho)===!1)return;dh.copy(s).invert(),cr.copy(e.ray).applyMatrix4(dh);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=this.isLineSegments?2:1,u=n.index,d=n.attributes.position;if(u!==null){const f=Math.max(0,o.start),g=Math.min(u.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=l){const p=u.getX(_),M=u.getX(_+1),v=fo(this,e,cr,c,p,M);v&&t.push(v)}if(this.isLineLoop){const _=u.getX(g-1),m=u.getX(f),p=fo(this,e,cr,c,_,m);p&&t.push(p)}}else{const f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=l){const p=fo(this,e,cr,c,_,_+1);p&&t.push(p)}if(this.isLineLoop){const _=fo(this,e,cr,c,g-1,f);_&&t.push(_)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function fo(i,e,t,n,s,r){const o=i.geometry.attributes.position;if(Fo.fromBufferAttribute(o,s),Oo.fromBufferAttribute(o,r),t.distanceSqToSegment(Fo,Oo,Oa,fh)>n)return;Oa.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(Oa);if(!(c<e.near||c>e.far))return{distance:c,point:fh.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}const ph=new R,mh=new R;class gv extends wl{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)ph.fromBufferAttribute(t,s),mh.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+ph.distanceTo(mh);e.setAttribute("lineDistance",new Ze(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class _v extends wl{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}}class bl extends bn{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new Fe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const gh=new He,zc=new $o,po=new zn,mo=new R;class qd extends St{constructor(e=new Tt,t=new bl){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),po.copy(n.boundingSphere),po.applyMatrix4(s),po.radius+=r,e.ray.intersectsSphere(po)===!1)return;gh.copy(s).invert(),zc.copy(e.ray).applyMatrix4(gh);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=n.index,h=n.attributes.position;if(l!==null){const d=Math.max(0,o.start),f=Math.min(l.count,o.start+o.count);for(let g=d,_=f;g<_;g++){const m=l.getX(g);mo.fromBufferAttribute(h,m),_h(mo,m,c,s,e,t,this)}}else{const d=Math.max(0,o.start),f=Math.min(h.count,o.start+o.count);for(let g=d,_=f;g<_;g++)mo.fromBufferAttribute(h,g),_h(mo,g,c,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function _h(i,e,t,n,s,r,o){const a=zc.distanceSqToPoint(i);if(a<t){const c=new R;zc.closestPointToPoint(i,c),c.applyMatrix4(n);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(a),point:c,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}class $d extends Nt{constructor(e,t,n,s,r,o,a,c,l){super(e,t,n,s,r,o,a,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Hn{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,s=this.getPoint(0),r=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),r+=n.distanceTo(s),t.push(r),s=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){const n=this.getLengths();let s=0;const r=n.length;let o;t?o=t:o=e*n[r-1];let a=0,c=r-1,l;for(;a<=c;)if(s=Math.floor(a+(c-a)/2),l=n[s]-o,l<0)a=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,n[s]===o)return s/(r-1);const u=n[s],d=n[s+1]-u,f=(o-u)/d;return(s+f)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const o=this.getPoint(s),a=this.getPoint(r),c=t||(o.isVector2?new se:new R);return c.copy(a).sub(o).normalize(),c}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t){const n=new R,s=[],r=[],o=[],a=new R,c=new He;for(let f=0;f<=e;f++){const g=f/e;s[f]=this.getTangentAt(g,new R)}r[0]=new R,o[0]=new R;let l=Number.MAX_VALUE;const u=Math.abs(s[0].x),h=Math.abs(s[0].y),d=Math.abs(s[0].z);u<=l&&(l=u,n.set(1,0,0)),h<=l&&(l=h,n.set(0,1,0)),d<=l&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let f=1;f<=e;f++){if(r[f]=r[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(s[f-1],s[f]),a.length()>Number.EPSILON){a.normalize();const g=Math.acos(It(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(c.makeRotationAxis(a,g))}o[f].crossVectors(s[f],r[f])}if(t===!0){let f=Math.acos(It(r[0].dot(r[e]),-1,1));f/=e,s[0].dot(a.crossVectors(r[0],r[e]))>0&&(f=-f);for(let g=1;g<=e;g++)r[g].applyMatrix4(c.makeRotationAxis(s[g],f*g)),o[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class El extends Hn{constructor(e=0,t=0,n=1,s=1,r=0,o=Math.PI*2,a=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=c}getPoint(e,t=new se){const n=t,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);const a=this.aStartAngle+e*r;let c=this.aX+this.xRadius*Math.cos(a),l=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){const u=Math.cos(this.aRotation),h=Math.sin(this.aRotation),d=c-this.aX,f=l-this.aY;c=d*u-f*h+this.aX,l=d*h+f*u+this.aY}return n.set(c,l)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class xv extends El{constructor(e,t,n,s,r,o){super(e,t,n,n,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}}function Tl(){let i=0,e=0,t=0,n=0;function s(r,o,a,c){i=r,e=a,t=-3*r+3*o-2*a-c,n=2*r-2*o+a+c}return{initCatmullRom:function(r,o,a,c,l){s(o,a,l*(a-r),l*(c-o))},initNonuniformCatmullRom:function(r,o,a,c,l,u,h){let d=(o-r)/l-(a-r)/(l+u)+(a-o)/u,f=(a-o)/u-(c-o)/(u+h)+(c-a)/h;d*=u,f*=u,s(o,a,d,f)},calc:function(r){const o=r*r,a=o*r;return i+e*r+t*o+n*a}}}const go=new R,Ba=new Tl,za=new Tl,Ha=new Tl;class Dr extends Hn{constructor(e=[],t=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=s}getPoint(e,t=new R){const n=t,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e;let a=Math.floor(o),c=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:c===0&&a===r-1&&(a=r-2,c=1);let l,u;this.closed||a>0?l=s[(a-1)%r]:(go.subVectors(s[0],s[1]).add(s[0]),l=go);const h=s[a%r],d=s[(a+1)%r];if(this.closed||a+2<r?u=s[(a+2)%r]:(go.subVectors(s[r-1],s[r-2]).add(s[r-1]),u=go),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let g=Math.pow(l.distanceToSquared(h),f),_=Math.pow(h.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(u),f);_<1e-4&&(_=1),g<1e-4&&(g=_),m<1e-4&&(m=_),Ba.initNonuniformCatmullRom(l.x,h.x,d.x,u.x,g,_,m),za.initNonuniformCatmullRom(l.y,h.y,d.y,u.y,g,_,m),Ha.initNonuniformCatmullRom(l.z,h.z,d.z,u.z,g,_,m)}else this.curveType==="catmullrom"&&(Ba.initCatmullRom(l.x,h.x,d.x,u.x,this.tension),za.initCatmullRom(l.y,h.y,d.y,u.y,this.tension),Ha.initCatmullRom(l.z,h.z,d.z,u.z,this.tension));return n.set(Ba.calc(c),za.calc(c),Ha.calc(c)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new R().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function xh(i,e,t,n,s){const r=(n-e)*.5,o=(s-t)*.5,a=i*i,c=i*a;return(2*t-2*n+r+o)*c+(-3*t+3*n-2*r-o)*a+r*i+t}function vv(i,e){const t=1-i;return t*t*e}function yv(i,e){return 2*(1-i)*i*e}function Mv(i,e){return i*i*e}function _r(i,e,t,n){return vv(i,e)+yv(i,t)+Mv(i,n)}function Sv(i,e){const t=1-i;return t*t*t*e}function wv(i,e){const t=1-i;return 3*t*t*i*e}function bv(i,e){return 3*(1-i)*i*i*e}function Ev(i,e){return i*i*i*e}function xr(i,e,t,n,s){return Sv(i,e)+wv(i,t)+bv(i,n)+Ev(i,s)}class Yd extends Hn{constructor(e=new se,t=new se,n=new se,s=new se){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new se){const n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(xr(e,s.x,r.x,o.x,a.x),xr(e,s.y,r.y,o.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Tv extends Hn{constructor(e=new R,t=new R,n=new R,s=new R){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new R){const n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(xr(e,s.x,r.x,o.x,a.x),xr(e,s.y,r.y,o.y,a.y),xr(e,s.z,r.z,o.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class jd extends Hn{constructor(e=new se,t=new se){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new se){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new se){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Av extends Hn{constructor(e=new R,t=new R){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new R){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new R){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Kd extends Hn{constructor(e=new se,t=new se,n=new se){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new se){const n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(_r(e,s.x,r.x,o.x),_r(e,s.y,r.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Zd extends Hn{constructor(e=new R,t=new R,n=new R){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new R){const n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(_r(e,s.x,r.x,o.x),_r(e,s.y,r.y,o.y),_r(e,s.z,r.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Jd extends Hn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new se){const n=t,s=this.points,r=(s.length-1)*e,o=Math.floor(r),a=r-o,c=s[o===0?o:o-1],l=s[o],u=s[o>s.length-2?s.length-1:o+1],h=s[o>s.length-3?s.length-1:o+2];return n.set(xh(a,c.x,l.x,u.x,h.x),xh(a,c.y,l.y,u.y,h.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new se().fromArray(s))}return this}}var Bo=Object.freeze({__proto__:null,ArcCurve:xv,CatmullRomCurve3:Dr,CubicBezierCurve:Yd,CubicBezierCurve3:Tv,EllipseCurve:El,LineCurve:jd,LineCurve3:Av,QuadraticBezierCurve:Kd,QuadraticBezierCurve3:Zd,SplineCurve:Jd});class Rv extends Hn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Bo[n](t,e))}return this}getPoint(e,t){const n=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=n){const o=s[r]-n,a=this.curves[r],c=a.getLength(),l=c===0?0:1-o/c;return a.getPointAt(l,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let n=0,s=this.curves.length;n<s;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let n;for(let s=0,r=this.curves;s<r.length;s++){const o=r[s],a=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,c=o.getPoints(a);for(let l=0;l<c.length;l++){const u=c[l];n&&n.equals(u)||(t.push(u),n=u)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(new Bo[s.type]().fromJSON(s))}return this}}class Hc extends Rv{constructor(e){super(),this.type="Path",this.currentPoint=new se,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const n=new jd(this.currentPoint.clone(),new se(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,s){const r=new Kd(this.currentPoint.clone(),new se(e,t),new se(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(e,t,n,s,r,o){const a=new Yd(this.currentPoint.clone(),new se(e,t),new se(n,s),new se(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),n=new Jd(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,s,r,o){const a=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(e+a,t+c,n,s,r,o),this}absarc(e,t,n,s,r,o){return this.absellipse(e,t,n,n,s,r,o),this}ellipse(e,t,n,s,r,o,a,c){const l=this.currentPoint.x,u=this.currentPoint.y;return this.absellipse(e+l,t+u,n,s,r,o,a,c),this}absellipse(e,t,n,s,r,o,a,c){const l=new El(e,t,n,s,r,o,a,c);if(this.curves.length>0){const h=l.getPoint(0);h.equals(this.currentPoint)||this.lineTo(h.x,h.y)}this.curves.push(l);const u=l.getPoint(1);return this.currentPoint.copy(u),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Al extends Tt{constructor(e=[new se(0,-.5),new se(.5,0),new se(0,.5)],t=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:s},t=Math.floor(t),s=It(s,0,Math.PI*2);const r=[],o=[],a=[],c=[],l=[],u=1/t,h=new R,d=new se,f=new R,g=new R,_=new R;let m=0,p=0;for(let M=0;M<=e.length-1;M++)switch(M){case 0:m=e[M+1].x-e[M].x,p=e[M+1].y-e[M].y,f.x=p*1,f.y=-m,f.z=p*0,_.copy(f),f.normalize(),c.push(f.x,f.y,f.z);break;case e.length-1:c.push(_.x,_.y,_.z);break;default:m=e[M+1].x-e[M].x,p=e[M+1].y-e[M].y,f.x=p*1,f.y=-m,f.z=p*0,g.copy(f),f.x+=_.x,f.y+=_.y,f.z+=_.z,f.normalize(),c.push(f.x,f.y,f.z),_.copy(g)}for(let M=0;M<=t;M++){const v=n+M*u*s,x=Math.sin(v),I=Math.cos(v);for(let A=0;A<=e.length-1;A++){h.x=e[A].x*x,h.y=e[A].y,h.z=e[A].x*I,o.push(h.x,h.y,h.z),d.x=M/t,d.y=A/(e.length-1),a.push(d.x,d.y);const T=c[3*A+0]*x,P=c[3*A+1],b=c[3*A+0]*I;l.push(T,P,b)}}for(let M=0;M<t;M++)for(let v=0;v<e.length-1;v++){const x=v+M*e.length,I=x,A=x+e.length,T=x+e.length+1,P=x+1;r.push(I,A,P),r.push(T,P,A)}this.setIndex(r),this.setAttribute("position",new Ze(o,3)),this.setAttribute("uv",new Ze(a,2)),this.setAttribute("normal",new Ze(l,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Al(e.points,e.segments,e.phiStart,e.phiLength)}}class Er extends Al{constructor(e=1,t=1,n=4,s=8){const r=new Hc;r.absarc(0,-t/2,e,Math.PI*1.5,0),r.absarc(0,t/2,e,0,Math.PI*.5),super(r.getPoints(n),s),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:n,radialSegments:s}}static fromJSON(e){return new Er(e.radius,e.length,e.capSegments,e.radialSegments)}}class dn extends Tt{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);const r=[],o=[],a=[],c=[],l=new R,u=new se;o.push(0,0,0),a.push(0,0,1),c.push(.5,.5);for(let h=0,d=3;h<=t;h++,d+=3){const f=n+h/t*s;l.x=e*Math.cos(f),l.y=e*Math.sin(f),o.push(l.x,l.y,l.z),a.push(0,0,1),u.x=(o[d]/e+1)/2,u.y=(o[d+1]/e+1)/2,c.push(u.x,u.y)}for(let h=1;h<=t;h++)r.push(h,h+1,0);this.setIndex(r),this.setAttribute("position",new Ze(o,3)),this.setAttribute("normal",new Ze(a,3)),this.setAttribute("uv",new Ze(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new dn(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class mt extends Tt{constructor(e=1,t=1,n=1,s=32,r=1,o=!1,a=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:c};const l=this;s=Math.floor(s),r=Math.floor(r);const u=[],h=[],d=[],f=[];let g=0;const _=[],m=n/2;let p=0;M(),o===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(u),this.setAttribute("position",new Ze(h,3)),this.setAttribute("normal",new Ze(d,3)),this.setAttribute("uv",new Ze(f,2));function M(){const x=new R,I=new R;let A=0;const T=(t-e)/n;for(let P=0;P<=r;P++){const b=[],w=P/r,D=w*(t-e)+e;for(let z=0;z<=s;z++){const O=z/s,Y=O*c+a,q=Math.sin(Y),j=Math.cos(Y);I.x=D*q,I.y=-w*n+m,I.z=D*j,h.push(I.x,I.y,I.z),x.set(q,T,j).normalize(),d.push(x.x,x.y,x.z),f.push(O,1-w),b.push(g++)}_.push(b)}for(let P=0;P<s;P++)for(let b=0;b<r;b++){const w=_[b][P],D=_[b+1][P],z=_[b+1][P+1],O=_[b][P+1];(e>0||b!==0)&&(u.push(w,D,O),A+=3),(t>0||b!==r-1)&&(u.push(D,z,O),A+=3)}l.addGroup(p,A,0),p+=A}function v(x){const I=g,A=new se,T=new R;let P=0;const b=x===!0?e:t,w=x===!0?1:-1;for(let z=1;z<=s;z++)h.push(0,m*w,0),d.push(0,w,0),f.push(.5,.5),g++;const D=g;for(let z=0;z<=s;z++){const Y=z/s*c+a,q=Math.cos(Y),j=Math.sin(Y);T.x=b*j,T.y=m*w,T.z=b*q,h.push(T.x,T.y,T.z),d.push(0,w,0),A.x=q*.5+.5,A.y=j*.5*w+.5,f.push(A.x,A.y),g++}for(let z=0;z<s;z++){const O=I+z,Y=D+z;x===!0?u.push(Y,Y+1,O):u.push(Y+1,Y,O),P+=3}l.addGroup(p,P,x===!0?1:2),p+=P}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new mt(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class ai extends mt{constructor(e=1,t=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,e,t,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(e){return new ai(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Nr extends Tt{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const r=[],o=[];a(s),l(n),u(),this.setAttribute("position",new Ze(r,3)),this.setAttribute("normal",new Ze(r.slice(),3)),this.setAttribute("uv",new Ze(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(M){const v=new R,x=new R,I=new R;for(let A=0;A<t.length;A+=3)f(t[A+0],v),f(t[A+1],x),f(t[A+2],I),c(v,x,I,M)}function c(M,v,x,I){const A=I+1,T=[];for(let P=0;P<=A;P++){T[P]=[];const b=M.clone().lerp(x,P/A),w=v.clone().lerp(x,P/A),D=A-P;for(let z=0;z<=D;z++)z===0&&P===A?T[P][z]=b:T[P][z]=b.clone().lerp(w,z/D)}for(let P=0;P<A;P++)for(let b=0;b<2*(A-P)-1;b++){const w=Math.floor(b/2);b%2===0?(d(T[P][w+1]),d(T[P+1][w]),d(T[P][w])):(d(T[P][w+1]),d(T[P+1][w+1]),d(T[P+1][w]))}}function l(M){const v=new R;for(let x=0;x<r.length;x+=3)v.x=r[x+0],v.y=r[x+1],v.z=r[x+2],v.normalize().multiplyScalar(M),r[x+0]=v.x,r[x+1]=v.y,r[x+2]=v.z}function u(){const M=new R;for(let v=0;v<r.length;v+=3){M.x=r[v+0],M.y=r[v+1],M.z=r[v+2];const x=m(M)/2/Math.PI+.5,I=p(M)/Math.PI+.5;o.push(x,1-I)}g(),h()}function h(){for(let M=0;M<o.length;M+=6){const v=o[M+0],x=o[M+2],I=o[M+4],A=Math.max(v,x,I),T=Math.min(v,x,I);A>.9&&T<.1&&(v<.2&&(o[M+0]+=1),x<.2&&(o[M+2]+=1),I<.2&&(o[M+4]+=1))}}function d(M){r.push(M.x,M.y,M.z)}function f(M,v){const x=M*3;v.x=e[x+0],v.y=e[x+1],v.z=e[x+2]}function g(){const M=new R,v=new R,x=new R,I=new R,A=new se,T=new se,P=new se;for(let b=0,w=0;b<r.length;b+=9,w+=6){M.set(r[b+0],r[b+1],r[b+2]),v.set(r[b+3],r[b+4],r[b+5]),x.set(r[b+6],r[b+7],r[b+8]),A.set(o[w+0],o[w+1]),T.set(o[w+2],o[w+3]),P.set(o[w+4],o[w+5]),I.copy(M).add(v).add(x).divideScalar(3);const D=m(I);_(A,w+0,M,D),_(T,w+2,v,D),_(P,w+4,x,D)}}function _(M,v,x,I){I<0&&M.x===1&&(o[v]=M.x-1),x.x===0&&x.z===0&&(o[v]=I/2/Math.PI+.5)}function m(M){return Math.atan2(M.z,-M.x)}function p(M){return Math.atan2(-M.y,Math.sqrt(M.x*M.x+M.z*M.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Nr(e.vertices,e.indices,e.radius,e.details)}}class jo extends Nr{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,o,e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new jo(e.radius,e.detail)}}class Pi extends Hc{constructor(e){super(e),this.uuid=wn(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let n=0,s=this.holes.length;n<s;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(new Hc().fromJSON(s))}return this}}const Cv={triangulate:function(i,e,t=2){const n=e&&e.length,s=n?e[0]*t:i.length;let r=Qd(i,0,s,t,!0);const o=[];if(!r||r.next===r.prev)return o;let a,c,l,u,h,d,f;if(n&&(r=Nv(i,e,r,t)),i.length>80*t){a=l=i[0],c=u=i[1];for(let g=t;g<s;g+=t)h=i[g],d=i[g+1],h<a&&(a=h),d<c&&(c=d),h>l&&(l=h),d>u&&(u=d);f=Math.max(l-a,u-c),f=f!==0?32767/f:0}return Tr(r,o,t,a,c,f,0),o}};function Qd(i,e,t,n,s){let r,o;if(s===Xv(i,e,t,n)>0)for(r=e;r<t;r+=n)o=vh(r,i[r],i[r+1],o);else for(r=t-n;r>=e;r-=n)o=vh(r,i[r],i[r+1],o);return o&&Ko(o,o.next)&&(Rr(o),o=o.next),o}function Zi(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(Ko(t,t.next)||bt(t.prev,t,t.next)===0)){if(Rr(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function Tr(i,e,t,n,s,r,o){if(!i)return;!o&&r&&Bv(i,n,s,r);let a=i,c,l;for(;i.prev!==i.next;){if(c=i.prev,l=i.next,r?Lv(i,n,s,r):Pv(i)){e.push(c.i/t|0),e.push(i.i/t|0),e.push(l.i/t|0),Rr(i),i=l.next,a=l.next;continue}if(i=l,i===a){o?o===1?(i=Iv(Zi(i),e,t),Tr(i,e,t,n,s,r,2)):o===2&&Dv(i,e,t,n,s,r):Tr(Zi(i),e,t,n,s,r,1);break}}}function Pv(i){const e=i.prev,t=i,n=i.next;if(bt(e,t,n)>=0)return!1;const s=e.x,r=t.x,o=n.x,a=e.y,c=t.y,l=n.y,u=s<r?s<o?s:o:r<o?r:o,h=a<c?a<l?a:l:c<l?c:l,d=s>r?s>o?s:o:r>o?r:o,f=a>c?a>l?a:l:c>l?c:l;let g=n.next;for(;g!==e;){if(g.x>=u&&g.x<=d&&g.y>=h&&g.y<=f&&ws(s,a,r,c,o,l,g.x,g.y)&&bt(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function Lv(i,e,t,n){const s=i.prev,r=i,o=i.next;if(bt(s,r,o)>=0)return!1;const a=s.x,c=r.x,l=o.x,u=s.y,h=r.y,d=o.y,f=a<c?a<l?a:l:c<l?c:l,g=u<h?u<d?u:d:h<d?h:d,_=a>c?a>l?a:l:c>l?c:l,m=u>h?u>d?u:d:h>d?h:d,p=Vc(f,g,e,t,n),M=Vc(_,m,e,t,n);let v=i.prevZ,x=i.nextZ;for(;v&&v.z>=p&&x&&x.z<=M;){if(v.x>=f&&v.x<=_&&v.y>=g&&v.y<=m&&v!==s&&v!==o&&ws(a,u,c,h,l,d,v.x,v.y)&&bt(v.prev,v,v.next)>=0||(v=v.prevZ,x.x>=f&&x.x<=_&&x.y>=g&&x.y<=m&&x!==s&&x!==o&&ws(a,u,c,h,l,d,x.x,x.y)&&bt(x.prev,x,x.next)>=0))return!1;x=x.nextZ}for(;v&&v.z>=p;){if(v.x>=f&&v.x<=_&&v.y>=g&&v.y<=m&&v!==s&&v!==o&&ws(a,u,c,h,l,d,v.x,v.y)&&bt(v.prev,v,v.next)>=0)return!1;v=v.prevZ}for(;x&&x.z<=M;){if(x.x>=f&&x.x<=_&&x.y>=g&&x.y<=m&&x!==s&&x!==o&&ws(a,u,c,h,l,d,x.x,x.y)&&bt(x.prev,x,x.next)>=0)return!1;x=x.nextZ}return!0}function Iv(i,e,t){let n=i;do{const s=n.prev,r=n.next.next;!Ko(s,r)&&ef(s,n,n.next,r)&&Ar(s,r)&&Ar(r,s)&&(e.push(s.i/t|0),e.push(n.i/t|0),e.push(r.i/t|0),Rr(n),Rr(n.next),n=i=r),n=n.next}while(n!==i);return Zi(n)}function Dv(i,e,t,n,s,r){let o=i;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Vv(o,a)){let c=tf(o,a);o=Zi(o,o.next),c=Zi(c,c.next),Tr(o,e,t,n,s,r,0),Tr(c,e,t,n,s,r,0);return}a=a.next}o=o.next}while(o!==i)}function Nv(i,e,t,n){const s=[];let r,o,a,c,l;for(r=0,o=e.length;r<o;r++)a=e[r]*n,c=r<o-1?e[r+1]*n:i.length,l=Qd(i,a,c,n,!1),l===l.next&&(l.steiner=!0),s.push(Hv(l));for(s.sort(Uv),r=0;r<s.length;r++)t=kv(s[r],t);return t}function Uv(i,e){return i.x-e.x}function kv(i,e){const t=Fv(i,e);if(!t)return e;const n=tf(t,i);return Zi(n,n.next),Zi(t,t.next)}function Fv(i,e){let t=e,n=-1/0,s;const r=i.x,o=i.y;do{if(o<=t.y&&o>=t.next.y&&t.next.y!==t.y){const d=t.x+(o-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(d<=r&&d>n&&(n=d,s=t.x<t.next.x?t:t.next,d===r))return s}t=t.next}while(t!==e);if(!s)return null;const a=s,c=s.x,l=s.y;let u=1/0,h;t=s;do r>=t.x&&t.x>=c&&r!==t.x&&ws(o<l?r:n,o,c,l,o<l?n:r,o,t.x,t.y)&&(h=Math.abs(o-t.y)/(r-t.x),Ar(t,i)&&(h<u||h===u&&(t.x>s.x||t.x===s.x&&Ov(s,t)))&&(s=t,u=h)),t=t.next;while(t!==a);return s}function Ov(i,e){return bt(i.prev,i,e.prev)<0&&bt(e.next,i,i.next)<0}function Bv(i,e,t,n){let s=i;do s.z===0&&(s.z=Vc(s.x,s.y,e,t,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,zv(s)}function zv(i){let e,t,n,s,r,o,a,c,l=1;do{for(t=i,i=null,r=null,o=0;t;){for(o++,n=t,a=0,e=0;e<l&&(a++,n=n.nextZ,!!n);e++);for(c=l;a>0||c>0&&n;)a!==0&&(c===0||!n||t.z<=n.z)?(s=t,t=t.nextZ,a--):(s=n,n=n.nextZ,c--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;t=n}r.nextZ=null,l*=2}while(o>1);return i}function Vc(i,e,t,n,s){return i=(i-t)*s|0,e=(e-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function Hv(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function ws(i,e,t,n,s,r,o,a){return(s-o)*(e-a)>=(i-o)*(r-a)&&(i-o)*(n-a)>=(t-o)*(e-a)&&(t-o)*(r-a)>=(s-o)*(n-a)}function Vv(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!Gv(i,e)&&(Ar(i,e)&&Ar(e,i)&&Wv(i,e)&&(bt(i.prev,i,e.prev)||bt(i,e.prev,e))||Ko(i,e)&&bt(i.prev,i,i.next)>0&&bt(e.prev,e,e.next)>0)}function bt(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function Ko(i,e){return i.x===e.x&&i.y===e.y}function ef(i,e,t,n){const s=xo(bt(i,e,t)),r=xo(bt(i,e,n)),o=xo(bt(t,n,i)),a=xo(bt(t,n,e));return!!(s!==r&&o!==a||s===0&&_o(i,t,e)||r===0&&_o(i,n,e)||o===0&&_o(t,i,n)||a===0&&_o(t,e,n))}function _o(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function xo(i){return i>0?1:i<0?-1:0}function Gv(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&ef(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function Ar(i,e){return bt(i.prev,i,i.next)<0?bt(i,e,i.next)>=0&&bt(i,i.prev,e)>=0:bt(i,e,i.prev)<0||bt(i,i.next,e)<0}function Wv(i,e){let t=i,n=!1;const s=(i.x+e.x)/2,r=(i.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function tf(i,e){const t=new Gc(i.i,i.x,i.y),n=new Gc(e.i,e.x,e.y),s=i.next,r=e.prev;return i.next=e,e.prev=i,t.next=s,s.prev=t,n.next=t,t.prev=n,r.next=n,n.prev=r,n}function vh(i,e,t,n){const s=new Gc(i,e,t);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function Rr(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function Gc(i,e,t){this.i=i,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Xv(i,e,t,n){let s=0;for(let r=e,o=t-n;r<t;r+=n)s+=(i[o]-i[r])*(i[r+1]+i[o+1]),o=r;return s}class Ti{static area(e){const t=e.length;let n=0;for(let s=t-1,r=0;r<t;s=r++)n+=e[s].x*e[r].y-e[r].x*e[s].y;return n*.5}static isClockWise(e){return Ti.area(e)<0}static triangulateShape(e,t){const n=[],s=[],r=[];yh(e),Mh(n,e);let o=e.length;t.forEach(yh);for(let c=0;c<t.length;c++)s.push(o),o+=t[c].length,Mh(n,t[c]);const a=Cv.triangulate(n,s);for(let c=0;c<a.length;c+=3)r.push(a.slice(c,c+3));return r}}function yh(i){const e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function Mh(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}class Rl extends Tt{constructor(e=new Pi([new se(.5,.5),new se(-.5,.5),new se(-.5,-.5),new se(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const n=this,s=[],r=[];for(let a=0,c=e.length;a<c;a++){const l=e[a];o(l)}this.setAttribute("position",new Ze(s,3)),this.setAttribute("uv",new Ze(r,2)),this.computeVertexNormals();function o(a){const c=[],l=t.curveSegments!==void 0?t.curveSegments:12,u=t.steps!==void 0?t.steps:1,h=t.depth!==void 0?t.depth:1;let d=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,g=t.bevelSize!==void 0?t.bevelSize:f-.1,_=t.bevelOffset!==void 0?t.bevelOffset:0,m=t.bevelSegments!==void 0?t.bevelSegments:3;const p=t.extrudePath,M=t.UVGenerator!==void 0?t.UVGenerator:qv;let v,x=!1,I,A,T,P;p&&(v=p.getSpacedPoints(u),x=!0,d=!1,I=p.computeFrenetFrames(u,!1),A=new R,T=new R,P=new R),d||(m=0,f=0,g=0,_=0);const b=a.extractPoints(l);let w=b.shape;const D=b.holes;if(!Ti.isClockWise(w)){w=w.reverse();for(let ee=0,re=D.length;ee<re;ee++){const C=D[ee];Ti.isClockWise(C)&&(D[ee]=C.reverse())}}const O=Ti.triangulateShape(w,D),Y=w;for(let ee=0,re=D.length;ee<re;ee++){const C=D[ee];w=w.concat(C)}function q(ee,re,C){return re||console.error("THREE.ExtrudeGeometry: vec does not exist"),ee.clone().addScaledVector(re,C)}const j=w.length,Q=O.length;function W(ee,re,C){let Te,ie,_e;const ue=ee.x-re.x,Oe=ee.y-re.y,L=C.x-ee.x,S=C.y-ee.y,y=ue*ue+Oe*Oe,N=ue*S-Oe*L;if(Math.abs(N)>Number.EPSILON){const B=Math.sqrt(y),K=Math.sqrt(L*L+S*S),$=re.x-Oe/B,Ee=re.y+ue/B,de=C.x-S/K,Se=C.y+L/K,$e=((de-$)*S-(Se-Ee)*L)/(ue*S-Oe*L);Te=$+ue*$e-ee.x,ie=Ee+Oe*$e-ee.y;const oe=Te*Te+ie*ie;if(oe<=2)return new se(Te,ie);_e=Math.sqrt(oe/2)}else{let B=!1;ue>Number.EPSILON?L>Number.EPSILON&&(B=!0):ue<-Number.EPSILON?L<-Number.EPSILON&&(B=!0):Math.sign(Oe)===Math.sign(S)&&(B=!0),B?(Te=-Oe,ie=ue,_e=Math.sqrt(y)):(Te=ue,ie=Oe,_e=Math.sqrt(y/2))}return new se(Te/_e,ie/_e)}const le=[];for(let ee=0,re=Y.length,C=re-1,Te=ee+1;ee<re;ee++,C++,Te++)C===re&&(C=0),Te===re&&(Te=0),le[ee]=W(Y[ee],Y[C],Y[Te]);const pe=[];let Me,Le=le.concat();for(let ee=0,re=D.length;ee<re;ee++){const C=D[ee];Me=[];for(let Te=0,ie=C.length,_e=ie-1,ue=Te+1;Te<ie;Te++,_e++,ue++)_e===ie&&(_e=0),ue===ie&&(ue=0),Me[Te]=W(C[Te],C[_e],C[ue]);pe.push(Me),Le=Le.concat(Me)}for(let ee=0;ee<m;ee++){const re=ee/m,C=f*Math.cos(re*Math.PI/2),Te=g*Math.sin(re*Math.PI/2)+_;for(let ie=0,_e=Y.length;ie<_e;ie++){const ue=q(Y[ie],le[ie],Te);X(ue.x,ue.y,-C)}for(let ie=0,_e=D.length;ie<_e;ie++){const ue=D[ie];Me=pe[ie];for(let Oe=0,L=ue.length;Oe<L;Oe++){const S=q(ue[Oe],Me[Oe],Te);X(S.x,S.y,-C)}}}const qe=g+_;for(let ee=0;ee<j;ee++){const re=d?q(w[ee],Le[ee],qe):w[ee];x?(T.copy(I.normals[0]).multiplyScalar(re.x),A.copy(I.binormals[0]).multiplyScalar(re.y),P.copy(v[0]).add(T).add(A),X(P.x,P.y,P.z)):X(re.x,re.y,0)}for(let ee=1;ee<=u;ee++)for(let re=0;re<j;re++){const C=d?q(w[re],Le[re],qe):w[re];x?(T.copy(I.normals[ee]).multiplyScalar(C.x),A.copy(I.binormals[ee]).multiplyScalar(C.y),P.copy(v[ee]).add(T).add(A),X(P.x,P.y,P.z)):X(C.x,C.y,h/u*ee)}for(let ee=m-1;ee>=0;ee--){const re=ee/m,C=f*Math.cos(re*Math.PI/2),Te=g*Math.sin(re*Math.PI/2)+_;for(let ie=0,_e=Y.length;ie<_e;ie++){const ue=q(Y[ie],le[ie],Te);X(ue.x,ue.y,h+C)}for(let ie=0,_e=D.length;ie<_e;ie++){const ue=D[ie];Me=pe[ie];for(let Oe=0,L=ue.length;Oe<L;Oe++){const S=q(ue[Oe],Me[Oe],Te);x?X(S.x,S.y+v[u-1].y,v[u-1].x+C):X(S.x,S.y,h+C)}}}J(),ae();function J(){const ee=s.length/3;if(d){let re=0,C=j*re;for(let Te=0;Te<Q;Te++){const ie=O[Te];he(ie[2]+C,ie[1]+C,ie[0]+C)}re=u+m*2,C=j*re;for(let Te=0;Te<Q;Te++){const ie=O[Te];he(ie[0]+C,ie[1]+C,ie[2]+C)}}else{for(let re=0;re<Q;re++){const C=O[re];he(C[2],C[1],C[0])}for(let re=0;re<Q;re++){const C=O[re];he(C[0]+j*u,C[1]+j*u,C[2]+j*u)}}n.addGroup(ee,s.length/3-ee,0)}function ae(){const ee=s.length/3;let re=0;we(Y,re),re+=Y.length;for(let C=0,Te=D.length;C<Te;C++){const ie=D[C];we(ie,re),re+=ie.length}n.addGroup(ee,s.length/3-ee,1)}function we(ee,re){let C=ee.length;for(;--C>=0;){const Te=C;let ie=C-1;ie<0&&(ie=ee.length-1);for(let _e=0,ue=u+m*2;_e<ue;_e++){const Oe=j*_e,L=j*(_e+1),S=re+Te+Oe,y=re+ie+Oe,N=re+ie+L,B=re+Te+L;Ae(S,y,N,B)}}}function X(ee,re,C){c.push(ee),c.push(re),c.push(C)}function he(ee,re,C){Ie(ee),Ie(re),Ie(C);const Te=s.length/3,ie=M.generateTopUV(n,s,Te-3,Te-2,Te-1);Je(ie[0]),Je(ie[1]),Je(ie[2])}function Ae(ee,re,C,Te){Ie(ee),Ie(re),Ie(Te),Ie(re),Ie(C),Ie(Te);const ie=s.length/3,_e=M.generateSideWallUV(n,s,ie-6,ie-3,ie-2,ie-1);Je(_e[0]),Je(_e[1]),Je(_e[3]),Je(_e[1]),Je(_e[2]),Je(_e[3])}function Ie(ee){s.push(c[ee*3+0]),s.push(c[ee*3+1]),s.push(c[ee*3+2])}function Je(ee){r.push(ee.x),r.push(ee.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return $v(t,n,e)}static fromJSON(e,t){const n=[];for(let r=0,o=e.shapes.length;r<o;r++){const a=t[e.shapes[r]];n.push(a)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new Bo[s.type]().fromJSON(s)),new Rl(n,e.options)}}const qv={generateTopUV:function(i,e,t,n,s){const r=e[t*3],o=e[t*3+1],a=e[n*3],c=e[n*3+1],l=e[s*3],u=e[s*3+1];return[new se(r,o),new se(a,c),new se(l,u)]},generateSideWallUV:function(i,e,t,n,s,r){const o=e[t*3],a=e[t*3+1],c=e[t*3+2],l=e[n*3],u=e[n*3+1],h=e[n*3+2],d=e[s*3],f=e[s*3+1],g=e[s*3+2],_=e[r*3],m=e[r*3+1],p=e[r*3+2];return Math.abs(a-u)<Math.abs(o-l)?[new se(o,1-c),new se(l,1-h),new se(d,1-g),new se(_,1-p)]:[new se(a,1-c),new se(u,1-h),new se(f,1-g),new se(m,1-p)]}};function $v(i,e,t){if(t.shapes=[],Array.isArray(i))for(let n=0,s=i.length;n<s;n++){const r=i[n];t.shapes.push(r.uuid)}else t.shapes.push(i.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class Zo extends Nr{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Zo(e.radius,e.detail)}}class Jo extends Nr{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Jo(e.radius,e.detail)}}class es extends Tt{constructor(e=new Pi([new se(0,.5),new se(-.5,-.5),new se(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const n=[],s=[],r=[],o=[];let a=0,c=0;if(Array.isArray(e)===!1)l(e);else for(let u=0;u<e.length;u++)l(e[u]),this.addGroup(a,c,u),a+=c,c=0;this.setIndex(n),this.setAttribute("position",new Ze(s,3)),this.setAttribute("normal",new Ze(r,3)),this.setAttribute("uv",new Ze(o,2));function l(u){const h=s.length/3,d=u.extractPoints(t);let f=d.shape;const g=d.holes;Ti.isClockWise(f)===!1&&(f=f.reverse());for(let m=0,p=g.length;m<p;m++){const M=g[m];Ti.isClockWise(M)===!0&&(g[m]=M.reverse())}const _=Ti.triangulateShape(f,g);for(let m=0,p=g.length;m<p;m++){const M=g[m];f=f.concat(M)}for(let m=0,p=f.length;m<p;m++){const M=f[m];s.push(M.x,M.y,0),r.push(0,0,1),o.push(M.x,M.y)}for(let m=0,p=_.length;m<p;m++){const M=_[m],v=M[0]+h,x=M[1]+h,I=M[2]+h;n.push(v,x,I),c+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Yv(t,e)}static fromJSON(e,t){const n=[];for(let s=0,r=e.shapes.length;s<r;s++){const o=t[e.shapes[s]];n.push(o)}return new es(n,e.curveSegments)}}function Yv(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){const s=i[t];e.shapes.push(s.uuid)}else e.shapes.push(i.uuid);return e}class We extends Tt{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const c=Math.min(o+a,Math.PI);let l=0;const u=[],h=new R,d=new R,f=[],g=[],_=[],m=[];for(let p=0;p<=n;p++){const M=[],v=p/n;let x=0;p===0&&o===0?x=.5/t:p===n&&c===Math.PI&&(x=-.5/t);for(let I=0;I<=t;I++){const A=I/t;h.x=-e*Math.cos(s+A*r)*Math.sin(o+v*a),h.y=e*Math.cos(o+v*a),h.z=e*Math.sin(s+A*r)*Math.sin(o+v*a),g.push(h.x,h.y,h.z),d.copy(h).normalize(),_.push(d.x,d.y,d.z),m.push(A+x,1-v),M.push(l++)}u.push(M)}for(let p=0;p<n;p++)for(let M=0;M<t;M++){const v=u[p][M+1],x=u[p][M],I=u[p+1][M],A=u[p+1][M+1];(p!==0||o>0)&&f.push(v,x,A),(p!==n-1||c<Math.PI)&&f.push(x,I,A)}this.setIndex(f),this.setAttribute("position",new Ze(g,3)),this.setAttribute("normal",new Ze(_,3)),this.setAttribute("uv",new Ze(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new We(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Li extends Tt{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);const o=[],a=[],c=[],l=[],u=new R,h=new R,d=new R;for(let f=0;f<=n;f++)for(let g=0;g<=s;g++){const _=g/s*r,m=f/n*Math.PI*2;h.x=(e+t*Math.cos(m))*Math.cos(_),h.y=(e+t*Math.cos(m))*Math.sin(_),h.z=t*Math.sin(m),a.push(h.x,h.y,h.z),u.x=e*Math.cos(_),u.y=e*Math.sin(_),d.subVectors(h,u).normalize(),c.push(d.x,d.y,d.z),l.push(g/s),l.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=s;g++){const _=(s+1)*f+g-1,m=(s+1)*(f-1)+g-1,p=(s+1)*(f-1)+g,M=(s+1)*f+g;o.push(_,m,M),o.push(m,p,M)}this.setIndex(o),this.setAttribute("position",new Ze(a,3)),this.setAttribute("normal",new Ze(c,3)),this.setAttribute("uv",new Ze(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Li(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class Cl extends Tt{constructor(e=1,t=.4,n=64,s=8,r=2,o=3){super(),this.type="TorusKnotGeometry",this.parameters={radius:e,tube:t,tubularSegments:n,radialSegments:s,p:r,q:o},n=Math.floor(n),s=Math.floor(s);const a=[],c=[],l=[],u=[],h=new R,d=new R,f=new R,g=new R,_=new R,m=new R,p=new R;for(let v=0;v<=n;++v){const x=v/n*r*Math.PI*2;M(x,r,o,e,f),M(x+.01,r,o,e,g),m.subVectors(g,f),p.addVectors(g,f),_.crossVectors(m,p),p.crossVectors(_,m),_.normalize(),p.normalize();for(let I=0;I<=s;++I){const A=I/s*Math.PI*2,T=-t*Math.cos(A),P=t*Math.sin(A);h.x=f.x+(T*p.x+P*_.x),h.y=f.y+(T*p.y+P*_.y),h.z=f.z+(T*p.z+P*_.z),c.push(h.x,h.y,h.z),d.subVectors(h,f).normalize(),l.push(d.x,d.y,d.z),u.push(v/n),u.push(I/s)}}for(let v=1;v<=n;v++)for(let x=1;x<=s;x++){const I=(s+1)*(v-1)+(x-1),A=(s+1)*v+(x-1),T=(s+1)*v+x,P=(s+1)*(v-1)+x;a.push(I,A,P),a.push(A,T,P)}this.setIndex(a),this.setAttribute("position",new Ze(c,3)),this.setAttribute("normal",new Ze(l,3)),this.setAttribute("uv",new Ze(u,2));function M(v,x,I,A,T){const P=Math.cos(v),b=Math.sin(v),w=I/x*v,D=Math.cos(w);T.x=A*(2+D)*.5*P,T.y=A*(2+D)*b*.5,T.z=A*Math.sin(w)*.5}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Cl(e.radius,e.tube,e.tubularSegments,e.radialSegments,e.p,e.q)}}class Ws extends Tt{constructor(e=new Zd(new R(-1,-1,0),new R(-1,1,0),new R(1,1,0)),t=64,n=1,s=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:n,radialSegments:s,closed:r};const o=e.computeFrenetFrames(t,r);this.tangents=o.tangents,this.normals=o.normals,this.binormals=o.binormals;const a=new R,c=new R,l=new se;let u=new R;const h=[],d=[],f=[],g=[];_(),this.setIndex(g),this.setAttribute("position",new Ze(h,3)),this.setAttribute("normal",new Ze(d,3)),this.setAttribute("uv",new Ze(f,2));function _(){for(let v=0;v<t;v++)m(v);m(r===!1?t:0),M(),p()}function m(v){u=e.getPointAt(v/t,u);const x=o.normals[v],I=o.binormals[v];for(let A=0;A<=s;A++){const T=A/s*Math.PI*2,P=Math.sin(T),b=-Math.cos(T);c.x=b*x.x+P*I.x,c.y=b*x.y+P*I.y,c.z=b*x.z+P*I.z,c.normalize(),d.push(c.x,c.y,c.z),a.x=u.x+n*c.x,a.y=u.y+n*c.y,a.z=u.z+n*c.z,h.push(a.x,a.y,a.z)}}function p(){for(let v=1;v<=t;v++)for(let x=1;x<=s;x++){const I=(s+1)*(v-1)+(x-1),A=(s+1)*v+(x-1),T=(s+1)*v+x,P=(s+1)*(v-1)+x;g.push(I,A,P),g.push(A,T,P)}}function M(){for(let v=0;v<=t;v++)for(let x=0;x<=s;x++)l.x=v/t,l.y=x/s,f.push(l.x,l.y)}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new Ws(new Bo[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}}class Be extends bn{static get type(){return"MeshStandardMaterial"}constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new Fe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Fe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=pl,this.normalScale=new se(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new fn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Vn extends Be{static get type(){return"MeshPhysicalMaterial"}constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new se(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return It(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Fe(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Fe(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Fe(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class Sh extends bn{static get type(){return"MeshLambertMaterial"}constructor(e){super(),this.isMeshLambertMaterial=!0,this.color=new Fe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Fe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=pl,this.normalScale=new se(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new fn,this.combine=ol,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}function vo(i,e,t){return!i||!t&&i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function jv(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function Kv(i){function e(s,r){return i[s]-i[r]}const t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function wh(i,e,t){const n=i.length,s=new i.constructor(n);for(let r=0,o=0;o!==n;++r){const a=t[r]*e;for(let c=0;c!==e;++c)s[o++]=i[a+c]}return s}function nf(i,e,t,n){let s=1,r=i[0];for(;r!==void 0&&r[n]===void 0;)r=i[s++];if(r===void 0)return;let o=r[n];if(o!==void 0)if(Array.isArray(o))do o=r[n],o!==void 0&&(e.push(r.time),t.push.apply(t,o)),r=i[s++];while(r!==void 0);else if(o.toArray!==void 0)do o=r[n],o!==void 0&&(e.push(r.time),o.toArray(t,t.length)),r=i[s++];while(r!==void 0);else do o=r[n],o!==void 0&&(e.push(r.time),t.push(o)),r=i[s++];while(r!==void 0)}class Ur{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,s=t[n],r=t[n-1];n:{e:{let o;t:{i:if(!(e<s)){for(let a=n+2;;){if(s===void 0){if(e<r)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=t[++n],e<s)break e}o=t.length;break t}if(!(e>=r)){const a=t[1];e<a&&(n=2,r=a);for(let c=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===c)break;if(s=r,r=t[--n-1],e>=r)break e}o=n,n=0;break t}break n}for(;n<o;){const a=n+o>>>1;e<t[a]?o=a:n=a+1}if(s=t[n],r=t[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s;for(let o=0;o!==s;++o)t[o]=n[r+o];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}}class Zv extends Ur{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:ru,endingEnd:ru}}intervalChanged_(e,t,n){const s=this.parameterPositions;let r=e-2,o=e+1,a=s[r],c=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case ou:r=e,a=2*t-n;break;case au:r=s.length-2,a=t+s[r]-s[r+1];break;default:r=e,a=n}if(c===void 0)switch(this.getSettings_().endingEnd){case ou:o=e,c=2*n-t;break;case au:o=1,c=n+s[1]-s[0];break;default:o=e-1,c=t}const l=(n-t)*.5,u=this.valueSize;this._weightPrev=l/(t-a),this._weightNext=l/(c-n),this._offsetPrev=r*u,this._offsetNext=o*u}interpolate_(e,t,n,s){const r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=this._offsetPrev,h=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-t)/(s-t),_=g*g,m=_*g,p=-d*m+2*d*_-d*g,M=(1+d)*m+(-1.5-2*d)*_+(-.5+d)*g+1,v=(-1-f)*m+(1.5+f)*_+.5*g,x=f*m-f*_;for(let I=0;I!==a;++I)r[I]=p*o[u+I]+M*o[l+I]+v*o[c+I]+x*o[h+I];return r}}class Jv extends Ur{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){const r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=(n-t)/(s-t),h=1-u;for(let d=0;d!==a;++d)r[d]=o[l+d]*h+o[c+d]*u;return r}}class Qv extends Ur{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}}class Gn{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=vo(t,this.TimeBufferType),this.values=vo(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:vo(e.times,Array),values:vo(e.values,Array)};const s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Qv(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Jv(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Zv(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Mr:t=this.InterpolantFactoryMethodDiscrete;break;case Sr:t=this.InterpolantFactoryMethodLinear;break;case aa:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Mr;case this.InterpolantFactoryMethodLinear:return Sr;case this.InterpolantFactoryMethodSmooth:return aa}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e}return this}trim(e,t){const n=this.times,s=n.length;let r=0,o=s-1;for(;r!==s&&n[r]<e;)++r;for(;o!==-1&&n[o]>t;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);const a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==r;a++){const c=n[a];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,c),e=!1;break}if(o!==null&&o>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,c,o),e=!1;break}o=c}if(s!==void 0&&jv(s))for(let a=0,c=s.length;a!==c;++a){const l=s[a];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,l),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===aa,r=e.length-1;let o=1;for(let a=1;a<r;++a){let c=!1;const l=e[a],u=e[a+1];if(l!==u&&(a!==1||l!==e[0]))if(s)c=!0;else{const h=a*n,d=h-n,f=h+n;for(let g=0;g!==n;++g){const _=t[h+g];if(_!==t[d+g]||_!==t[f+g]){c=!0;break}}}if(c){if(a!==o){e[o]=e[a];const h=a*n,d=o*n;for(let f=0;f!==n;++f)t[d+f]=t[h+f]}++o}}if(r>0){e[o]=e[r];for(let a=r*n,c=o*n,l=0;l!==n;++l)t[c+l]=t[a+l];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,s}}Gn.prototype.TimeBufferType=Float32Array;Gn.prototype.ValueBufferType=Float32Array;Gn.prototype.DefaultInterpolation=Sr;class Xs extends Gn{constructor(e,t,n){super(e,t,n)}}Xs.prototype.ValueTypeName="bool";Xs.prototype.ValueBufferType=Array;Xs.prototype.DefaultInterpolation=Mr;Xs.prototype.InterpolantFactoryMethodLinear=void 0;Xs.prototype.InterpolantFactoryMethodSmooth=void 0;class sf extends Gn{}sf.prototype.ValueTypeName="color";class Fs extends Gn{}Fs.prototype.ValueTypeName="number";class ey extends Ur{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){const r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=(n-t)/(s-t);let l=e*a;for(let u=l+a;l!==u;l+=4)Un.slerpFlat(r,0,o,l-a,o,l,c);return r}}class Os extends Gn{InterpolantFactoryMethodLinear(e){return new ey(this.times,this.values,this.getValueSize(),e)}}Os.prototype.ValueTypeName="quaternion";Os.prototype.InterpolantFactoryMethodSmooth=void 0;class qs extends Gn{constructor(e,t,n){super(e,t,n)}}qs.prototype.ValueTypeName="string";qs.prototype.ValueBufferType=Array;qs.prototype.DefaultInterpolation=Mr;qs.prototype.InterpolantFactoryMethodLinear=void 0;qs.prototype.InterpolantFactoryMethodSmooth=void 0;class Bs extends Gn{}Bs.prototype.ValueTypeName="vector";class ty{constructor(e="",t=-1,n=[],s=bp){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=wn(),this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,s=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(iy(n[o]).scale(s));const r=new this(e.name,e.duration,t,e.blendMode);return r.uuid=e.uuid,r}static toJSON(e){const t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let r=0,o=n.length;r!==o;++r)t.push(Gn.toJSON(n[r]));return s}static CreateFromMorphTargetSequence(e,t,n,s){const r=t.length,o=[];for(let a=0;a<r;a++){let c=[],l=[];c.push((a+r-1)%r,a,(a+1)%r),l.push(0,1,0);const u=Kv(c);c=wh(c,1,u),l=wh(l,1,u),!s&&c[0]===0&&(c.push(r),l.push(l[0])),o.push(new Fs(".morphTargetInfluences["+t[a].name+"]",c,l).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const s={},r=/^([\w-]*?)([\d]+)$/;for(let a=0,c=e.length;a<c;a++){const l=e[a],u=l.name.match(r);if(u&&u.length>1){const h=u[1];let d=s[h];d||(s[h]=d=[]),d.push(l)}}const o=[];for(const a in s)o.push(this.CreateFromMorphTargetSequence(a,s[a],t,n));return o}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;const n=function(h,d,f,g,_){if(f.length!==0){const m=[],p=[];nf(f,m,p,g),m.length!==0&&_.push(new h(d,m,p))}},s=[],r=e.name||"default",o=e.fps||30,a=e.blendMode;let c=e.length||-1;const l=e.hierarchy||[];for(let h=0;h<l.length;h++){const d=l[h].keys;if(!(!d||d.length===0))if(d[0].morphTargets){const f={};let g;for(g=0;g<d.length;g++)if(d[g].morphTargets)for(let _=0;_<d[g].morphTargets.length;_++)f[d[g].morphTargets[_]]=-1;for(const _ in f){const m=[],p=[];for(let M=0;M!==d[g].morphTargets.length;++M){const v=d[g];m.push(v.time),p.push(v.morphTarget===_?1:0)}s.push(new Fs(".morphTargetInfluence["+_+"]",m,p))}c=f.length*o}else{const f=".bones["+t[h].name+"]";n(Bs,f+".position",d,"pos",s),n(Os,f+".quaternion",d,"rot",s),n(Bs,f+".scale",d,"scl",s)}}return s.length===0?null:new this(r,c,s,a)}resetDuration(){const e=this.tracks;let t=0;for(let n=0,s=e.length;n!==s;++n){const r=this.tracks[n];t=Math.max(t,r.times[r.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}}function ny(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Fs;case"vector":case"vector2":case"vector3":case"vector4":return Bs;case"color":return sf;case"quaternion":return Os;case"bool":case"boolean":return Xs;case"string":return qs}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function iy(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=ny(i.type);if(i.times===void 0){const t=[],n=[];nf(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}const wi={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class sy{constructor(e,t,n){const s=this;let r=!1,o=0,a=0,c;const l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(u){a++,r===!1&&s.onStart!==void 0&&s.onStart(u,o,a),r=!0},this.itemEnd=function(u){o++,s.onProgress!==void 0&&s.onProgress(u,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return c?c(u):u},this.setURLModifier=function(u){return c=u,this},this.addHandler=function(u,h){return l.push(u,h),this},this.removeHandler=function(u){const h=l.indexOf(u);return h!==-1&&l.splice(h,2),this},this.getHandler=function(u){for(let h=0,d=l.length;h<d;h+=2){const f=l[h],g=l[h+1];if(f.global&&(f.lastIndex=0),f.test(u))return g}return null}}}const ry=new sy;class $s{constructor(e){this.manager=e!==void 0?e:ry,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}}$s.DEFAULT_MATERIAL_NAME="__DEFAULT";const Zn={};class oy extends Error{constructor(e,t){super(e),this.response=t}}class rf extends $s{constructor(e){super(e)}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=wi.get(e);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(Zn[e]!==void 0){Zn[e].push({onLoad:t,onProgress:n,onError:s});return}Zn[e]=[],Zn[e].push({onLoad:t,onProgress:n,onError:s});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),a=this.mimeType,c=this.responseType;fetch(o).then(l=>{if(l.status===200||l.status===0){if(l.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;const u=Zn[e],h=l.body.getReader(),d=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),f=d?parseInt(d):0,g=f!==0;let _=0;const m=new ReadableStream({start(p){M();function M(){h.read().then(({done:v,value:x})=>{if(v)p.close();else{_+=x.byteLength;const I=new ProgressEvent("progress",{lengthComputable:g,loaded:_,total:f});for(let A=0,T=u.length;A<T;A++){const P=u[A];P.onProgress&&P.onProgress(I)}p.enqueue(x),M()}},v=>{p.error(v)})}}});return new Response(m)}else throw new oy(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then(l=>{switch(c){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then(u=>new DOMParser().parseFromString(u,a));case"json":return l.json();default:if(a===void 0)return l.text();{const h=/charset="?([^;"\s]*)"?/i.exec(a),d=h&&h[1]?h[1].toLowerCase():void 0,f=new TextDecoder(d);return l.arrayBuffer().then(g=>f.decode(g))}}}).then(l=>{wi.add(e,l);const u=Zn[e];delete Zn[e];for(let h=0,d=u.length;h<d;h++){const f=u[h];f.onLoad&&f.onLoad(l)}}).catch(l=>{const u=Zn[e];if(u===void 0)throw this.manager.itemError(e),l;delete Zn[e];for(let h=0,d=u.length;h<d;h++){const f=u[h];f.onError&&f.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}}class ay extends $s{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=this,o=wi.get(e);if(o!==void 0)return r.manager.itemStart(e),setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o;const a=wr("img");function c(){u(),wi.add(e,this),t&&t(this),r.manager.itemEnd(e)}function l(h){u(),s&&s(h),r.manager.itemError(e),r.manager.itemEnd(e)}function u(){a.removeEventListener("load",c,!1),a.removeEventListener("error",l,!1)}return a.addEventListener("load",c,!1),a.addEventListener("error",l,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),r.manager.itemStart(e),a.src=e,a}}class cy extends $s{constructor(e){super(e)}load(e,t,n,s){const r=new Nt,o=new ay(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){r.image=a,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}}class Qo extends St{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Fe(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class ly extends Qo{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(St.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Fe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const Va=new He,bh=new R,Eh=new R;class Pl{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new se(512,512),this.map=null,this.mapPass=null,this.matrix=new He,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new _l,this._frameExtents=new se(1,1),this._viewportCount=1,this._viewports=[new at(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;bh.setFromMatrixPosition(e.matrixWorld),t.position.copy(bh),Eh.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Eh),t.updateMatrixWorld(),Va.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Va),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Va)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class uy extends Pl{constructor(){super(new Qt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){const t=this.camera,n=Us*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height,r=e.distance||t.far;(n!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=n,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class hy extends Qo{constructor(e,t,n=0,s=Math.PI/3,r=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(St.DEFAULT_UP),this.updateMatrix(),this.target=new St,this.distance=n,this.angle=s,this.penumbra=r,this.decay=o,this.map=null,this.shadow=new uy}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const Th=new He,lr=new R,Ga=new R;class dy extends Pl{constructor(){super(new Qt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new se(4,2),this._viewportCount=6,this._viewports=[new at(2,1,1,1),new at(0,1,1,1),new at(3,1,1,1),new at(1,1,1,1),new at(3,0,1,1),new at(1,0,1,1)],this._cubeDirections=[new R(1,0,0),new R(-1,0,0),new R(0,0,1),new R(0,0,-1),new R(0,1,0),new R(0,-1,0)],this._cubeUps=[new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,0,1),new R(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,s=this.matrix,r=e.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),lr.setFromMatrixPosition(e.matrixWorld),n.position.copy(lr),Ga.copy(n.position),Ga.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(Ga),n.updateMatrixWorld(),s.makeTranslation(-lr.x,-lr.y,-lr.z),Th.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Th)}}class fy extends Qo{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new dy}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class py extends Pl{constructor(){super(new xl(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class of extends Qo{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(St.DEFAULT_UP),this.updateMatrix(),this.target=new St,this.shadow=new py}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class vr{static decodeText(e){if(console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."),typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,s=e.length;n<s;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}class my extends $s{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=this,o=wi.get(e);if(o!==void 0){if(r.manager.itemStart(e),o.then){o.then(l=>{t&&t(l),r.manager.itemEnd(e)}).catch(l=>{s&&s(l)});return}return setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o}const a={};a.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",a.headers=this.requestHeader;const c=fetch(e,a).then(function(l){return l.blob()}).then(function(l){return createImageBitmap(l,Object.assign(r.options,{colorSpaceConversion:"none"}))}).then(function(l){return wi.add(e,l),t&&t(l),r.manager.itemEnd(e),l}).catch(function(l){s&&s(l),wi.remove(e),r.manager.itemError(e),r.manager.itemEnd(e)});wi.add(e,c),r.manager.itemStart(e)}}const Ll="\\[\\]\\.:\\/",gy=new RegExp("["+Ll+"]","g"),Il="[^"+Ll+"]",_y="[^"+Ll.replace("\\.","")+"]",xy=/((?:WC+[\/:])*)/.source.replace("WC",Il),vy=/(WCOD+)?/.source.replace("WCOD",_y),yy=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Il),My=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Il),Sy=new RegExp("^"+xy+vy+yy+My+"$"),wy=["material","materials","bones","map"];class by{constructor(e,t,n){const s=n||dt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class dt{constructor(e,t,n){this.path=t,this.parsedPath=n||dt.parseTrackName(t),this.node=dt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new dt.Composite(e,t,n):new dt(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(gy,"")}static parseTrackName(e){const t=Sy.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){const r=n.nodeName.substring(s+1);wy.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(r){for(let o=0;o<r.length;o++){const a=r[o];if(a.name===t||a.uuid===t)return a;const c=n(a.children);if(c)return c}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,s=t.propertyName;let r=t.propertyIndex;if(e||(e=dt.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let l=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let u=0;u<e.length;u++)if(e[u].name===l){l=u;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(l!==void 0){if(e[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[l]}}const o=e[s];if(o===void 0){const l=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}dt.Composite=by;dt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};dt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};dt.prototype.GetterByBindingType=[dt.prototype._getValue_direct,dt.prototype._getValue_array,dt.prototype._getValue_arrayElement,dt.prototype._getValue_toArray];dt.prototype.SetterByBindingTypeAndVersioning=[[dt.prototype._setValue_direct,dt.prototype._setValue_direct_setNeedsUpdate,dt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[dt.prototype._setValue_array,dt.prototype._setValue_array_setNeedsUpdate,dt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[dt.prototype._setValue_arrayElement,dt.prototype._setValue_arrayElement_setNeedsUpdate,dt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[dt.prototype._setValue_fromArray,dt.prototype._setValue_fromArray_setNeedsUpdate,dt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:rl}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=rl);function Ah(i,e){if(e===Ep)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===kc||e===Sd){let t=i.getIndex();if(t===null){const o=[],a=i.getAttribute("position");if(a!==void 0){for(let c=0;c<a.count;c++)o.push(c);i.setIndex(o),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}const n=t.count-2,s=[];if(e===kc)for(let o=1;o<=n;o++)s.push(t.getX(0)),s.push(t.getX(o)),s.push(t.getX(o+1));else for(let o=0;o<n;o++)o%2===0?(s.push(t.getX(o)),s.push(t.getX(o+1)),s.push(t.getX(o+2))):(s.push(t.getX(o+2)),s.push(t.getX(o+1)),s.push(t.getX(o)));s.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const r=i.clone();return r.setIndex(s),r.clearGroups(),r}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}class Ey extends $s{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new Py(t)}),this.register(function(t){return new Ly(t)}),this.register(function(t){return new zy(t)}),this.register(function(t){return new Hy(t)}),this.register(function(t){return new Vy(t)}),this.register(function(t){return new Dy(t)}),this.register(function(t){return new Ny(t)}),this.register(function(t){return new Uy(t)}),this.register(function(t){return new ky(t)}),this.register(function(t){return new Cy(t)}),this.register(function(t){return new Fy(t)}),this.register(function(t){return new Iy(t)}),this.register(function(t){return new By(t)}),this.register(function(t){return new Oy(t)}),this.register(function(t){return new Ay(t)}),this.register(function(t){return new Gy(t)}),this.register(function(t){return new Wy(t)})}load(e,t,n,s){const r=this;let o;if(this.resourcePath!=="")o=this.resourcePath;else if(this.path!==""){const l=vr.extractUrlBase(e);o=vr.resolveURL(l,this.path)}else o=vr.extractUrlBase(e);this.manager.itemStart(e);const a=function(l){s?s(l):console.error(l),r.manager.itemError(e),r.manager.itemEnd(e)},c=new rf(this.manager);c.setPath(this.path),c.setResponseType("arraybuffer"),c.setRequestHeader(this.requestHeader),c.setWithCredentials(this.withCredentials),c.load(e,function(l){try{r.parse(l,o,function(u){t(u),r.manager.itemEnd(e)},a)}catch(u){a(u)}},n,a)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,s){let r;const o={},a={},c=new TextDecoder;if(typeof e=="string")r=JSON.parse(e);else if(e instanceof ArrayBuffer)if(c.decode(new Uint8Array(e,0,4))===af){try{o[tt.KHR_BINARY_GLTF]=new Xy(e)}catch(h){s&&s(h);return}r=JSON.parse(o[tt.KHR_BINARY_GLTF].content)}else r=JSON.parse(c.decode(e));else r=e;if(r.asset===void 0||r.asset.version[0]<2){s&&s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const l=new sM(r,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let u=0;u<this.pluginCallbacks.length;u++){const h=this.pluginCallbacks[u](l);h.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),a[h.name]=h,o[h.name]=!0}if(r.extensionsUsed)for(let u=0;u<r.extensionsUsed.length;++u){const h=r.extensionsUsed[u],d=r.extensionsRequired||[];switch(h){case tt.KHR_MATERIALS_UNLIT:o[h]=new Ry;break;case tt.KHR_DRACO_MESH_COMPRESSION:o[h]=new qy(r,this.dracoLoader);break;case tt.KHR_TEXTURE_TRANSFORM:o[h]=new $y;break;case tt.KHR_MESH_QUANTIZATION:o[h]=new Yy;break;default:d.indexOf(h)>=0&&a[h]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+h+'".')}}l.setExtensions(o),l.setPlugins(a),l.parse(n,s)}parseAsync(e,t){const n=this;return new Promise(function(s,r){n.parse(e,t,s,r)})}}function Ty(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}const tt={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class Ay{constructor(e){this.parser=e,this.name=tt.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const e=this.parser,t=this.parser.json.nodes||[];for(let n=0,s=t.length;n<s;n++){const r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){const t=this.parser,n="light:"+e;let s=t.cache.get(n);if(s)return s;const r=t.json,c=((r.extensions&&r.extensions[this.name]||{}).lights||[])[e];let l;const u=new Fe(16777215);c.color!==void 0&&u.setRGB(c.color[0],c.color[1],c.color[2],nn);const h=c.range!==void 0?c.range:0;switch(c.type){case"directional":l=new of(u),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new fy(u),l.distance=h;break;case"spot":l=new hy(u),l.distance=h,c.spot=c.spot||{},c.spot.innerConeAngle=c.spot.innerConeAngle!==void 0?c.spot.innerConeAngle:0,c.spot.outerConeAngle=c.spot.outerConeAngle!==void 0?c.spot.outerConeAngle:Math.PI/4,l.angle=c.spot.outerConeAngle,l.penumbra=1-c.spot.innerConeAngle/c.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+c.type)}return l.position.set(0,0,0),l.decay=2,Qn(l,c),c.intensity!==void 0&&(l.intensity=c.intensity),l.name=t.createUniqueName(c.name||"light_"+e),s=Promise.resolve(l),t.cache.add(n,s),s}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){const t=this,n=this.parser,r=n.json.nodes[e],a=(r.extensions&&r.extensions[this.name]||{}).light;return a===void 0?null:this._loadLight(a).then(function(c){return n._getNodeRef(t.cache,a,c)})}}class Ry{constructor(){this.name=tt.KHR_MATERIALS_UNLIT}getMaterialType(){return Dt}extendParams(e,t,n){const s=[];e.color=new Fe(1,1,1),e.opacity=1;const r=t.pbrMetallicRoughness;if(r){if(Array.isArray(r.baseColorFactor)){const o=r.baseColorFactor;e.color.setRGB(o[0],o[1],o[2],nn),e.opacity=o[3]}r.baseColorTexture!==void 0&&s.push(n.assignTexture(e,"map",r.baseColorTexture,Lt))}return Promise.all(s)}}class Cy{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){const s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=s.extensions[this.name].emissiveStrength;return r!==void 0&&(t.emissiveIntensity=r),Promise.resolve()}}class Py{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];if(o.clearcoatFactor!==void 0&&(t.clearcoat=o.clearcoatFactor),o.clearcoatTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatMap",o.clearcoatTexture)),o.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=o.clearcoatRoughnessFactor),o.clearcoatRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatRoughnessMap",o.clearcoatRoughnessTexture)),o.clearcoatNormalTexture!==void 0&&(r.push(n.assignTexture(t,"clearcoatNormalMap",o.clearcoatNormalTexture)),o.clearcoatNormalTexture.scale!==void 0)){const a=o.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new se(a,a)}return Promise.all(r)}}class Ly{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_DISPERSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=s.extensions[this.name];return t.dispersion=r.dispersion!==void 0?r.dispersion:0,Promise.resolve()}}class Iy{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];return o.iridescenceFactor!==void 0&&(t.iridescence=o.iridescenceFactor),o.iridescenceTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceMap",o.iridescenceTexture)),o.iridescenceIor!==void 0&&(t.iridescenceIOR=o.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),o.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=o.iridescenceThicknessMinimum),o.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=o.iridescenceThicknessMaximum),o.iridescenceThicknessTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceThicknessMap",o.iridescenceThicknessTexture)),Promise.all(r)}}class Dy{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_SHEEN}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[];t.sheenColor=new Fe(0,0,0),t.sheenRoughness=0,t.sheen=1;const o=s.extensions[this.name];if(o.sheenColorFactor!==void 0){const a=o.sheenColorFactor;t.sheenColor.setRGB(a[0],a[1],a[2],nn)}return o.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=o.sheenRoughnessFactor),o.sheenColorTexture!==void 0&&r.push(n.assignTexture(t,"sheenColorMap",o.sheenColorTexture,Lt)),o.sheenRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"sheenRoughnessMap",o.sheenRoughnessTexture)),Promise.all(r)}}class Ny{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];return o.transmissionFactor!==void 0&&(t.transmission=o.transmissionFactor),o.transmissionTexture!==void 0&&r.push(n.assignTexture(t,"transmissionMap",o.transmissionTexture)),Promise.all(r)}}class Uy{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_VOLUME}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];t.thickness=o.thicknessFactor!==void 0?o.thicknessFactor:0,o.thicknessTexture!==void 0&&r.push(n.assignTexture(t,"thicknessMap",o.thicknessTexture)),t.attenuationDistance=o.attenuationDistance||1/0;const a=o.attenuationColor||[1,1,1];return t.attenuationColor=new Fe().setRGB(a[0],a[1],a[2],nn),Promise.all(r)}}class ky{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_IOR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=s.extensions[this.name];return t.ior=r.ior!==void 0?r.ior:1.5,Promise.resolve()}}class Fy{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_SPECULAR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];t.specularIntensity=o.specularFactor!==void 0?o.specularFactor:1,o.specularTexture!==void 0&&r.push(n.assignTexture(t,"specularIntensityMap",o.specularTexture));const a=o.specularColorFactor||[1,1,1];return t.specularColor=new Fe().setRGB(a[0],a[1],a[2],nn),o.specularColorTexture!==void 0&&r.push(n.assignTexture(t,"specularColorMap",o.specularColorTexture,Lt)),Promise.all(r)}}class Oy{constructor(e){this.parser=e,this.name=tt.EXT_MATERIALS_BUMP}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];return t.bumpScale=o.bumpFactor!==void 0?o.bumpFactor:1,o.bumpTexture!==void 0&&r.push(n.assignTexture(t,"bumpMap",o.bumpTexture)),Promise.all(r)}}class By{constructor(e){this.parser=e,this.name=tt.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Vn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],o=s.extensions[this.name];return o.anisotropyStrength!==void 0&&(t.anisotropy=o.anisotropyStrength),o.anisotropyRotation!==void 0&&(t.anisotropyRotation=o.anisotropyRotation),o.anisotropyTexture!==void 0&&r.push(n.assignTexture(t,"anisotropyMap",o.anisotropyTexture)),Promise.all(r)}}class zy{constructor(e){this.parser=e,this.name=tt.KHR_TEXTURE_BASISU}loadTexture(e){const t=this.parser,n=t.json,s=n.textures[e];if(!s.extensions||!s.extensions[this.name])return null;const r=s.extensions[this.name],o=t.options.ktx2Loader;if(!o){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,r.source,o)}}class Hy{constructor(e){this.parser=e,this.name=tt.EXT_TEXTURE_WEBP,this.isSupported=null}loadTexture(e){const t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;const o=r.extensions[t],a=s.images[o.source];let c=n.textureLoader;if(a.uri){const l=n.options.manager.getHandler(a.uri);l!==null&&(c=l)}return this.detectSupport().then(function(l){if(l)return n.loadTextureImage(e,o.source,c);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){const t=new Image;t.src="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}}class Vy{constructor(e){this.parser=e,this.name=tt.EXT_TEXTURE_AVIF,this.isSupported=null}loadTexture(e){const t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;const o=r.extensions[t],a=s.images[o.source];let c=n.textureLoader;if(a.uri){const l=n.options.manager.getHandler(a.uri);l!==null&&(c=l)}return this.detectSupport().then(function(l){if(l)return n.loadTextureImage(e,o.source,c);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){const t=new Image;t.src="data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}}class Gy{constructor(e){this.name=tt.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){const t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){const s=n.extensions[this.name],r=this.parser.getDependency("buffer",s.buffer),o=this.parser.options.meshoptDecoder;if(!o||!o.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return r.then(function(a){const c=s.byteOffset||0,l=s.byteLength||0,u=s.count,h=s.byteStride,d=new Uint8Array(a,c,l);return o.decodeGltfBufferAsync?o.decodeGltfBufferAsync(u,h,d,s.mode,s.filter).then(function(f){return f.buffer}):o.ready.then(function(){const f=new ArrayBuffer(u*h);return o.decodeGltfBuffer(new Uint8Array(f),u,h,d,s.mode,s.filter),f})})}else return null}}class Wy{constructor(e){this.name=tt.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){const t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;const s=t.meshes[n.mesh];for(const l of s.primitives)if(l.mode!==_n.TRIANGLES&&l.mode!==_n.TRIANGLE_STRIP&&l.mode!==_n.TRIANGLE_FAN&&l.mode!==void 0)return null;const o=n.extensions[this.name].attributes,a=[],c={};for(const l in o)a.push(this.parser.getDependency("accessor",o[l]).then(u=>(c[l]=u,c[l])));return a.length<1?null:(a.push(this.parser.createNodeMesh(e)),Promise.all(a).then(l=>{const u=l.pop(),h=u.isGroup?u.children:[u],d=l[0].count,f=[];for(const g of h){const _=new He,m=new R,p=new Un,M=new R(1,1,1),v=new ko(g.geometry,g.material,d);for(let x=0;x<d;x++)c.TRANSLATION&&m.fromBufferAttribute(c.TRANSLATION,x),c.ROTATION&&p.fromBufferAttribute(c.ROTATION,x),c.SCALE&&M.fromBufferAttribute(c.SCALE,x),v.setMatrixAt(x,_.compose(m,p,M));for(const x in c)if(x==="_COLOR_0"){const I=c[x];v.instanceColor=new Bc(I.array,I.itemSize,I.normalized)}else x!=="TRANSLATION"&&x!=="ROTATION"&&x!=="SCALE"&&g.geometry.setAttribute(x,c[x]);St.prototype.copy.call(v,g),this.parser.assignFinalMaterial(v),f.push(v)}return u.isGroup?(u.clear(),u.add(...f),u):f[0]}))}}const af="glTF",ur=12,Rh={JSON:1313821514,BIN:5130562};class Xy{constructor(e){this.name=tt.KHR_BINARY_GLTF,this.content=null,this.body=null;const t=new DataView(e,0,ur),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==af)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const s=this.header.length-ur,r=new DataView(e,ur);let o=0;for(;o<s;){const a=r.getUint32(o,!0);o+=4;const c=r.getUint32(o,!0);if(o+=4,c===Rh.JSON){const l=new Uint8Array(e,ur+o,a);this.content=n.decode(l)}else if(c===Rh.BIN){const l=ur+o;this.body=e.slice(l,l+a)}o+=a}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class qy{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=tt.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){const n=this.json,s=this.dracoLoader,r=e.extensions[this.name].bufferView,o=e.extensions[this.name].attributes,a={},c={},l={};for(const u in o){const h=Wc[u]||u.toLowerCase();a[h]=o[u]}for(const u in e.attributes){const h=Wc[u]||u.toLowerCase();if(o[u]!==void 0){const d=n.accessors[e.attributes[u]],f=Ts[d.componentType];l[h]=f.name,c[h]=d.normalized===!0}}return t.getDependency("bufferView",r).then(function(u){return new Promise(function(h,d){s.decodeDracoFile(u,function(f){for(const g in f.attributes){const _=f.attributes[g],m=c[g];m!==void 0&&(_.normalized=m)}h(f)},a,l,nn,d)})})}}class $y{constructor(){this.name=tt.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}}class Yy{constructor(){this.name=tt.KHR_MESH_QUANTIZATION}}class cf extends Ur{constructor(e,t,n,s){super(e,t,n,s)}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s*3+s;for(let o=0;o!==s;o++)t[o]=n[r+o];return t}interpolate_(e,t,n,s){const r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=a*2,l=a*3,u=s-t,h=(n-t)/u,d=h*h,f=d*h,g=e*l,_=g-l,m=-2*f+3*d,p=f-d,M=1-m,v=p-d+h;for(let x=0;x!==a;x++){const I=o[_+x+a],A=o[_+x+c]*u,T=o[g+x+a],P=o[g+x]*u;r[x]=M*I+v*A+m*T+p*P}return r}}const jy=new Un;class Ky extends cf{interpolate_(e,t,n,s){const r=super.interpolate_(e,t,n,s);return jy.fromArray(r).normalize().toArray(r),r}}const _n={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},Ts={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Ch={9728:en,9729:hn,9984:dd,9985:Eo,9986:hr,9987:ti},Ph={33071:Si,33648:No,10497:Yi},Wa={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Wc={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},xi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},Zy={CUBICSPLINE:void 0,LINEAR:Sr,STEP:Mr},Xa={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function Jy(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new Be({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:si})),i.DefaultMaterial}function Bi(i,e,t){for(const n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Qn(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function Qy(i,e,t){let n=!1,s=!1,r=!1;for(let l=0,u=e.length;l<u;l++){const h=e[l];if(h.POSITION!==void 0&&(n=!0),h.NORMAL!==void 0&&(s=!0),h.COLOR_0!==void 0&&(r=!0),n&&s&&r)break}if(!n&&!s&&!r)return Promise.resolve(i);const o=[],a=[],c=[];for(let l=0,u=e.length;l<u;l++){const h=e[l];if(n){const d=h.POSITION!==void 0?t.getDependency("accessor",h.POSITION):i.attributes.position;o.push(d)}if(s){const d=h.NORMAL!==void 0?t.getDependency("accessor",h.NORMAL):i.attributes.normal;a.push(d)}if(r){const d=h.COLOR_0!==void 0?t.getDependency("accessor",h.COLOR_0):i.attributes.color;c.push(d)}}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(c)]).then(function(l){const u=l[0],h=l[1],d=l[2];return n&&(i.morphAttributes.position=u),s&&(i.morphAttributes.normal=h),r&&(i.morphAttributes.color=d),i.morphTargetsRelative=!0,i})}function eM(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){const t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,s=t.length;n<s;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function tM(i){let e;const t=i.extensions&&i.extensions[tt.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+qa(t.attributes):e=i.indices+":"+qa(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,s=i.targets.length;n<s;n++)e+=":"+qa(i.targets[n]);return e}function qa(i){let e="";const t=Object.keys(i).sort();for(let n=0,s=t.length;n<s;n++)e+=t[n]+":"+i[t[n]]+";";return e}function Xc(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function nM(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":i.search(/\.ktx2($|\?)/i)>0||i.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const iM=new He;class sM{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new Ty,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,s=-1,r=!1,o=-1;if(typeof navigator<"u"){const a=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(a)===!0;const c=a.match(/Version\/(\d+)/);s=n&&c?parseInt(c[1],10):-1,r=a.indexOf("Firefox")>-1,o=r?a.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&s<17||r&&o<98?this.textureLoader=new cy(this.options.manager):this.textureLoader=new my(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new rf(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){const n=this,s=this.json,r=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(o){return o._markDefs&&o._markDefs()}),Promise.all(this._invokeAll(function(o){return o.beforeRoot&&o.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(o){const a={scene:o[0][s.scene||0],scenes:o[0],animations:o[1],cameras:o[2],asset:s.asset,parser:n,userData:{}};return Bi(r,a,s),Qn(a,s),Promise.all(n._invokeAll(function(c){return c.afterRoot&&c.afterRoot(a)})).then(function(){for(const c of a.scenes)c.updateMatrixWorld();e(a)})}).catch(t)}_markDefs(){const e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let s=0,r=t.length;s<r;s++){const o=t[s].joints;for(let a=0,c=o.length;a<c;a++)e[o[a]].isBone=!0}for(let s=0,r=e.length;s<r;s++){const o=e[s];o.mesh!==void 0&&(this._addNodeRef(this.meshCache,o.mesh),o.skin!==void 0&&(n[o.mesh].isSkinnedMesh=!0)),o.camera!==void 0&&this._addNodeRef(this.cameraCache,o.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;const s=n.clone(),r=(o,a)=>{const c=this.associations.get(o);c!=null&&this.associations.set(a,c);for(const[l,u]of o.children.entries())r(u,a.children[l])};return r(n,s),s.name+="_instance_"+e.uses[t]++,s}_invokeOne(e){const t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){const s=e(t[n]);if(s)return s}return null}_invokeAll(e){const t=Object.values(this.plugins);t.unshift(this);const n=[];for(let s=0;s<t.length;s++){const r=e(t[s]);r&&n.push(r)}return n}getDependency(e,t){const n=e+":"+t;let s=this.cache.get(n);if(!s){switch(e){case"scene":s=this.loadScene(t);break;case"node":s=this._invokeOne(function(r){return r.loadNode&&r.loadNode(t)});break;case"mesh":s=this._invokeOne(function(r){return r.loadMesh&&r.loadMesh(t)});break;case"accessor":s=this.loadAccessor(t);break;case"bufferView":s=this._invokeOne(function(r){return r.loadBufferView&&r.loadBufferView(t)});break;case"buffer":s=this.loadBuffer(t);break;case"material":s=this._invokeOne(function(r){return r.loadMaterial&&r.loadMaterial(t)});break;case"texture":s=this._invokeOne(function(r){return r.loadTexture&&r.loadTexture(t)});break;case"skin":s=this.loadSkin(t);break;case"animation":s=this._invokeOne(function(r){return r.loadAnimation&&r.loadAnimation(t)});break;case"camera":s=this.loadCamera(t);break;default:if(s=this._invokeOne(function(r){return r!=this&&r.getDependency&&r.getDependency(e,t)}),!s)throw new Error("Unknown type: "+e);break}this.cache.add(n,s)}return s}getDependencies(e){let t=this.cache.get(e);if(!t){const n=this,s=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(s.map(function(r,o){return n.getDependency(e,o)})),this.cache.add(e,t)}return t}loadBuffer(e){const t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[tt.KHR_BINARY_GLTF].body);const s=this.options;return new Promise(function(r,o){n.load(vr.resolveURL(t.uri,s.path),r,void 0,function(){o(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){const t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){const s=t.byteLength||0,r=t.byteOffset||0;return n.slice(r,r+s)})}loadAccessor(e){const t=this,n=this.json,s=this.json.accessors[e];if(s.bufferView===void 0&&s.sparse===void 0){const o=Wa[s.type],a=Ts[s.componentType],c=s.normalized===!0,l=new a(s.count*o);return Promise.resolve(new jt(l,o,c))}const r=[];return s.bufferView!==void 0?r.push(this.getDependency("bufferView",s.bufferView)):r.push(null),s.sparse!==void 0&&(r.push(this.getDependency("bufferView",s.sparse.indices.bufferView)),r.push(this.getDependency("bufferView",s.sparse.values.bufferView))),Promise.all(r).then(function(o){const a=o[0],c=Wa[s.type],l=Ts[s.componentType],u=l.BYTES_PER_ELEMENT,h=u*c,d=s.byteOffset||0,f=s.bufferView!==void 0?n.bufferViews[s.bufferView].byteStride:void 0,g=s.normalized===!0;let _,m;if(f&&f!==h){const p=Math.floor(d/f),M="InterleavedBuffer:"+s.bufferView+":"+s.componentType+":"+p+":"+s.count;let v=t.cache.get(M);v||(_=new l(a,p*f,s.count*f/u),v=new zd(_,f/u),t.cache.add(M,v)),m=new br(v,c,d%f/u,g)}else a===null?_=new l(s.count*c):_=new l(a,d,s.count*c),m=new jt(_,c,g);if(s.sparse!==void 0){const p=Wa.SCALAR,M=Ts[s.sparse.indices.componentType],v=s.sparse.indices.byteOffset||0,x=s.sparse.values.byteOffset||0,I=new M(o[1],v,s.sparse.count*p),A=new l(o[2],x,s.sparse.count*c);a!==null&&(m=new jt(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let T=0,P=I.length;T<P;T++){const b=I[T];if(m.setX(b,A[T*c]),c>=2&&m.setY(b,A[T*c+1]),c>=3&&m.setZ(b,A[T*c+2]),c>=4&&m.setW(b,A[T*c+3]),c>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=g}return m})}loadTexture(e){const t=this.json,n=this.options,r=t.textures[e].source,o=t.images[r];let a=this.textureLoader;if(o.uri){const c=n.manager.getHandler(o.uri);c!==null&&(a=c)}return this.loadTextureImage(e,r,a)}loadTextureImage(e,t,n){const s=this,r=this.json,o=r.textures[e],a=r.images[t],c=(a.uri||a.bufferView)+":"+o.sampler;if(this.textureCache[c])return this.textureCache[c];const l=this.loadImageSource(t,n).then(function(u){u.flipY=!1,u.name=o.name||a.name||"",u.name===""&&typeof a.uri=="string"&&a.uri.startsWith("data:image/")===!1&&(u.name=a.uri);const d=(r.samplers||{})[o.sampler]||{};return u.magFilter=Ch[d.magFilter]||hn,u.minFilter=Ch[d.minFilter]||ti,u.wrapS=Ph[d.wrapS]||Yi,u.wrapT=Ph[d.wrapT]||Yi,u.generateMipmaps=!u.isCompressedTexture&&u.minFilter!==en&&u.minFilter!==hn,s.associations.set(u,{textures:e}),u}).catch(function(){return null});return this.textureCache[c]=l,l}loadImageSource(e,t){const n=this,s=this.json,r=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(h=>h.clone());const o=s.images[e],a=self.URL||self.webkitURL;let c=o.uri||"",l=!1;if(o.bufferView!==void 0)c=n.getDependency("bufferView",o.bufferView).then(function(h){l=!0;const d=new Blob([h],{type:o.mimeType});return c=a.createObjectURL(d),c});else if(o.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");const u=Promise.resolve(c).then(function(h){return new Promise(function(d,f){let g=d;t.isImageBitmapLoader===!0&&(g=function(_){const m=new Nt(_);m.needsUpdate=!0,d(m)}),t.load(vr.resolveURL(h,r.path),g,void 0,f)})}).then(function(h){return l===!0&&a.revokeObjectURL(c),Qn(h,o),h.userData.mimeType=o.mimeType||nM(o.uri),h}).catch(function(h){throw console.error("THREE.GLTFLoader: Couldn't load texture",c),h});return this.sourceCache[e]=u,u}assignTexture(e,t,n,s){const r=this;return this.getDependency("texture",n.index).then(function(o){if(!o)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(o=o.clone(),o.channel=n.texCoord),r.extensions[tt.KHR_TEXTURE_TRANSFORM]){const a=n.extensions!==void 0?n.extensions[tt.KHR_TEXTURE_TRANSFORM]:void 0;if(a){const c=r.associations.get(o);o=r.extensions[tt.KHR_TEXTURE_TRANSFORM].extendTexture(o,a),r.associations.set(o,c)}}return s!==void 0&&(o.colorSpace=s),e[t]=o,o})}assignFinalMaterial(e){const t=e.geometry;let n=e.material;const s=t.attributes.tangent===void 0,r=t.attributes.color!==void 0,o=t.attributes.normal===void 0;if(e.isPoints){const a="PointsMaterial:"+n.uuid;let c=this.cache.get(a);c||(c=new bl,bn.prototype.copy.call(c,n),c.color.copy(n.color),c.map=n.map,c.sizeAttenuation=!1,this.cache.add(a,c)),n=c}else if(e.isLine){const a="LineBasicMaterial:"+n.uuid;let c=this.cache.get(a);c||(c=new Xd,bn.prototype.copy.call(c,n),c.color.copy(n.color),c.map=n.map,this.cache.add(a,c)),n=c}if(s||r||o){let a="ClonedMaterial:"+n.uuid+":";s&&(a+="derivative-tangents:"),r&&(a+="vertex-colors:"),o&&(a+="flat-shading:");let c=this.cache.get(a);c||(c=n.clone(),r&&(c.vertexColors=!0),o&&(c.flatShading=!0),s&&(c.normalScale&&(c.normalScale.y*=-1),c.clearcoatNormalScale&&(c.clearcoatNormalScale.y*=-1)),this.cache.add(a,c),this.associations.set(c,this.associations.get(n))),n=c}e.material=n}getMaterialType(){return Be}loadMaterial(e){const t=this,n=this.json,s=this.extensions,r=n.materials[e];let o;const a={},c=r.extensions||{},l=[];if(c[tt.KHR_MATERIALS_UNLIT]){const h=s[tt.KHR_MATERIALS_UNLIT];o=h.getMaterialType(),l.push(h.extendParams(a,r,t))}else{const h=r.pbrMetallicRoughness||{};if(a.color=new Fe(1,1,1),a.opacity=1,Array.isArray(h.baseColorFactor)){const d=h.baseColorFactor;a.color.setRGB(d[0],d[1],d[2],nn),a.opacity=d[3]}h.baseColorTexture!==void 0&&l.push(t.assignTexture(a,"map",h.baseColorTexture,Lt)),a.metalness=h.metallicFactor!==void 0?h.metallicFactor:1,a.roughness=h.roughnessFactor!==void 0?h.roughnessFactor:1,h.metallicRoughnessTexture!==void 0&&(l.push(t.assignTexture(a,"metalnessMap",h.metallicRoughnessTexture)),l.push(t.assignTexture(a,"roughnessMap",h.metallicRoughnessTexture))),o=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(e,a)})))}r.doubleSided===!0&&(a.side=Bt);const u=r.alphaMode||Xa.OPAQUE;if(u===Xa.BLEND?(a.transparent=!0,a.depthWrite=!1):(a.transparent=!1,u===Xa.MASK&&(a.alphaTest=r.alphaCutoff!==void 0?r.alphaCutoff:.5)),r.normalTexture!==void 0&&o!==Dt&&(l.push(t.assignTexture(a,"normalMap",r.normalTexture)),a.normalScale=new se(1,1),r.normalTexture.scale!==void 0)){const h=r.normalTexture.scale;a.normalScale.set(h,h)}if(r.occlusionTexture!==void 0&&o!==Dt&&(l.push(t.assignTexture(a,"aoMap",r.occlusionTexture)),r.occlusionTexture.strength!==void 0&&(a.aoMapIntensity=r.occlusionTexture.strength)),r.emissiveFactor!==void 0&&o!==Dt){const h=r.emissiveFactor;a.emissive=new Fe().setRGB(h[0],h[1],h[2],nn)}return r.emissiveTexture!==void 0&&o!==Dt&&l.push(t.assignTexture(a,"emissiveMap",r.emissiveTexture,Lt)),Promise.all(l).then(function(){const h=new o(a);return r.name&&(h.name=r.name),Qn(h,r),t.associations.set(h,{materials:e}),r.extensions&&Bi(s,h,r),h})}createUniqueName(e){const t=dt.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){const t=this,n=this.extensions,s=this.primitiveCache;function r(a){return n[tt.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a,t).then(function(c){return Lh(c,a,t)})}const o=[];for(let a=0,c=e.length;a<c;a++){const l=e[a],u=tM(l),h=s[u];if(h)o.push(h.promise);else{let d;l.extensions&&l.extensions[tt.KHR_DRACO_MESH_COMPRESSION]?d=r(l):d=Lh(new Tt,l,t),s[u]={primitive:l,promise:d},o.push(d)}}return Promise.all(o)}loadMesh(e){const t=this,n=this.json,s=this.extensions,r=n.meshes[e],o=r.primitives,a=[];for(let c=0,l=o.length;c<l;c++){const u=o[c].material===void 0?Jy(this.cache):this.getDependency("material",o[c].material);a.push(u)}return a.push(t.loadGeometries(o)),Promise.all(a).then(function(c){const l=c.slice(0,c.length-1),u=c[c.length-1],h=[];for(let f=0,g=u.length;f<g;f++){const _=u[f],m=o[f];let p;const M=l[f];if(m.mode===_n.TRIANGLES||m.mode===_n.TRIANGLE_STRIP||m.mode===_n.TRIANGLE_FAN||m.mode===void 0)p=r.isSkinnedMesh===!0?new fv(_,M):new G(_,M),p.isSkinnedMesh===!0&&p.normalizeSkinWeights(),m.mode===_n.TRIANGLE_STRIP?p.geometry=Ah(p.geometry,Sd):m.mode===_n.TRIANGLE_FAN&&(p.geometry=Ah(p.geometry,kc));else if(m.mode===_n.LINES)p=new gv(_,M);else if(m.mode===_n.LINE_STRIP)p=new wl(_,M);else if(m.mode===_n.LINE_LOOP)p=new _v(_,M);else if(m.mode===_n.POINTS)p=new qd(_,M);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(p.geometry.morphAttributes).length>0&&eM(p,r),p.name=t.createUniqueName(r.name||"mesh_"+e),Qn(p,r),m.extensions&&Bi(s,p,m),t.assignFinalMaterial(p),h.push(p)}for(let f=0,g=h.length;f<g;f++)t.associations.set(h[f],{meshes:e,primitives:f});if(h.length===1)return r.extensions&&Bi(s,h[0],r),h[0];const d=new ze;r.extensions&&Bi(s,d,r),t.associations.set(d,{meshes:e});for(let f=0,g=h.length;f<g;f++)d.add(h[f]);return d})}loadCamera(e){let t;const n=this.json.cameras[e],s=n[n.type];if(!s){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Qt(gl.radToDeg(s.yfov),s.aspectRatio||1,s.znear||1,s.zfar||2e6):n.type==="orthographic"&&(t=new xl(-s.xmag,s.xmag,s.ymag,-s.ymag,s.znear,s.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Qn(t,n),Promise.resolve(t)}loadSkin(e){const t=this.json.skins[e],n=[];for(let s=0,r=t.joints.length;s<r;s++)n.push(this._loadNodeShallow(t.joints[s]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(s){const r=s.pop(),o=s,a=[],c=[];for(let l=0,u=o.length;l<u;l++){const h=o[l];if(h){a.push(h);const d=new He;r!==null&&d.fromArray(r.array,l*16),c.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[l])}return new Sl(a,c)})}loadAnimation(e){const t=this.json,n=this,s=t.animations[e],r=s.name?s.name:"animation_"+e,o=[],a=[],c=[],l=[],u=[];for(let h=0,d=s.channels.length;h<d;h++){const f=s.channels[h],g=s.samplers[f.sampler],_=f.target,m=_.node,p=s.parameters!==void 0?s.parameters[g.input]:g.input,M=s.parameters!==void 0?s.parameters[g.output]:g.output;_.node!==void 0&&(o.push(this.getDependency("node",m)),a.push(this.getDependency("accessor",p)),c.push(this.getDependency("accessor",M)),l.push(g),u.push(_))}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(c),Promise.all(l),Promise.all(u)]).then(function(h){const d=h[0],f=h[1],g=h[2],_=h[3],m=h[4],p=[];for(let M=0,v=d.length;M<v;M++){const x=d[M],I=f[M],A=g[M],T=_[M],P=m[M];if(x===void 0)continue;x.updateMatrix&&x.updateMatrix();const b=n._createAnimationTracks(x,I,A,T,P);if(b)for(let w=0;w<b.length;w++)p.push(b[w])}return new ty(r,void 0,p)})}createNodeMesh(e){const t=this.json,n=this,s=t.nodes[e];return s.mesh===void 0?null:n.getDependency("mesh",s.mesh).then(function(r){const o=n._getNodeRef(n.meshCache,s.mesh,r);return s.weights!==void 0&&o.traverse(function(a){if(a.isMesh)for(let c=0,l=s.weights.length;c<l;c++)a.morphTargetInfluences[c]=s.weights[c]}),o})}loadNode(e){const t=this.json,n=this,s=t.nodes[e],r=n._loadNodeShallow(e),o=[],a=s.children||[];for(let l=0,u=a.length;l<u;l++)o.push(n.getDependency("node",a[l]));const c=s.skin===void 0?Promise.resolve(null):n.getDependency("skin",s.skin);return Promise.all([r,Promise.all(o),c]).then(function(l){const u=l[0],h=l[1],d=l[2];d!==null&&u.traverse(function(f){f.isSkinnedMesh&&f.bind(d,iM)});for(let f=0,g=h.length;f<g;f++)u.add(h[f]);return u})}_loadNodeShallow(e){const t=this.json,n=this.extensions,s=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];const r=t.nodes[e],o=r.name?s.createUniqueName(r.name):"",a=[],c=s._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(e)});return c&&a.push(c),r.camera!==void 0&&a.push(s.getDependency("camera",r.camera).then(function(l){return s._getNodeRef(s.cameraCache,r.camera,l)})),s._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(e)}).forEach(function(l){a.push(l)}),this.nodeCache[e]=Promise.all(a).then(function(l){let u;if(r.isBone===!0?u=new Gd:l.length>1?u=new ze:l.length===1?u=l[0]:u=new St,u!==l[0])for(let h=0,d=l.length;h<d;h++)u.add(l[h]);if(r.name&&(u.userData.name=r.name,u.name=o),Qn(u,r),r.extensions&&Bi(n,u,r),r.matrix!==void 0){const h=new He;h.fromArray(r.matrix),u.applyMatrix4(h)}else r.translation!==void 0&&u.position.fromArray(r.translation),r.rotation!==void 0&&u.quaternion.fromArray(r.rotation),r.scale!==void 0&&u.scale.fromArray(r.scale);return s.associations.has(u)||s.associations.set(u,{}),s.associations.get(u).nodes=e,u}),this.nodeCache[e]}loadScene(e){const t=this.extensions,n=this.json.scenes[e],s=this,r=new ze;n.name&&(r.name=s.createUniqueName(n.name)),Qn(r,n),n.extensions&&Bi(t,r,n);const o=n.nodes||[],a=[];for(let c=0,l=o.length;c<l;c++)a.push(s.getDependency("node",o[c]));return Promise.all(a).then(function(c){for(let u=0,h=c.length;u<h;u++)r.add(c[u]);const l=u=>{const h=new Map;for(const[d,f]of s.associations)(d instanceof bn||d instanceof Nt)&&h.set(d,f);return u.traverse(d=>{const f=s.associations.get(d);f!=null&&h.set(d,f)}),h};return s.associations=l(r),r})}_createAnimationTracks(e,t,n,s,r){const o=[],a=e.name?e.name:e.uuid,c=[];xi[r.path]===xi.weights?e.traverse(function(d){d.morphTargetInfluences&&c.push(d.name?d.name:d.uuid)}):c.push(a);let l;switch(xi[r.path]){case xi.weights:l=Fs;break;case xi.rotation:l=Os;break;case xi.position:case xi.scale:l=Bs;break;default:switch(n.itemSize){case 1:l=Fs;break;case 2:case 3:default:l=Bs;break}break}const u=s.interpolation!==void 0?Zy[s.interpolation]:Sr,h=this._getArrayFromAccessor(n);for(let d=0,f=c.length;d<f;d++){const g=new l(c[d]+"."+xi[r.path],t.array,h,u);s.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),o.push(g)}return o}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){const n=Xc(t.constructor),s=new Float32Array(t.length);for(let r=0,o=t.length;r<o;r++)s[r]=t[r]*n;t=s}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){const s=this instanceof Os?Ky:cf;return new s(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function rM(i,e,t){const n=e.attributes,s=new Bn;if(n.POSITION!==void 0){const a=t.json.accessors[n.POSITION],c=a.min,l=a.max;if(c!==void 0&&l!==void 0){if(s.set(new R(c[0],c[1],c[2]),new R(l[0],l[1],l[2])),a.normalized){const u=Xc(Ts[a.componentType]);s.min.multiplyScalar(u),s.max.multiplyScalar(u)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const r=e.targets;if(r!==void 0){const a=new R,c=new R;for(let l=0,u=r.length;l<u;l++){const h=r[l];if(h.POSITION!==void 0){const d=t.json.accessors[h.POSITION],f=d.min,g=d.max;if(f!==void 0&&g!==void 0){if(c.setX(Math.max(Math.abs(f[0]),Math.abs(g[0]))),c.setY(Math.max(Math.abs(f[1]),Math.abs(g[1]))),c.setZ(Math.max(Math.abs(f[2]),Math.abs(g[2]))),d.normalized){const _=Xc(Ts[d.componentType]);c.multiplyScalar(_)}a.max(c)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(a)}i.boundingBox=s;const o=new zn;s.getCenter(o.center),o.radius=s.min.distanceTo(s.max)/2,i.boundingSphere=o}function Lh(i,e,t){const n=e.attributes,s=[];function r(o,a){return t.getDependency("accessor",o).then(function(c){i.setAttribute(a,c)})}for(const o in n){const a=Wc[o]||o.toLowerCase();a in i.attributes||s.push(r(n[o],a))}if(e.indices!==void 0&&!i.index){const o=t.getDependency("accessor",e.indices).then(function(a){i.setIndex(a)});s.push(o)}return st.workingColorSpace!==nn&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${st.workingColorSpace}" not supported.`),Qn(i,e),rM(i,e,t),Promise.all(s).then(function(){return e.targets!==void 0?Qy(i,e.targets,t):i})}const lf={value:0},ea=new Map;function oM(i,e=.08,t=1.6){i.onBeforeCompile=n=>{n.uniforms.uWind=lf,n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
uniform float uWind;`).replace("#include <begin_vertex>",`#include <begin_vertex>
        {
          vec4 wp0 = vec4(transformed, 1.0);
          #ifdef USE_INSTANCING
          wp0 = instanceMatrix * wp0;
          #endif
          wp0 = modelMatrix * wp0;
          float h = max(0.0, position.y);
          float s = sin(uWind * ${t.toFixed(2)} + wp0.x * 0.45 + wp0.z * 0.3) + 0.4 * sin(uWind * ${(t*2.3).toFixed(2)} + wp0.x * 1.3);
          transformed.x += s * ${e.toFixed(3)} * h;
          transformed.z += s * ${(e*.4).toFixed(3)} * h;
        }`)},i.customProgramCacheKey=()=>`wind${e}${t}`}const aM=/Leaves|Grass|Flowers|Leaf/i;async function cM(i){const e=await new Ey().loadAsync(i),t=new Set;e.scene.traverse(n=>{const s=n;if(s.isMesh){s.castShadow=!0,s.receiveShadow=!0;const r=Array.isArray(s.material)?s.material:[s.material];for(const o of r){if(t.has(o))continue;t.add(o);const a=o;a.metalness=0,a.roughness=.9,/Leaves/i.test(o.name)&&a.color.setScalar(1.35),aM.test(o.name)&&(a.alphaTest=.5,a.side=Bt,oM(o,/Grass/i.test(o.name)?.14:.05))}}});for(const n of e.scene.children)ea.set(n.name,n)}function lM(i){return ea.has(i)}function uM(i){const e=ea.get(i),t=new Bn;return e&&t.setFromObject(e),t.getSize(new R)}function gn(i,e,t=!0,n){const s=new ze,r=ea.get(i);if(!r||!e.length)return s;r.updateMatrixWorld(!0);const o=new He().copy(r.matrixWorld).invert();return r.traverse(a=>{const c=a;if(!c.isMesh)return;const l=new He().multiplyMatrices(o,c.matrixWorld);let u=c.material;if(n&&!Array.isArray(u)&&/Leaves|Leaf/i.test(u.name)){const f=u,g=f.clone(),_=new Fe(n);g.color.setScalar(1),g.onBeforeCompile=(m,p)=>{f.onBeforeCompile(m,p),m.uniforms.uTint={value:_},m.fragmentShader=m.fragmentShader.replace("#include <common>",`#include <common>
uniform vec3 uTint;`).replace("#include <map_fragment>",`#include <map_fragment>
{ float lum = dot(diffuseColor.rgb, vec3(0.3, 0.59, 0.11)); diffuseColor.rgb = uTint * (0.35 + lum * 2.1); }`)},g.customProgramCacheKey=()=>`${f.customProgramCacheKey()}tint`,u=g}const h=new ko(c.geometry,u,e.length),d=new He;e.forEach((f,g)=>h.setMatrixAt(g,d.multiplyMatrices(f,l))),h.castShadow=t,h.receiveShadow=!0,h.computeBoundingSphere(),s.add(h)}),s}function uf(i){let e=i>>>0||1;return()=>(e=e*1664525+1013904223>>>0,e/4294967296)}function Ys(i,e){const t=document.createElement("canvas");return t.width=i,t.height=e,[t,t.getContext("2d")]}function js(i,e=!0){const t=new $d(i);return t.colorSpace=Lt,e&&(t.wrapS=t.wrapT=Yi),t.anisotropy=4,t}const Ih=new Map;function kr(i,e){let t=Ih.get(i);return t||Ih.set(i,t=e()),t}function $a(i="#9a6a43",e="#6f4a2e",t="#b98457"){return kr(`soil${i}`,()=>{const[n,s]=Ys(256,256),r=uf(7);s.fillStyle=i,s.fillRect(0,0,256,256);for(let o=0;o<9;o++){s.fillStyle=o%2?e:t,s.globalAlpha=.18;const a=o*30+r()*10;s.beginPath(),s.moveTo(0,a);for(let c=0;c<=256;c+=32)s.lineTo(c,a+Math.sin(c/40+o)*5);s.lineTo(256,a+14);for(let c=256;c>=0;c-=32)s.lineTo(c,a+14+Math.sin(c/30+o*2)*4);s.fill()}s.globalAlpha=1;for(let o=0;o<70;o++){const a=r()*256,c=r()*256,l=2+r()*6,u=l*(.6+r()*.3);s.fillStyle=r()<.5?e:t,s.globalAlpha=.55;for(const[h,d]of[[0,0],[256,0],[-256,0],[0,256],[0,-256]])s.beginPath(),s.ellipse(a+h,c+d,l,u,0,0,Math.PI*2),s.fill()}s.strokeStyle="#5a3a22",s.lineCap="round",s.globalAlpha=.5;for(let o=0;o<8;o++){s.lineWidth=1.5+r()*2,s.beginPath();let a=r()*256,c=r()*40;s.moveTo(a,c);for(let l=0;l<4;l++)a+=(r()-.5)*30,c+=8+r()*12,s.lineTo(a,c);s.stroke()}return s.globalAlpha=1,js(n)})}function ts(i="#7b5236"){return kr(`bark${i}`,()=>{const[e,t]=Ys(128,256),n=uf(3);t.fillStyle=i,t.fillRect(0,0,128,256);for(let s=0;s<26;s++){t.strokeStyle=n()<.5?"rgba(60,35,20,0.55)":"rgba(170,120,80,0.35)",t.lineWidth=2+n()*4,t.beginPath();let r=n()*128;t.moveTo(r,-10);for(let o=0;o<=266;o+=24)r+=(n()-.5)*8,t.lineTo(r,o);t.stroke()}return js(e)})}function ta(){return kr("rings",()=>{const[i,e]=Ys(128,128);e.fillStyle="#d9a86c",e.fillRect(0,0,128,128);for(let t=10;t>0;t--)e.strokeStyle=t%2?"rgba(150,95,50,0.6)":"rgba(190,130,75,0.5)",e.lineWidth=3,e.beginPath(),e.arc(64+Math.sin(t)*2,64,t*6,0,Math.PI*2),e.stroke();return e.strokeStyle="#7b5236",e.lineWidth=8,e.beginPath(),e.arc(64,64,60,0,Math.PI*2),e.stroke(),js(i,!1)})}function Dl(){return kr("glow",()=>{const[i,e]=Ys(64,64),t=e.createRadialGradient(32,32,0,32,32,32);return t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.35,"rgba(255,255,255,0.55)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,64,64),js(i,!1)})}function hM(){return kr("ray",()=>{const[i,e]=Ys(64,256),t=e.createLinearGradient(0,0,0,256);t.addColorStop(0,"rgba(255,248,220,0.9)"),t.addColorStop(1,"rgba(255,248,220,0)"),e.fillStyle=t,e.fillRect(0,0,64,256),e.globalCompositeOperation="destination-in";const n=e.createLinearGradient(0,0,64,0);return n.addColorStop(0,"rgba(0,0,0,0)"),n.addColorStop(.5,"rgba(0,0,0,1)"),n.addColorStop(1,"rgba(0,0,0,0)"),e.fillStyle=n,e.fillRect(0,0,64,256),js(i,!1)})}function dM(i){const[e,t]=Ys(512,256);t.fillStyle="#b07a48",t.beginPath(),t.roundRect(8,8,496,240,36),t.fill(),t.strokeStyle="#7a4d2a",t.lineWidth=10,t.stroke(),t.globalAlpha=.18,t.strokeStyle="#5a3a20",t.lineWidth=3;for(let l=40;l<240;l+=38)t.beginPath(),t.moveTo(30,l),t.bezierCurveTo(180,l+8,330,l-8,482,l+3),t.stroke();t.globalAlpha=1,t.fillStyle="#fff7e6",t.textAlign="center",t.textBaseline="middle";let n=72;const s=l=>`700 ${l}px Fredoka, Nunito, "Trebuchet MS", sans-serif`;t.font=s(n);const r=i.split(" ");let o=[i];for(;n>30;n-=4){if(t.font=s(n),t.measureText(i).width<=440){o=[i];break}let l=null;for(let u=1;u<r.length;u++){const h=r.slice(0,u).join(" "),d=r.slice(u).join(" ");t.measureText(h).width<=440&&t.measureText(d).width<=440&&n<=62&&(l=[h,d])}if(l){o=l;break}}t.shadowColor="rgba(70,40,15,0.7)",t.shadowOffsetY=4;const a=n*1.1;return o.forEach((l,u)=>t.fillText(l,256,128+(u-(o.length-1)/2)*a)),js(e,!1)}const fM={skyTop:"#6db9ec",skyBottom:"#fdf3d0",fog:"#dff0e4",hills:["#8fcf72","#a7d68e","#b9dbc0","#cfe3e6"],sun:"#fff1c9",ambientSky:"#dff3ff",ambientGround:"#6f8f4a",fogNear:45,fogFar:230,rays:.22};class pM{constructor(e){te(this,"renderer");te(this,"scene",new hv);te(this,"camera",new Qt(30,1,.5,400));te(this,"sun");te(this,"hemi");te(this,"sky");te(this,"skyMat");te(this,"far",[]);te(this,"clouds",[]);te(this,"rays",[]);te(this,"pollen");te(this,"ambient",{color:"#fff7c2",size:.22,count:90,fall:0,flicker:!1});te(this,"rayStrength",.22);te(this,"world",new ze);te(this,"fx",new ze);te(this,"width",1);te(this,"height",1);te(this,"time",0);this.canvas=e,this.renderer=new uv({canvas:e,antialias:!0,powerPreference:"high-performance",preserveDrawingBuffer:!1}),this.renderer.outputColorSpace=Lt,this.renderer.toneMapping=ud,this.renderer.toneMappingExposure=1.05,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=ld,this.scene.add(this.world,this.fx),this.hemi=new ly("#dff3ff","#6f8f4a",1.25),this.scene.add(this.hemi),this.sun=new of("#fff1c9",2.3),this.sun.castShadow=!0,this.sun.shadow.mapSize.set(2048,1024);const t=this.sun.shadow.camera;t.left=-26,t.right=26,t.top=14,t.bottom=-10,t.near=1,t.far=80,this.sun.shadow.bias=-6e-4,this.sun.shadow.normalBias=.03,this.sun.shadow.radius=4,this.scene.add(this.sun,this.sun.target),this.skyMat=new oi({depthWrite:!1,fog:!1,uniforms:{top:{value:new Fe},bottom:{value:new Fe},sun:{value:new Fe},sunPos:{value:new se(.72,.62)}},vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`uniform vec3 top; uniform vec3 bottom; uniform vec3 sun; uniform vec2 sunPos; varying vec2 vUv;
        void main(){
          float k = smoothstep(0.42, 0.62, vUv.y);
          vec3 c = mix(bottom, top, k);
          vec2 d = (vUv - sunPos) * vec2(2.2, 1.0);
          float g = exp(-dot(d,d) * 18.0);
          c += sun * g * 0.55 + sun * exp(-dot(d,d) * 400.0) * 0.6;
          gl_FragColor = vec4(c, 1.0);
          #include <colorspace_fragment>
        }`}),this.sky=new G(new kn(900,360),this.skyMat),this.sky.position.set(0,60,-200),this.scene.add(this.sky);const n=new Tt,s=120,r=new Float32Array(s*3);for(let o=0;o<s;o++)r[o*3]=o*53%100/100*60-30,r[o*3+1]=o*29%100/100*14-2,r[o*3+2]=o*71%100/100*10-6;n.setAttribute("position",new jt(r,3)),this.pollen=new qd(n,new bl({map:Dl(),size:.22,color:"#fff7c2",transparent:!0,opacity:.8,depthWrite:!1,blending:Cs})),this.scene.add(this.pollen)}setAmbient(e){this.ambient=e;const t=this.pollen.material;t.color.set(e.color),t.size=e.size,t.opacity=.85}setTheme(e){this.skyMat.uniforms.top.value.set(e.skyTop),this.skyMat.uniforms.bottom.value.set(e.skyBottom),this.skyMat.uniforms.sun.value.set(e.sun),this.scene.fog=new yl(e.fog,e.fogNear,e.fogFar),this.rayStrength=e.rays,this.hemi.color.set(e.ambientSky),this.hemi.groundColor.set(e.ambientGround),this.sun.color.set(e.sun);for(const r of this.far)this.scene.remove(r.o);for(const r of this.clouds)this.scene.remove(r);for(const r of this.rays)this.scene.remove(r);this.far=[],this.clouds=[],this.rays=[],[{z:-26,y:-3,amp:3.2,freq:.09,color:e.hills[0],k:.25},{z:-48,y:-1,amp:5,freq:.05,color:e.hills[1],k:.45},{z:-85,y:1,amp:9,freq:.03,color:e.hills[2],k:.65},{z:-140,y:4,amp:16,freq:.018,color:e.hills[3],k:.8}].forEach((r,o)=>{const a=new Pi,c=600;a.moveTo(-c/2,-40);for(let u=-c/2;u<=c/2;u+=2){const h=r.amp*(.6*Math.sin(u*r.freq+o*1.7)+.4*Math.sin(u*r.freq*2.3+o))+r.amp;a.lineTo(u,h)}a.lineTo(c/2,-40);const l=new G(new es(a,1),new Sh({color:r.color}));l.position.set(0,r.y,r.z),this.scene.add(l),this.far.push({o:l,k:r.k,x:0})});const n=new Sh({color:"#ffffff",emissive:"#ffffff",emissiveIntensity:.45});for(let r=0;r<9;r++){const o=new ze;for(let a=0;a<5;a++){const c=new G(new We(1,14,10),n);c.scale.set(2.2-Math.abs(a-2)*.4,1.4-Math.abs(a-2)*.25,1.2),c.position.set((a-2)*1.7,Math.abs(a-2)*-.25,0),o.add(c)}o.scale.setScalar(1.6+r%3*.5),o.position.set(-120+r*32,22+r%3*6,-95-r%2*20),this.scene.add(o),this.clouds.push(o),this.far.push({o,k:.7,x:o.position.x})}const s=new Dt({map:hM(),color:"#fff3c4",transparent:!0,opacity:.22,depthWrite:!1,blending:Cs,fog:!1});for(let r=0;r<5;r++){const o=new G(new kn(3+r%2*2,30),s.clone());o.rotation.z=.42,o.position.set(r*9-18,6,-9-r%3*3),this.scene.add(o),this.rays.push(o),this.far.push({o,k:.15,x:o.position.x})}}resize(e,t,n){this.width=e,this.height=t,this.renderer.setPixelRatio(n),this.renderer.setSize(e,t,!1),this.camera.aspect=e/t,this.camera.updateProjectionMatrix()}frame(e,t,n,s,r=.5,o=.5){const a=this.camera,c=Math.tan(gl.degToRad(a.fov/2)),l=Math.max(s,n/a.aspect),u=l/2/c,h=l*a.aspect,d=e+(.5-r)*h,f=t+(.5-o)*l;return a.position.set(d,f+u*.06,u),a.lookAt(d,f,0),u}update(e){this.time+=e,lf.value=this.time;const t=this.camera.position.x;for(const c of this.far)c.o.position.x=c.x+t*c.k;this.sky.position.x=t,this.clouds.forEach((c,l)=>{const u=this.far.find(h=>h.o===c);u&&(u.x+=e*(.4+l%3*.15))}),this.rays.forEach((c,l)=>c.material.opacity=this.rayStrength*(.65+.35*Math.sin(this.time*.6+l*1.7)));const n=this.pollen.geometry.attributes.position,s=this.ambient;for(let c=0;c<n.count;c++){let l=n.getX(c)+e*(.3+c%5*.05+s.fall*.5),u=n.getY(c)+Math.sin(this.time*.8+c)*e*.15-s.fall*e*(.8+c%3*.3);l-t>30&&(l-=60),l-t<-30&&(l+=60),u<-2&&(u+=16),u>14&&(u-=16),n.setXY(c,l,u)}n.needsUpdate=!0,this.pollen.geometry.setDrawRange(0,s.count);const r=this.pollen.material;s.flicker&&(r.opacity=.55+.45*Math.abs(Math.sin(this.time*2.3))),this.pollen.position.y=this.camera.position.y-6;const o=this.camera.position.x,a=this.camera.position.y-2;this.sun.position.set(o+10,a+22,18),this.sun.target.position.set(o,a-2,0)}render(){this.renderer.render(this.scene,this.camera)}}const Rt=1/60,Ai=4.6,Nl=Ai*1.5,hf=i=>i*1.2+2,mM=2,Ya=34,gM=10.4,_M=.42,xM=.3,vM=.1,yM=.12,qt=.7,df=1.25,MM=.6,SM=.65,wM=1.6,bM=9,qi=6.5,vi=5.6,EM=4.2,TM=5.5,AM=16,RM=8.5,Io=.7,Do=9.5,pr=4.4,ff=.95,Dh=1.6,CM=.7,pf=1.1,mf=1.5,Nh={jumpPressed:!1,jumpHeld:!1,duckPressed:!1,duckHeld:!1},Mi=4,Uh=new WeakMap;function gf(i){let e=Uh.get(i);if(e)return e;const t=Math.ceil((i.goalX+40)/Mi)+2;return e={cell:Mi,boxes:Array.from({length:t},()=>[]),pickups:Array.from({length:t},()=>[])},i.boxes.forEach((n,s)=>{for(let r=Math.max(0,Math.floor(n.x0/Mi));r<=Math.min(t-1,Math.floor(n.x1/Mi));r++)e.boxes[r].push(s)}),i.pickups.forEach((n,s)=>e.pickups[Math.max(0,Math.min(t-1,Math.floor(n.x/Mi)))].push(s)),Uh.set(i,e),e}function PM(i){return{tick:0,et:0,mode:"run",modeT:0,x:i.startX,y:i.startY,vx:0,vy:0,grounded:!0,coyote:0,buffer:0,holding:!1,holdT:0,duckT:0,ducking:!1,climbing:!1,hopped:!1,bounced:!1,knockT:0,hearts:3,invuln:0,speed:i.speed,rollAt:new Float64Array(i.enemies.length).fill(-1),gliding:!1,logHop:!1,seeds:i.seeds,gems:0,acorns:0,got:new Uint8Array(i.pickups.length),enemyDead:new Uint8Array(i.enemies.length),solved:new Uint8Array(i.dps.length),cp:-1,cpX:i.startX,cpY:i.startY,dp:-1,plants:[],failReason:"",wrong:0,stuckT:0,bestX:i.startX,landV:0,events:[],lastPickup:-1,lastEnemy:-1}}function qc(i,e,t=-1){if(i.kind==="roller")return t<0?i.x0:i.x0-(e-t)*Rt*mM;const n=i.x1-i.x0;if(n<=0)return i.x0;const s=e*Rt*i.speed%(2*n);return s<n?i.x0+s:i.x1-(s-n)}function _f(i,e){return i.kind!=="bee"?i.y:i.y+(i.amp??0)*Math.sin(e*Rt*i.speed*2+(i.phase??0))}const LM={beetle:{w:.9,h:.7,stomp:!0},snail:{w:1,h:.85,stomp:!1},bee:{w:.7,h:.6,stomp:!1},roller:{w:.8,h:.8,stomp:!0}};function IM(i,e){const t=[];for(const n of e.plants)n.kind==="bridge"&&t.push({x0:n.x,x1:n.x+qi,y0:n.y-.3,y1:n.y,kind:"plank",oneWay:!0}),n.kind==="tree"&&t.push({x0:n.x,x1:n.x+Do,y0:n.y-.4,y1:n.y,kind:"plank",oneWay:!0}),n.kind==="log"&&t.push({x0:n.x,x1:n.x+pr,y0:n.y+.2,y1:n.y+ff,kind:"plank",oneWay:!0});return t}function $c(i,e,t,n,s){const r=gf(i),o=Math.max(0,Math.floor(t/Mi)),a=Math.min(r.boxes.length-1,Math.floor(n/Mi));let c=null;for(let l=o;l<=a;l++)for(const u of r.boxes[l]){if(a>o){if(c??(c=new Set),c.has(u))continue;c.add(u)}s(i.boxes[u])}if(e.plants.length)for(const l of IM(i,e))s(l)}const DM=i=>i.ducking?MM:df;function kh(i,e){let t=!0;const n=e.x-qt/2,s=e.x+qt/2;return $c(i,e,n,s,r=>{r.oneWay||s>r.x0&&n<r.x1&&e.y+df>r.y0+1e-4&&e.y<r.y1-1e-4&&(t=!1)}),t}function xf(i,e){for(let t=0;t<i.dps.length;t++)if(!e.solved[t])return t;return-1}function Fh(i){i.invuln>0||i.mode!=="run"||(i.hearts--,i.invuln=wM,i.vy=7,i.grounded=!1,i.knockT=.25,i.holding=!1,i.events.push("hit"),i.hearts<=0&&(i.mode="lost",i.modeT=0,i.events.push("lose")))}function yo(i,e){i.mode="fail",i.modeT=0,i.failReason=e,i.climbing=!1,i.events.push("fail")}function Oh(i,e){return i.water.some(t=>e>=t.x0&&e<=t.x1)}function NM(i,e){return i==="bridge"||i==="tree"?e.anchorX-.3:i==="log"?e.anchorX-.4:i==="mushroom"?e.anchorX-.8:e.anchorX-.05}function UM(i,e,t){if(e.mode!=="decide"||e.dp<0||e.seeds<=0)return!1;const n=i.dps[e.dp];return n.cards.includes(t)?(e.seeds--,e.plants.push({dp:e.dp,kind:t,x:NM(t,n),y:n.y,at:e.tick}),e.mode="grow",e.modeT=0,e.events.push("plant"),!0):!1}function kM(i){const e=i.plants[i.plants.length-1];return e&&e.dp===i.dp?e:null}function FM(i,e,t){if(e.events.length=0,e.tick++,e.modeT+=Rt,e.mode==="won"||e.mode==="lost"||e.mode==="decide")return;if(e.mode==="grow"){e.modeT>=pf&&(e.mode="cross",e.modeT=0,e.stuckT=0,e.bestX=e.x,e.hopped=!1,e.bounced=!1,e.gliding=!1,e.logHop=!1,e.events.push("cross"));return}if(e.mode==="fail"){if((e.failReason==="splash"||e.failReason==="fall")&&(e.vy=Math.max(e.vy-Ya*Rt,-6),e.y+=e.vy*Rt,e.x+=e.vx*.3*Rt),e.modeT>=mf){const g=i.dps[e.dp];e.plants.pop(),e.wrong++,e.x=g.stopX,e.y=g.y,e.vx=e.vy=0,e.grounded=!0,e.ducking=!1,e.mode="decide",e.modeT=0,e.failReason=""}return}e.et++;const n=e.mode==="cross",s=n?i.dps[e.dp]:null,r=n?kM(e):null,o=!n&&t.jumpPressed,a=!n&&t.jumpHeld,c=!n&&t.duckPressed,l=!n&&t.duckHeld;e.invuln=Math.max(0,e.invuln-Rt),e.knockT=Math.max(0,e.knockT-Rt),e.buffer=o?yM:Math.max(0,e.buffer-Rt),e.coyote=e.grounded?vM:Math.max(0,e.coyote-Rt),c&&(e.duckT=SM,e.grounded||(e.vy=Math.min(e.vy,-14)),e.events.push("duck")),l&&e.grounded&&(e.duckT=Math.max(e.duckT,Rt*2)),e.duckT=Math.max(0,e.duckT-Rt),e.duckT>0?e.ducking=!0:e.ducking&&kh(i,e)&&(e.ducking=!1),e.buffer>0&&(e.grounded||e.coyote>0)&&!e.climbing&&(!e.ducking||kh(i,e))&&(e.vy=gM,e.grounded=!1,e.coyote=0,e.buffer=0,e.holding=!0,e.holdT=0,e.ducking=!1,e.duckT=0,e.events.push("jump")),a||(e.holding=!1);const u=n?-1:xf(i,e);if(e.climbing)e.vx=0;else if(e.knockT>0)e.vx=-3;else if(e.bounced&&!e.grounded)e.vx=RM;else{let g=n?Ai:e.speed;if(u>=0){const _=i.dps[u].stopX-e.x;_<Dh&&(g*=Math.max(.25,Math.min(1,_/Dh)))}e.vx=g}if(e.climbing)e.vy=EM;else{const g=e.holding&&e.vy>0&&e.holdT<xM?Ya*_M:Ya;e.vy=Math.max(e.vy-g*Rt,-20)}n&&r?.kind==="leaf"&&!e.grounded&&e.vy<0&&(e.gliding||e.events.push("glide"),e.gliding=!0,e.vy=Math.max(e.vy,-1.3)),n&&r?.kind==="log"&&!e.logHop&&e.grounded&&e.x>=r.x-.9&&(e.logHop=!0,e.vy=9,e.grounded=!1,e.events.push("hop")),e.holdT+=Rt;const h=DM(e);e.x+=e.vx*Rt;{const g=e.x-qt/2,_=e.x+qt/2;$c(i,e,g-.1,_+.1,m=>{m.oneWay||e.x+qt/2>m.x0&&e.x-qt/2<m.x1&&e.y+h>m.y0+1e-4&&e.y<m.y1-1e-4&&(e.vx>0?e.x=m.x0-qt/2:e.vx<0&&(e.x=m.x1+qt/2))})}if(u>=0&&e.x>i.dps[u].stopX&&(e.x=i.dps[u].stopX),n&&r?.kind==="vine"&&!e.climbing&&!e.hopped){const g=r.y+vi;e.x>=r.x-.45&&e.y<g-.1&&(e.climbing=!0,e.x=r.x-.45,e.vx=0,e.events.push("climb"))}e.climbing&&r&&e.y>=r.y+vi&&(e.climbing=!1,e.hopped=!0,e.vy=TM,e.vx=Ai,e.events.push("hop"));const d=e.y,f=e.grounded;e.y+=e.vy*Rt,e.grounded=!1;{const g=e.x-qt/2,_=e.x+qt/2;$c(i,e,g,_,m=>{_>m.x0&&g<m.x1&&(e.vy<=0&&d>=m.y1-.001&&e.y<m.y1?(e.landV=-e.vy,e.y=m.y1,e.vy=0,e.grounded=!0):!m.oneWay&&e.vy>0&&e.y+h>m.y0&&d+h<=m.y0+.001?(e.y=m.y0-h,e.vy=0,e.holding=!1):!m.oneWay&&e.vy<=0&&Math.abs(e.y-m.y1)<.001&&(e.grounded=!0))})}e.climbing&&(e.grounded=!1),e.grounded&&!f&&(e.events.push("land"),e.bounced=!1),n&&r?.kind==="mushroom"&&e.vy<=0&&!e.climbing&&e.x+qt/2>=r.x-.55&&e.x-qt/2<=r.x+.55&&e.y<=r.y+Io+.05&&(e.vy=AM,e.bounced=!0,e.grounded=!1,e.events.push("bounce"));for(const g of i.hazards)if(e.x+qt/2>g.x0+.1&&e.x-qt/2<g.x1-.1&&e.y<g.y1-.05&&e.y+h>g.y0){if(n)return yo(e,"thorns");Fh(e)}if(n||i.enemies.forEach((g,_)=>{if(e.enemyDead[_])return;if(g.kind==="roller"&&e.rollAt[_]<0)if(g.x0-e.x<=hf(e.speed))e.rollAt[_]=e.et,e.lastEnemy=_,e.events.push("roll");else return;const m=LM[g.kind],p=qc(g,e.et,e.rollAt[_]),M=_f(g,e.et);e.x+qt/2>p-m.w/2&&e.x-qt/2<p+m.w/2&&e.y<M+m.h&&e.y+h>M&&(m.stomp&&e.vy<0&&d>=M+m.h*.45?(e.enemyDead[_]=1,e.vy=bM,e.holding=a,e.holdT=0,e.lastEnemy=_,e.events.push("stomp")):Fh(e))}),e.mode!=="lost"){{const g=gf(i),_=Math.floor(e.x/Mi);for(let m=Math.max(0,_-1);m<=Math.min(g.pickups.length-1,_+1);m++)for(const p of g.pickups[m]){if(e.got[p])continue;const M=i.pickups[p];Math.abs(M.x-e.x)<.7&&Math.abs(M.y-(e.y+h/2))<h/2+.45&&(e.got[p]=1,e.lastPickup=p,M.kind==="gem"?(e.gems++,e.events.push("gem")):(e.acorns++,e.events.push("acorn")))}}if(e.y<i.killY){if(n)return yo(e,Oh(i,e.x)?"splash":"fall");e.x=e.cpX,e.y=e.cpY,e.vx=e.vy=0,e.grounded=!0,e.invuln=1,e.ducking=!1,e.duckT=0,e.events.push("fall");return}if(n&&s&&e.y<s.y-(s.drop??0)-1.6)return yo(e,Oh(i,e.x)?"splash":"fall");if(n&&s){if(e.x>=s.exitX&&e.grounded){e.solved[e.dp]=1,e.cpX=s.exitX,e.cpY=e.y,e.mode="run",e.modeT=0,e.events.push("success");return}if(e.x>e.bestX+.02||e.climbing)e.bestX=Math.max(e.bestX,e.x),e.stuckT=0;else if(e.stuckT+=Rt,e.stuckT>CM)return yo(e,"bonk");return}if(u>=0&&e.grounded&&e.x>=i.dps[u].stopX-.02){e.x=i.dps[u].stopX,e.dp=u,e.mode="decide",e.modeT=0,e.vx=0,e.ducking=!1,e.duckT=0,e.events.push("dpStop");return}for(let g=e.cp+1;g<i.checkpoints.length&&e.x>=i.checkpoints[g].x;g++){e.cp=g,e.cpX=i.checkpoints[g].x,e.cpY=i.checkpoints[g].y,e.events.push("checkpoint");const _=Math.min(Nl,e.speed*(1+i.ramp));_>e.speed+1e-9&&e.events.push("speed"),e.speed=_}e.x>=i.goalX&&(e.mode="won",e.modeT=0,e.events.push("win"))}}function OM(i,e){return e.mode!=="won"?0:1+(e.acorns>=3?1:0)+(e.seeds>=i.seeds-i.dps.length?1:0)}function BM(i){i.mode==="lost"&&(i.hearts=1,i.mode="run",i.modeT=0,i.x=i.cpX,i.y=i.cpY,i.vx=i.vy=0,i.grounded=!0,i.invuln=2,i.knockT=0,i.ducking=!1,i.duckT=0)}function zM(i,e){i.seeds+=e}const HM=70,Bh=22,ja=new Set(["Space","ArrowUp","KeyW"]),zh=new Set(["ArrowDown","KeyS"]);class VM{constructor(){te(this,"enabled",!1);te(this,"jumpEdge",!1);te(this,"duckEdge",!1);te(this,"jumpKey",!1);te(this,"duckKey",!1);te(this,"touchJump",!1);te(this,"touchDuck",!1);te(this,"pending",null);te(this,"active",null);te(this,"onGesture",()=>{});te(this,"onAny",()=>{});te(this,"keyboard",!1)}attach(e){e.addEventListener("pointerdown",n=>{this.onAny(),!(!this.enabled||this.active!==null)&&(n.target.closest("button, .ui-block")||(n.preventDefault(),this.active=n.pointerId,this.pending={id:n.pointerId,x:n.clientX,y:n.clientY,t:performance.now()}))}),window.addEventListener("pointermove",n=>{if(n.pointerId!==this.active||!this.pending)return;const s=n.clientY-this.pending.y;s>Bh?this.fireDuck(n.clientX,n.clientY):s<-Bh&&this.fireJump(n.clientX,n.clientY)},{passive:!0});const t=n=>{n.pointerId===this.active&&(this.pending&&this.fireJump(n.clientX,n.clientY),this.active=null,this.touchJump=!1,this.touchDuck=!1)};window.addEventListener("pointerup",t),window.addEventListener("pointercancel",t),window.addEventListener("keydown",n=>{if(this.onAny(),!!this.enabled&&(ja.has(n.code)||zh.has(n.code))){if(n.preventDefault(),this.keyboard=!0,n.repeat)return;ja.has(n.code)?(this.jumpKey=!0,this.jumpEdge=!0):(this.duckKey=!0,this.duckEdge=!0)}}),window.addEventListener("keyup",n=>{ja.has(n.code)&&(this.jumpKey=!1),zh.has(n.code)&&(this.duckKey=!1)}),window.addEventListener("blur",()=>this.release())}fireJump(e,t){this.pending=null,this.jumpEdge=!0,this.touchJump=this.active!==null,this.onGesture("tap",e,t)}fireDuck(e,t){this.pending=null,this.duckEdge=!0,this.touchDuck=!0,this.onGesture("swipeDown",e,t)}release(){this.jumpKey=this.duckKey=this.touchJump=this.touchDuck=!1,this.jumpEdge=this.duckEdge=!1,this.pending=null,this.active=null}sample(){this.pending&&performance.now()-this.pending.t>HM&&this.fireJump(this.pending.x,this.pending.y);const e={jumpPressed:this.jumpEdge,jumpHeld:this.jumpKey||this.touchJump||this.jumpEdge,duckPressed:this.duckEdge,duckHeld:this.duckKey||this.touchDuck};return this.jumpEdge=!1,this.duckEdge=!1,e}}const zt=new VM;let Ht=null,Cr=null,zs=null,Ln=null,Yc=null,zi=null,Hh=null,zo=!1,Ul=!0,vf=!0,yf=!1;const GM=.34,WM=.7;function XM(){if(!Ht)try{Ht=new AudioContext;const i=Ht.createDynamicsCompressor();i.threshold.value=-14,i.ratio.value=3,i.connect(Ht.destination),Cr=Ht.createGain(),zs=Ht.createGain(),Cr.connect(i),zs.connect(i),Ln=Mf(Ht),na()}catch{Ht=null}Ht?.state==="suspended"&&Ht.resume(),yf&&kl()}function Mf(i){const e=i.createBuffer(1,i.sampleRate,i.sampleRate),t=e.getChannelData(0);let n=12345;for(let s=0;s<t.length;s++)n=n*1103515245+12345&2147483647,t[s]=n/2147483647*2-1;return e}function na(){!Ht||!Cr||!zs||(Cr.gain.setTargetAtTime(zo||!Ul?0:WM,Ht.currentTime,.02),zs.gain.setTargetAtTime(zo||!vf?0:GM,Ht.currentTime,.08))}function Ka(i){zo=i,na()}function qM(i){Ul=i,na()}function $M(i){vf=i,na()}const YM=104,rn=60/YM,Sf=16,Vh=Sf*4*rn,vn=i=>440*2**((i-69)/12),jM=[[48,52,55],[43,47,50],[45,48,52],[41,45,48],[48,52,55],[43,47,50],[41,45,48],[43,47,50]],Gh=[[[0,72,1],[1,76,.5],[1.5,79,.5],[2,76,1],[3,74,1]],[[0,74,1.5],[1.5,71,.5],[2,67,2]],[[0,69,1],[1,72,.5],[1.5,76,.5],[2,74,1],[3,72,1]],[[0,72,1.5],[1.5,69,.5],[2,65,1],[3,69,1]],[[0,72,.5],[.5,74,.5],[1,76,1],[2,79,1],[3,81,1]],[[0,79,1.5],[1.5,76,.5],[2,74,1],[3,71,1]],[[0,72,1],[1,69,.5],[1.5,72,.5],[2,77,1],[3,76,1]],[[0,74,2],[2,71,1],[3,74,1]]];function Pt(i,e,t,n,s,r){const o=i.createOscillator();o.type=r.type??"sine",o.frequency.value=n,r.detune&&(o.detune.value=r.detune);const a=i.createGain(),c=r.a??.01,l=r.r??.2,u=r.gain??.2;a.gain.setValueAtTime(0,t),a.gain.linearRampToValueAtTime(u,t+c),a.gain.setTargetAtTime(0,t+Math.max(c,s),l/3);let h=a;if(r.lp){const d=i.createBiquadFilter();d.type="lowpass",d.frequency.value=r.lp,a.connect(d),h=d}o.connect(a),h.connect(e),o.start(t),o.stop(t+s+l*2+.05)}function Jt(i,e,t,n,s,r){const o=vn(n);Pt(i,e,t,o,.02,{type:"sine",gain:r,a:.004,r:Math.min(1.2,.35+s*.3)}),Pt(i,e,t,o*4,.01,{type:"sine",gain:r*.18,a:.002,r:.12}),Pt(i,e,t,o*2,.02,{type:"triangle",gain:r*.25,a:.004,r:.3})}function xn(i,e,t,n,s){const r=i.createBufferSource();r.buffer=t;const o=i.createBiquadFilter();o.type=s.type??"bandpass",o.frequency.value=s.f,o.Q.value=s.q??1;const a=i.createGain();a.gain.setValueAtTime(s.gain,n),a.gain.exponentialRampToValueAtTime(8e-4,n+s.dur),r.connect(o).connect(a).connect(e),r.start(n,n*7.31%.8),r.stop(n+s.dur+.02)}async function KM(){const t=Math.ceil((Vh+2)*32e3);let n;try{n=new OfflineAudioContext(2,t,32e3)}catch{return null}const s=Mf(n),r=n.createGain();r.connect(n.destination);const o=n.createStereoPanner();o.pan.value=-.35,o.connect(r);const a=n.createStereoPanner();a.pan.value=.35,a.connect(r);for(let f=0;f<Sf;f++){const g=f*4*rn,_=jM[f%8],m=f>=8;for(const M of _)Pt(n,o,g,vn(M+12),4*rn-.1,{type:"triangle",gain:.045,a:.5,r:.8,lp:1400,detune:-6}),Pt(n,a,g,vn(M+12),4*rn-.1,{type:"triangle",gain:.045,a:.5,r:.8,lp:1400,detune:6});const p=_[0]-12;Pt(n,r,g,vn(p),rn*1.6,{type:"sine",gain:.32,a:.01,r:.25}),Pt(n,r,g+2*rn,vn(p+7),rn*1.2,{type:"sine",gain:.26,a:.01,r:.25}),Pt(n,r,g+3.5*rn,vn(p+12),rn*.4,{type:"sine",gain:.18,a:.01,r:.15});for(let M=0;M<8;M++){const v=_[[0,1,2,1,0,2,1,2][M]]+24;Jt(n,a,g+M*rn*.5,v,.5,M%2?.035:.05)}for(const[M,v,x]of Gh[f%8])Jt(n,r,g+M*rn,v+(m&&f%2===0,0),x,m?.13:.11);if(m)for(const[M,v,x]of Gh[f%8])Jt(n,o,g+M*rn+.01,v-12,x,.04);for(let M=0;M<4;M++){const v=g+M*rn;if(M%2===0){const x=n.createOscillator(),I=n.createGain();x.frequency.setValueAtTime(130,v),x.frequency.exponentialRampToValueAtTime(45,v+.12),I.gain.setValueAtTime(.38,v),I.gain.exponentialRampToValueAtTime(.001,v+.22),x.connect(I).connect(r),x.start(v),x.stop(v+.25)}else xn(n,r,s,v,{gain:.12,f:1800,q:1.2,dur:.09});xn(n,a,s,v,{gain:.04,f:7e3,q:.8,dur:.04,type:"highpass"}),xn(n,a,s,v+rn/2,{gain:.05,f:7500,q:.8,dur:.05,type:"highpass"})}}const c=await n.startRendering(),l=Math.round(Vh*32e3),u=new AudioBuffer({numberOfChannels:2,length:l,sampleRate:32e3});let h=0;for(let f=0;f<2;f++){const g=c.getChannelData(f),_=u.getChannelData(f);for(let m=0;m<l;m++)_[m]=g[m]+(m+l<g.length?g[m+l]:0);for(let m=0;m<l;m++)h=Math.max(h,Math.abs(_[m]))}const d=h>0?.9/h:1;for(let f=0;f<2;f++){const g=u.getChannelData(f);for(let _=0;_<l;_++)g[_]*=d}return u}function wf(){return Hh??(Hh=KM().then(i=>Yc=i)),Hh}async function kl(){yf=!0,!(!Ht||!zs||zi)&&(await wf(),!(!Yc||zi||!Ht)&&(zi=Ht.createBufferSource(),zi.buffer=Yc,zi.loop=!0,zi.connect(zs),zi.start()))}let Za=0,Wh=0;function Mt(i){const e=Ht,t=Cr;if(!e||!t||!Ln||zo||!Ul)return;const n=e.currentTime+.005;switch(i){case"jump":{const s=e.createOscillator(),r=e.createGain();s.type="sine",s.frequency.setValueAtTime(330,n),s.frequency.exponentialRampToValueAtTime(720,n+.13),r.gain.setValueAtTime(.18,n),r.gain.exponentialRampToValueAtTime(.001,n+.18),s.connect(r).connect(t),s.start(n),s.stop(n+.2);break}case"land":xn(e,t,Ln,n,{gain:.2,f:300,q:.7,dur:.09,type:"lowpass"});break;case"duck":xn(e,t,Ln,n,{gain:.16,f:900,q:.6,dur:.25,type:"lowpass"});break;case"gem":{const s=performance.now();Za=s-Wh<450?Math.min(Za+1,10):0,Wh=s;const r=84+[0,2,4,7,9,12,14,16,19,21,24][Za];Jt(e,t,n,r,.4,.16),Pt(e,t,n+.05,vn(r+7),.02,{gain:.05,r:.2});break}case"acorn":[72,76,79,84,88].forEach((s,r)=>Jt(e,t,n+r*.07,s,.8,.18)),Pt(e,t,n+.35,vn(96),.3,{gain:.04,a:.01,r:.8});break;case"checkpoint":[79,84].forEach((s,r)=>Jt(e,t,n+r*.09,s,.5,.12));break;case"hit":{const s=e.createOscillator(),r=e.createGain();s.type="square",s.frequency.setValueAtTime(420,n),s.frequency.exponentialRampToValueAtTime(110,n+.25),r.gain.setValueAtTime(.09,n),r.gain.exponentialRampToValueAtTime(.001,n+.3);const o=e.createBiquadFilter();o.frequency.value=1600,s.connect(o).connect(r).connect(t),s.start(n),s.stop(n+.32);break}case"stomp":xn(e,t,Ln,n,{gain:.3,f:500,q:1,dur:.12}),Pt(e,t,n,180,.05,{type:"triangle",gain:.25,r:.1}),Jt(e,t,n+.06,88,.3,.1);break;case"grow":for(let s=0;s<8;s++)Jt(e,t,n+s*.09,[60,64,67,72,76,79,84,88][s],.5,.06+s*.012);xn(e,t,Ln,n,{gain:.18,f:2500,q:.5,dur:.9}),Pt(e,t,n+.75,vn(91),.2,{gain:.06,a:.02,r:.9});break;case"bounce":{const s=e.createOscillator(),r=e.createGain();s.type="sine",s.frequency.setValueAtTime(140,n),s.frequency.exponentialRampToValueAtTime(520,n+.22),r.gain.setValueAtTime(.32,n),r.gain.exponentialRampToValueAtTime(.001,n+.35),s.connect(r).connect(t),s.start(n),s.stop(n+.36);break}case"climb":for(let s=0;s<6;s++)xn(e,t,Ln,n+s*.18,{gain:.1,f:1400+s*120,q:2,dur:.06});break;case"splash":xn(e,t,Ln,n,{gain:.4,f:1200,q:.4,dur:.6,type:"lowpass"}),[70,66,63].forEach((s,r)=>Pt(e,t,n+.2+r*.12,vn(s),.05,{gain:.09,r:.15}));break;case"bonk":Pt(e,t,n,210,.03,{type:"triangle",gain:.35,r:.12}),xn(e,t,Ln,n,{gain:.25,f:700,q:3,dur:.1}),[91,88,91].forEach((s,r)=>Pt(e,t,n+.2+r*.1,vn(s),.02,{gain:.05,r:.08}));break;case"thorns":xn(e,t,Ln,n,{gain:.25,f:3e3,q:4,dur:.15}),Pt(e,t,n+.05,600,.12,{type:"triangle",gain:.14,r:.1}),Pt(e,t,n+.17,760,.12,{type:"triangle",gain:.14,r:.15});break;case"card":Jt(e,t,n,79,.2,.12);break;case"click":Pt(e,t,n,900,.01,{type:"triangle",gain:.12,r:.05});break;case"glide":xn(e,t,Ln,n,{gain:.18,f:900,q:.5,dur:.8,type:"lowpass"}),[79,76,72].forEach((s,r)=>Jt(e,t,n+r*.12,s,.6,.06));break;case"roll":for(let s=0;s<5;s++)Pt(e,t,n+s*.09,110+s*6,.04,{type:"triangle",gain:.12,r:.06});break;case"buy":[76,79,84,88].forEach((s,r)=>Jt(e,t,n+r*.06,s,.5,.14));break;case"reward":[72,79,84,91].forEach((s,r)=>Jt(e,t,n+r*.08,s,.7,.15));break;case"stop":[76,72].forEach((s,r)=>Jt(e,t,n+r*.1,s,.4,.1));break;case"win":[72,76,79,84,79,84,88].forEach((s,r)=>Jt(e,t,n+r*.11,s,.8,.16)),[60,64,67].forEach(s=>Pt(e,t,n+.66,vn(s),.8,{type:"triangle",gain:.06,a:.05,r:.8}));break;case"fall":{const s=e.createOscillator(),r=e.createGain();s.frequency.setValueAtTime(700,n),s.frequency.exponentialRampToValueAtTime(160,n+.45),r.gain.setValueAtTime(.12,n),r.gain.exponentialRampToValueAtTime(.001,n+.5),s.connect(r).connect(t),s.start(n),s.stop(n+.52)}break;case"lose":[67,64,60,55].forEach((s,r)=>Jt(e,t,n+r*.16,s,.6,.12));break}}const ZM="Sprout Trail",JM="Grow your way home",QM="Loading…",e1="Back",t1="Nice!",n1="Retry",i1="Checkpoint!",s1="Faster!",r1={title:ZM,tagline:JM,loading:QM,"menu.play":"Play","menu.continue":"Continue","menu.worlds":"Worlds","menu.daily":"Daily","menu.settings":"Settings","menu.soon":"Soon","world.1":"Spring Meadow","world.2":"Deep Forest","world.3":"Mushroom Valley","world.4":"Autumn Woods","world.5":"Misty Swamp","level.name":"Level {n}","settings.title":"Settings","settings.music":"Music","settings.sfx":"Sound effects","settings.language":"Language","settings.reset":"Reset progress","settings.resetAsk":"Erase all stars, acorns and gems?","settings.resetYes":"Yes, erase","settings.resetNo":"Keep it","settings.on":"On","settings.off":"Off",back:e1,"pause.title":"Paused","pause.resume":"Resume","pause.restart":"Restart","pause.menu":"Menu","tut.jump.touch":"Tap to jump","tut.jump.keys":"Press Space to jump","tut.hold.touch":"Hold to jump higher","tut.hold.keys":"Hold Space to jump higher","tut.duck.touch":"Swipe down to duck","tut.duck.keys":"Press Down to duck","tut.choose":"Choose the right plant","tut.stomp":"Jump on beetles","dp.prompt":"Which plant gets you across?","dp.seeds":"Seeds left: {n}","plant.bridge":"Bridge","plant.vine":"Vine ladder","plant.mushroom":"Mushroom","plant.tree":"Tall tree","plant.leaf":"Big leaf","plant.log":"Log","fail.splash":"Splash! It can't reach the other side.","fail.thorns":"Ouch! The thorns poke through.","fail.bonk":"Bonk! The wall is too high.","fail.fall":"Whoops! Nothing to land on.","fail.again":"Try another seed",nice:t1,"win.title":"Level complete!","win.acorns":"Golden acorns","win.gems":"Gems","win.seeds":"Seeds left","win.next":"Next","win.retry":"Retry","win.menu":"Menu","lost.title":"Out of hearts","lost.text":"Shake off the leaves and try again!","seeds.title":"Out of seeds","seeds.text":"No seeds left to plant here.",retry:n1,checkpoint:i1,"menu.wardrobe":"Wardrobe","world.locked":"Finish the world before","world.special":"Golden Grove","world.specialLocked":"Finish level 12 to open","worlds.stars":"{n} stars","wardrobe.title":"Wardrobe","wardrobe.hats":"Hats","wardrobe.colors":"Colours","wardrobe.equip":"Wear","wardrobe.equipped":"Worn","wardrobe.poor":"Not enough gems yet","hat.none":"No hat","hat.acorn":"Acorn cap","hat.flower":"Flower","hat.bow":"Blue bow","hat.mushroom":"Mushroom","hat.straw":"Straw hat","hat.crown":"Leaf crown","color.leaf":"Leaf green","color.sun":"Sunny","color.sky":"Sky blue","color.blossom":"Blossom","color.lavender":"Lavender","color.autumn":"Autumn","color.moss":"Moss","daily.title":"Daily trail","daily.text":"A new trail every day. Finish it to grow your streak!","daily.streak":"Streak: {n}","daily.best":"Best: {n}","daily.play":"Play today's trail","daily.done":"Done for today. Come back tomorrow!","daily.again":"Play again","ad.seeds":"Watch an ad: +2 seeds","ad.heart":"Watch an ad: continue with 1 heart","ad.gems":"Watch an ad: double gems","ad.none":"No ad available right now, try later","ad.doubled":"Gems doubled!","tut.bee":"Duck under the bees","tut.leaf":"Big leaves glide far","tut.acornChoice":"Some plants find acorns","tut.snail":"Snails are spiky: jump","tut.tree":"Trees make long bridges","tut.roll":"Rolling acorns: jump!","tut.log":"Logs cross low thorns","tut.double":"Two obstacles in a row","tut.fog":"Stay sharp in the fog",faster:s1,"win.earned":"Gems earned","fail.missedAcorn":"It worked, but no golden acorn"},o1="Sprout Trail",a1="Pousse jusqu'à la maison",c1="Chargement…",l1="Retour",u1="Bravo !",h1="Réessayer",d1="Point de contrôle !",f1="Plus vite !",p1={title:o1,tagline:a1,loading:c1,"menu.play":"Jouer","menu.continue":"Continuer","menu.worlds":"Mondes","menu.daily":"Défi du jour","menu.settings":"Réglages","menu.soon":"Bientôt","world.1":"Prairie printanière","world.2":"Forêt profonde","world.3":"Vallée des champignons","world.4":"Bois d'automne","world.5":"Marais brumeux","level.name":"Niveau {n}","settings.title":"Réglages","settings.music":"Musique","settings.sfx":"Effets sonores","settings.language":"Langue","settings.reset":"Réinitialiser la progression","settings.resetAsk":"Effacer toutes les étoiles, glands et gemmes ?","settings.resetYes":"Oui, effacer","settings.resetNo":"Non, garder","settings.on":"Oui","settings.off":"Non",back:l1,"pause.title":"Pause","pause.resume":"Reprendre","pause.restart":"Recommencer","pause.menu":"Menu","tut.jump.touch":"Touche pour sauter","tut.jump.keys":"Espace pour sauter","tut.hold.touch":"Maintiens pour sauter plus haut","tut.hold.keys":"Maintiens Espace pour sauter plus haut","tut.duck.touch":"Glisse vers le bas pour te baisser","tut.duck.keys":"Flèche bas pour te baisser","tut.choose":"Choisis la bonne plante","tut.stomp":"Saute sur les scarabées","dp.prompt":"Quelle plante te fera passer ?","dp.seeds":"Graines restantes : {n}","plant.bridge":"Pont","plant.vine":"Échelle de lianes","plant.mushroom":"Champignon","plant.tree":"Grand arbre","plant.leaf":"Grande feuille","plant.log":"Rondin","fail.splash":"Plouf ! Ça n'atteint pas l'autre rive.","fail.thorns":"Aïe ! Les épines passent à travers.","fail.bonk":"Bonk ! Le mur est trop haut.","fail.fall":"Oups ! Rien pour atterrir.","fail.again":"Essaie une autre graine",nice:u1,"win.title":"Niveau terminé !","win.acorns":"Glands dorés","win.gems":"Gemmes","win.seeds":"Graines restantes","win.next":"Suivant","win.retry":"Rejouer","win.menu":"Menu","lost.title":"Plus de cœurs","lost.text":"Secoue les feuilles et réessaie !","seeds.title":"Plus de graines","seeds.text":"Il ne reste aucune graine à planter ici.",retry:h1,checkpoint:d1,"menu.wardrobe":"Garde-robe","world.locked":"Termine d'abord le monde précédent","world.special":"Bosquet doré","world.specialLocked":"Termine le niveau 12 pour l'ouvrir","worlds.stars":"{n} étoiles","wardrobe.title":"Garde-robe","wardrobe.hats":"Chapeaux","wardrobe.colors":"Couleurs","wardrobe.equip":"Porter","wardrobe.equipped":"Porté","wardrobe.poor":"Pas encore assez de gemmes","hat.none":"Sans chapeau","hat.acorn":"Chapeau gland","hat.flower":"Fleur","hat.bow":"Nœud bleu","hat.mushroom":"Champignon","hat.straw":"Chapeau de paille","hat.crown":"Couronne de feuilles","color.leaf":"Vert feuille","color.sun":"Soleil","color.sky":"Bleu ciel","color.blossom":"Fleur de cerisier","color.lavender":"Lavande","color.autumn":"Automne","color.moss":"Mousse","daily.title":"Sentier du jour","daily.text":"Un nouveau sentier chaque jour. Termine-le pour prolonger ta série !","daily.streak":"Série : {n}","daily.best":"Record : {n}","daily.play":"Jouer le sentier du jour","daily.done":"Fini pour aujourd'hui. Reviens demain !","daily.again":"Rejouer","ad.seeds":"Regarder une pub : +2 graines","ad.heart":"Regarder une pub : continuer avec 1 cœur","ad.gems":"Regarder une pub : doubler les gemmes","ad.none":"Aucune pub disponible pour l'instant, réessaie plus tard","ad.doubled":"Gemmes doublées !","tut.bee":"Baisse-toi sous les abeilles","tut.leaf":"Les grandes feuilles planent loin","tut.acornChoice":"Certaines plantes trouvent des glands","tut.snail":"Escargots piquants : saute !","tut.tree":"Les arbres font de longs ponts","tut.roll":"Glands qui roulent : saute !","tut.log":"Les rondins passent les épines basses","tut.double":"Deux obstacles d'affilée","tut.fog":"Reste attentif dans la brume",faster:f1,"win.earned":"Gemmes gagnées","fail.missedAcorn":"Ça marche, mais sans gland doré"},m1="Sprout Trail",g1="Wachse dich nach Hause",_1="Lädt…",x1="Zurück",v1="Super!",y1="Nochmal",M1="Kontrollpunkt!",S1="Schneller!",w1={title:m1,tagline:g1,loading:_1,"menu.play":"Spielen","menu.continue":"Weiter","menu.worlds":"Welten","menu.daily":"Täglich","menu.settings":"Einstellungen","menu.soon":"Bald","world.1":"Frühlingswiese","world.2":"Tiefer Wald","world.3":"Pilztal","world.4":"Herbstwald","world.5":"Nebelsumpf","level.name":"Level {n}","settings.title":"Einstellungen","settings.music":"Musik","settings.sfx":"Soundeffekte","settings.language":"Sprache","settings.reset":"Fortschritt zurücksetzen","settings.resetAsk":"Alle Sterne, Eicheln und Edelsteine löschen?","settings.resetYes":"Ja, löschen","settings.resetNo":"Behalten","settings.on":"An","settings.off":"Aus",back:x1,"pause.title":"Pause","pause.resume":"Weiter","pause.restart":"Neu starten","pause.menu":"Menü","tut.jump.touch":"Tippen zum Springen","tut.jump.keys":"Leertaste zum Springen","tut.hold.touch":"Halten für höhere Sprünge","tut.hold.keys":"Leertaste halten: höher springen","tut.duck.touch":"Nach unten wischen zum Ducken","tut.duck.keys":"Pfeil runter zum Ducken","tut.choose":"Wähle die richtige Pflanze","tut.stomp":"Spring auf die Käfer","dp.prompt":"Welche Pflanze bringt dich rüber?","dp.seeds":"Samen übrig: {n}","plant.bridge":"Brücke","plant.vine":"Rankenleiter","plant.mushroom":"Pilz","plant.tree":"Hoher Baum","plant.leaf":"Großes Blatt","plant.log":"Baumstamm","fail.splash":"Platsch! Sie reicht nicht ans andere Ufer.","fail.thorns":"Autsch! Die Dornen stechen durch.","fail.bonk":"Bonk! Die Wand ist zu hoch.","fail.fall":"Hoppla! Nichts zum Landen.","fail.again":"Versuch einen anderen Samen",nice:v1,"win.title":"Level geschafft!","win.acorns":"Goldene Eicheln","win.gems":"Edelsteine","win.seeds":"Samen übrig","win.next":"Weiter","win.retry":"Nochmal","win.menu":"Menü","lost.title":"Keine Herzen mehr","lost.text":"Schüttel die Blätter ab und versuch's nochmal!","seeds.title":"Keine Samen mehr","seeds.text":"Hier sind keine Samen mehr zum Pflanzen.",retry:y1,checkpoint:M1,"menu.wardrobe":"Kleiderschrank","world.locked":"Schaffe zuerst die Welt davor","world.special":"Goldener Hain","world.specialLocked":"Schaffe Level 12, um ihn zu öffnen","worlds.stars":"{n} Sterne","wardrobe.title":"Kleiderschrank","wardrobe.hats":"Hüte","wardrobe.colors":"Farben","wardrobe.equip":"Anziehen","wardrobe.equipped":"Angezogen","wardrobe.poor":"Noch nicht genug Edelsteine","hat.none":"Kein Hut","hat.acorn":"Eichelkappe","hat.flower":"Blume","hat.bow":"Blaue Schleife","hat.mushroom":"Pilz","hat.straw":"Strohhut","hat.crown":"Blätterkrone","color.leaf":"Blattgrün","color.sun":"Sonnig","color.sky":"Himmelblau","color.blossom":"Blüte","color.lavender":"Lavendel","color.autumn":"Herbst","color.moss":"Moos","daily.title":"Tagespfad","daily.text":"Jeden Tag ein neuer Pfad. Schaffe ihn und verlängere deine Serie!","daily.streak":"Serie: {n}","daily.best":"Rekord: {n}","daily.play":"Heutigen Pfad spielen","daily.done":"Für heute geschafft. Komm morgen wieder!","daily.again":"Nochmal spielen","ad.seeds":"Werbung ansehen: +2 Samen","ad.heart":"Werbung ansehen: mit 1 Herz weiter","ad.gems":"Werbung ansehen: doppelte Edelsteine","ad.none":"Gerade keine Werbung verfügbar, versuch es später","ad.doubled":"Edelsteine verdoppelt!","tut.bee":"Duck dich unter Bienen","tut.leaf":"Große Blätter gleiten weit","tut.acornChoice":"Manche Pflanzen finden Eicheln","tut.snail":"Schnecken sind stachelig: spring","tut.tree":"Bäume werden lange Brücken","tut.roll":"Rollende Eicheln: spring!","tut.log":"Stämme gehen über niedrige Dornen","tut.double":"Zwei Hindernisse hintereinander","tut.fog":"Pass im Nebel gut auf",faster:S1,"win.earned":"Verdiente Edelsteine","fail.missedAcorn":"Geschafft, aber ohne goldene Eichel"},b1="Sprout Trail",E1="Crece hasta llegar a casa",T1="Cargando…",A1="Volver",R1="¡Bien hecho!",C1="Reintentar",P1="¡Punto de control!",L1="¡Más rápido!",I1={title:b1,tagline:E1,loading:T1,"menu.play":"Jugar","menu.continue":"Continuar","menu.worlds":"Mundos","menu.daily":"Diario","menu.settings":"Ajustes","menu.soon":"Pronto","world.1":"Prado primaveral","world.2":"Bosque profundo","world.3":"Valle de setas","world.4":"Bosque otoñal","world.5":"Pantano brumoso","level.name":"Nivel {n}","settings.title":"Ajustes","settings.music":"Música","settings.sfx":"Efectos de sonido","settings.language":"Idioma","settings.reset":"Borrar progreso","settings.resetAsk":"¿Borrar todas las estrellas, bellotas y gemas?","settings.resetYes":"Sí, borrar","settings.resetNo":"No, conservar","settings.on":"Sí","settings.off":"No",back:A1,"pause.title":"Pausa","pause.resume":"Seguir","pause.restart":"Reiniciar","pause.menu":"Menú","tut.jump.touch":"Toca para saltar","tut.jump.keys":"Pulsa Espacio para saltar","tut.hold.touch":"Mantén para saltar más alto","tut.hold.keys":"Mantén Espacio para saltar más alto","tut.duck.touch":"Desliza hacia abajo para agacharte","tut.duck.keys":"Pulsa Abajo para agacharte","tut.choose":"Elige la planta correcta","tut.stomp":"Salta sobre los escarabajos","dp.prompt":"¿Qué planta te hace cruzar?","dp.seeds":"Semillas: {n}","plant.bridge":"Puente","plant.vine":"Escalera de lianas","plant.mushroom":"Seta","plant.tree":"Árbol alto","plant.leaf":"Hoja grande","plant.log":"Tronco","fail.splash":"¡Chof! No llega a la otra orilla.","fail.thorns":"¡Ay! Las espinas lo atraviesan.","fail.bonk":"¡Bonk! El muro es demasiado alto.","fail.fall":"¡Uy! No hay dónde aterrizar.","fail.again":"Prueba otra semilla",nice:R1,"win.title":"¡Nivel superado!","win.acorns":"Bellotas doradas","win.gems":"Gemas","win.seeds":"Semillas restantes","win.next":"Siguiente","win.retry":"Repetir","win.menu":"Menú","lost.title":"Sin corazones","lost.text":"¡Sacúdete las hojas y vuelve a intentarlo!","seeds.title":"Sin semillas","seeds.text":"No quedan semillas para plantar aquí.",retry:C1,checkpoint:P1,"menu.wardrobe":"Armario","world.locked":"Termina antes el mundo anterior","world.special":"Arboleda dorada","world.specialLocked":"Termina el nivel 12 para abrirla","worlds.stars":"{n} estrellas","wardrobe.title":"Armario","wardrobe.hats":"Sombreros","wardrobe.colors":"Colores","wardrobe.equip":"Ponerse","wardrobe.equipped":"Puesto","wardrobe.poor":"Aún no tienes gemas suficientes","hat.none":"Sin sombrero","hat.acorn":"Gorro de bellota","hat.flower":"Flor","hat.bow":"Lazo azul","hat.mushroom":"Seta","hat.straw":"Sombrero de paja","hat.crown":"Corona de hojas","color.leaf":"Verde hoja","color.sun":"Soleado","color.sky":"Azul cielo","color.blossom":"Flor de cerezo","color.lavender":"Lavanda","color.autumn":"Otoño","color.moss":"Musgo","daily.title":"Sendero diario","daily.text":"Un sendero nuevo cada día. ¡Termínalo para alargar tu racha!","daily.streak":"Racha: {n}","daily.best":"Récord: {n}","daily.play":"Jugar el sendero de hoy","daily.done":"Listo por hoy. ¡Vuelve mañana!","daily.again":"Jugar otra vez","ad.seeds":"Ver un anuncio: +2 semillas","ad.heart":"Ver un anuncio: seguir con 1 corazón","ad.gems":"Ver un anuncio: doble de gemas","ad.none":"No hay anuncios ahora, inténtalo más tarde","ad.doubled":"¡Gemas duplicadas!","tut.bee":"Agáchate bajo las abejas","tut.leaf":"Las hojas grandes planean lejos","tut.acornChoice":"Algunas plantas encuentran bellotas","tut.snail":"Caracoles con pinchos: ¡salta!","tut.tree":"Los árboles hacen puentes largos","tut.roll":"Bellotas rodando: ¡salta!","tut.log":"Los troncos cruzan espinas bajas","tut.double":"Dos obstáculos seguidos","tut.fog":"Atento en la niebla",faster:L1,"win.earned":"Gemas ganadas","fail.missedAcorn":"Funciona, pero sin bellota dorada"},D1="Sprout Trail",N1="Cresci fino a casa",U1="Caricamento…",k1="Indietro",F1="Bravo!",O1="Riprova",B1="Checkpoint!",z1="Più veloce!",H1={title:D1,tagline:N1,loading:U1,"menu.play":"Gioca","menu.continue":"Continua","menu.worlds":"Mondi","menu.daily":"Sfida del giorno","menu.settings":"Impostazioni","menu.soon":"Presto","world.1":"Prato di primavera","world.2":"Foresta profonda","world.3":"Valle dei funghi","world.4":"Bosco d'autunno","world.5":"Palude nebbiosa","level.name":"Livello {n}","settings.title":"Impostazioni","settings.music":"Musica","settings.sfx":"Effetti sonori","settings.language":"Lingua","settings.reset":"Azzera i progressi","settings.resetAsk":"Cancellare tutte le stelle, ghiande e gemme?","settings.resetYes":"Sì, cancella","settings.resetNo":"No, tienili","settings.on":"Sì","settings.off":"No",back:k1,"pause.title":"Pausa","pause.resume":"Riprendi","pause.restart":"Ricomincia","pause.menu":"Menu","tut.jump.touch":"Tocca per saltare","tut.jump.keys":"Premi Spazio per saltare","tut.hold.touch":"Tieni premuto per saltare più in alto","tut.hold.keys":"Tieni Spazio per saltare più in alto","tut.duck.touch":"Scorri in giù per abbassarti","tut.duck.keys":"Premi Giù per abbassarti","tut.choose":"Scegli la pianta giusta","tut.stomp":"Salta sui coleotteri","dp.prompt":"Quale pianta ti fa passare?","dp.seeds":"Semi rimasti: {n}","plant.bridge":"Ponte","plant.vine":"Scala di liane","plant.mushroom":"Fungo","plant.tree":"Albero alto","plant.leaf":"Foglia grande","plant.log":"Tronco","fail.splash":"Splash! Non arriva all'altra riva.","fail.thorns":"Ahi! Le spine passano attraverso.","fail.bonk":"Bonk! Il muro è troppo alto.","fail.fall":"Ops! Niente su cui atterrare.","fail.again":"Prova un altro seme",nice:F1,"win.title":"Livello completato!","win.acorns":"Ghiande d'oro","win.gems":"Gemme","win.seeds":"Semi rimasti","win.next":"Avanti","win.retry":"Riprova","win.menu":"Menu","lost.title":"Niente più cuori","lost.text":"Scrollati le foglie e riprova!","seeds.title":"Niente più semi","seeds.text":"Non restano semi da piantare qui.",retry:O1,checkpoint:B1,"menu.wardrobe":"Guardaroba","world.locked":"Completa prima il mondo precedente","world.special":"Boschetto dorato","world.specialLocked":"Completa il livello 12 per aprirlo","worlds.stars":"{n} stelle","wardrobe.title":"Guardaroba","wardrobe.hats":"Cappelli","wardrobe.colors":"Colori","wardrobe.equip":"Indossa","wardrobe.equipped":"Indossato","wardrobe.poor":"Non hai ancora abbastanza gemme","hat.none":"Senza cappello","hat.acorn":"Cappello a ghianda","hat.flower":"Fiore","hat.bow":"Fiocco blu","hat.mushroom":"Fungo","hat.straw":"Cappello di paglia","hat.crown":"Corona di foglie","color.leaf":"Verde foglia","color.sun":"Solare","color.sky":"Azzurro cielo","color.blossom":"Fiore di ciliegio","color.lavender":"Lavanda","color.autumn":"Autunno","color.moss":"Muschio","daily.title":"Sentiero del giorno","daily.text":"Un nuovo sentiero ogni giorno. Completalo per allungare la serie!","daily.streak":"Serie: {n}","daily.best":"Record: {n}","daily.play":"Gioca il sentiero di oggi","daily.done":"Fatto per oggi. Torna domani!","daily.again":"Gioca ancora","ad.seeds":"Guarda una pubblicità: +2 semi","ad.heart":"Guarda una pubblicità: continua con 1 cuore","ad.gems":"Guarda una pubblicità: gemme doppie","ad.none":"Nessuna pubblicità disponibile ora, riprova più tardi","ad.doubled":"Gemme raddoppiate!","tut.bee":"Abbassati sotto le api","tut.leaf":"Le foglie grandi planano lontano","tut.acornChoice":"Alcune piante trovano ghiande","tut.snail":"Lumache spinose: salta!","tut.tree":"Gli alberi fanno ponti lunghi","tut.roll":"Ghiande che rotolano: salta!","tut.log":"I tronchi superano spine basse","tut.double":"Due ostacoli di fila","tut.fog":"Attento nella nebbia",faster:z1,"win.earned":"Gemme guadagnate","fail.missedAcorn":"Funziona, ma niente ghianda d'oro"},V1="Sprout Trail",G1="Расти до самого дома",W1="Загрузка…",X1="Назад",q1="Здорово!",$1="Ещё раз",Y1="Контрольная точка!",j1="Быстрее!",K1={title:V1,tagline:G1,loading:W1,"menu.play":"Играть","menu.continue":"Продолжить","menu.worlds":"Миры","menu.daily":"Ежедневно","menu.settings":"Настройки","menu.soon":"Скоро","world.1":"Весенний луг","world.2":"Густой лес","world.3":"Грибная долина","world.4":"Осенний лес","world.5":"Туманное болото","level.name":"Уровень {n}","settings.title":"Настройки","settings.music":"Музыка","settings.sfx":"Звуки","settings.language":"Язык","settings.reset":"Сбросить прогресс","settings.resetAsk":"Стереть все звёзды, жёлуди и кристаллы?","settings.resetYes":"Да, стереть","settings.resetNo":"Оставить","settings.on":"Вкл","settings.off":"Выкл",back:X1,"pause.title":"Пауза","pause.resume":"Продолжить","pause.restart":"Заново","pause.menu":"Меню","tut.jump.touch":"Нажми, чтобы прыгнуть","tut.jump.keys":"Пробел — прыжок","tut.hold.touch":"Удерживай — прыжок выше","tut.hold.keys":"Держи пробел — прыжок выше","tut.duck.touch":"Проведи вниз — пригнуться","tut.duck.keys":"Стрелка вниз — пригнуться","tut.choose":"Выбери нужное растение","tut.stomp":"Прыгай на жуков","dp.prompt":"Какое растение поможет пройти?","dp.seeds":"Осталось семян: {n}","plant.bridge":"Мост","plant.vine":"Лестница из лиан","plant.mushroom":"Гриб","plant.tree":"Высокое дерево","plant.leaf":"Большой лист","plant.log":"Бревно","fail.splash":"Плюх! Не достаёт до берега.","fail.thorns":"Ай! Шипы колются насквозь.","fail.bonk":"Бум! Стена слишком высокая.","fail.fall":"Ой! Приземлиться не на что.","fail.again":"Попробуй другое семечко",nice:q1,"win.title":"Уровень пройден!","win.acorns":"Золотые жёлуди","win.gems":"Кристаллы","win.seeds":"Осталось семян","win.next":"Дальше","win.retry":"Заново","win.menu":"Меню","lost.title":"Сердечки кончились","lost.text":"Отряхнись от листьев и попробуй снова!","seeds.title":"Семена кончились","seeds.text":"Здесь больше нечего посадить.",retry:$1,checkpoint:Y1,"menu.wardrobe":"Гардероб","world.locked":"Сначала пройди прошлый мир","world.special":"Золотая роща","world.specialLocked":"Пройди уровень 12, чтобы открыть","worlds.stars":"Звёзд: {n}","wardrobe.title":"Гардероб","wardrobe.hats":"Шляпы","wardrobe.colors":"Цвета","wardrobe.equip":"Надеть","wardrobe.equipped":"Надето","wardrobe.poor":"Пока мало кристаллов","hat.none":"Без шляпы","hat.acorn":"Шапочка-жёлудь","hat.flower":"Цветок","hat.bow":"Синий бант","hat.mushroom":"Гриб","hat.straw":"Соломенная шляпа","hat.crown":"Венок из листьев","color.leaf":"Зелёный лист","color.sun":"Солнечный","color.sky":"Небесный","color.blossom":"Цветущий","color.lavender":"Лавандовый","color.autumn":"Осенний","color.moss":"Мох","daily.title":"Тропа дня","daily.text":"Каждый день новая тропа. Пройди её и продли серию!","daily.streak":"Серия: {n}","daily.best":"Рекорд: {n}","daily.play":"Пройти тропу дня","daily.done":"На сегодня всё. Приходи завтра!","daily.again":"Сыграть ещё","ad.seeds":"Смотреть рекламу: +2 семени","ad.heart":"Смотреть рекламу: продолжить с 1 сердцем","ad.gems":"Смотреть рекламу: удвоить кристаллы","ad.none":"Реклама сейчас недоступна, попробуй позже","ad.doubled":"Кристаллы удвоены!","tut.bee":"Пригнись под пчёлами","tut.leaf":"Большие листья планируют далеко","tut.acornChoice":"Некоторые растения находят жёлуди","tut.snail":"Улитки колючие — прыгай","tut.tree":"Деревья — длинные мосты","tut.roll":"Катятся жёлуди — прыгай!","tut.log":"Бревно над низкими шипами","tut.double":"Два препятствия подряд","tut.fog":"Будь внимателен в тумане",faster:j1,"win.earned":"Получено кристаллов","fail.missedAcorn":"Получилось, но без золотого жёлудя"},bf=["en","fr","de","es","it","ru"],Z1={en:"English",fr:"Français",de:"Deutsch",es:"Español",it:"Italiano",ru:"Русский"},jc={en:r1,fr:p1,de:w1,es:I1,it:H1,ru:K1};let Fl="en";const Kc=new Set;function J1(i){if(!i)return null;const e=i.toLowerCase().replace("_","-").split("-")[0];return bf.includes(e)?e:null}function Q1(...i){for(const e of i){const t=J1(e);if(t)return t}return"en"}const eS=()=>Fl;function Ol(i){Fl=i,typeof document<"u"&&(document.documentElement.lang=i);for(const e of Kc)e(i)}function tS(i){return Kc.add(i),()=>Kc.delete(i)}const nS=i=>i in jc.en;function $t(i,e){let t=jc[Fl][i]??jc.en[i]??i;if(e)for(const[n,s]of Object.entries(e))t=t.split(`{${n}}`).join(String(s));return t}const iS=(()=>{const i=new Pi;return i.moveTo(0,-.12),i.quadraticCurveTo(.09,0,0,.12),i.quadraticCurveTo(-.09,0,0,-.12),new es(i,4)})();class sS{constructor(e){te(this,"ps",[]);te(this,"seed",1);this.root=e}rnd(){return this.seed=this.seed*16807%2147483647,this.seed/2147483647}sprite(e,t){const n=new Ml({map:Dl(),color:e,transparent:!0,depthWrite:!1,blending:t?Cs:$i});return new Vd(n)}add(e,t){this.root.add(e),this.ps.push({s:e,...t})}dust(e,t,n=8,s=1){for(let r=0;r<n;r++){const o=this.sprite("#f2e6c8",!1);o.position.set(e+(this.rnd()-.5)*.5,t+.1,(this.rnd()-.5)*.6+.3);const a=this.rnd()<.5?-1:1;this.add(o,{vx:a*(.6+this.rnd()*1.6)*s,vy:.4+this.rnd()*.8,vz:(this.rnd()-.5)*.5,g:-.6,life:0,max:.45+this.rnd()*.3,size:.35+this.rnd()*.3,spin:0,fade:!0})}}sparkle(e,t,n="#9ff0ff",s=10){for(let r=0;r<s;r++){const o=this.sprite(n,!0);o.position.set(e,t,.2);const a=this.rnd()*Math.PI*2,c=1.5+this.rnd()*2.5;this.add(o,{vx:Math.cos(a)*c,vy:Math.sin(a)*c,vz:0,g:2,life:0,max:.4+this.rnd()*.3,size:.25+this.rnd()*.2,spin:0,fade:!0})}}leaves(e,t,n=14,s=["#7bd05a","#5cb840","#b8e986","#ffd84a"]){for(let r=0;r<n;r++){const o=new G(iS,new Be({color:s[r%s.length],side:Bt,transparent:!0}));o.position.set(e+(this.rnd()-.5)*.6,t+this.rnd()*.4,.4+(this.rnd()-.5)*.8);const a=Math.PI*(.15+this.rnd()*.7),c=2.5+this.rnd()*3.5;this.add(o,{vx:Math.cos(a)*c,vy:Math.sin(a)*c,vz:(this.rnd()-.5)*2,g:6,life:0,max:1+this.rnd()*.6,size:1+this.rnd()*.8,spin:(this.rnd()-.5)*12,fade:!0})}}splash(e,t){for(let n=0;n<22;n++){const s=this.sprite(n%3?"#bfe8ff":"#ffffff",!1);s.position.set(e+(this.rnd()-.5)*.6,t,.3);const r=Math.PI*(.25+this.rnd()*.5),o=3+this.rnd()*5;this.add(s,{vx:Math.cos(r)*o,vy:Math.sin(r)*o,vz:(this.rnd()-.5)*2,g:16,life:0,max:.8+this.rnd()*.4,size:.18+this.rnd()*.22,spin:0,fade:!0})}}magic(e,t,n){for(let s=0;s<26;s++){const r=this.sprite(["#fff6a8","#b8ffb0","#ffd0f0"][s%3],!0);r.position.set(e+(this.rnd()-.5)*1.2,t+this.rnd()*n,.3+(this.rnd()-.5)),this.add(r,{vx:(this.rnd()-.5)*.8,vy:.8+this.rnd()*1.5,vz:0,g:-.5,life:-this.rnd()*.6,max:.9+this.rnd()*.5,size:.2+this.rnd()*.25,spin:0,fade:!0})}}update(e){for(let t=this.ps.length-1;t>=0;t--){const n=this.ps[t];n.life+=e;const s=n.s;if(n.life<0){s.visible=!1;continue}s.visible=!0,n.vy-=n.g*e,s.position.x+=n.vx*e,s.position.y+=n.vy*e,s.position.z+=n.vz*e;const r=n.life/n.max;if(s.isSprite){const o=n.size*(.6+r*.8);s.scale.set(o,o,o),s.material.opacity=n.fade?1-r:1}else s.rotation.z+=n.spin*e,s.rotation.x+=n.spin*.5*e,s.scale.setScalar(n.size),n.vx*=1-e*1.5,s.material.opacity=Math.min(1,(1-r)*2);n.life>=n.max&&(this.root.remove(s),s.material.dispose(),this.ps.splice(t,1))}}clear(){for(const e of this.ps)this.root.remove(e.s),e.s.material.dispose();this.ps=[]}}const Hs=i=>1+(1.9+1)*(i-1)**3+1.9*(i-1)**2,Yt=i=>Math.max(0,Math.min(1,i)),Ho=(()=>{const i=new Pi;return i.moveTo(0,0),i.bezierCurveTo(.12,.08,.12,.24,0,.32),i.bezierCurveTo(-.12,.24,-.12,.08,0,0),new es(i,6)})();function Vo(i,e=.75){return new Be({color:i,roughness:e,side:Bt})}function Ks(i,e){i.traverse(t=>{var s;const n=t.material;!n||!n.color||((s=n.userData).base??(s.base=n.color.clone()),n.color.copy(n.userData.base).lerp(new Fe("#8a6a3a"),e*.7))})}function rS(){const i=new ze,e=[],t=new Be({color:"#c99662",map:ts("#b8854f"),roughness:.85}),n=Vo("#4d9a34"),s=13,r=qi/s;for(let c=0;c<s;c++){const l=new G(new li(r*.86,.14,1.5),t);l.position.set(r*(c+.5),-.08,0),l.rotation.y=c*37%7*.012-.03,l.castShadow=l.receiveShadow=!0,i.add(l),e.push(l)}const o=[];for(const c of[-.72,.72]){const l=[];for(let h=0;h<=20;h++){const d=qi*h/20;l.push(new R(d,.7-Math.sin(Math.PI*h/20)*.25,c))}const u=new G(new Ws(new Dr(l),40,.045,6),n);u.castShadow=!0,i.add(u),o.push(u);for(const h of[.1,qi-.1]){const d=new G(new mt(.07,.09,.95,8),t);d.position.set(h,.3,c),d.castShadow=!0,i.add(d)}for(let h=0;h<10;h++){const d=new G(Ho,n),f=.3+h*(qi/10);d.position.set(f,.7-Math.sin(Math.PI*f/qi)*.25,c),d.rotation.set(.4,0,h%2?2.3:-2.3),i.add(d)}}let a=0;return{kind:"bridge",root:i,grow(c){e.forEach((u,h)=>{const d=Yt(c*1.4-h/s*.9);u.scale.setScalar(Math.max(.001,Hs(d))),u.position.y=-.08+(1-d)*.4-a*(h/s)*1.6});const l=Yt((c-.45)/.55);i.children.forEach(u=>{e.includes(u)||u.scale.set(1,Math.max(.001,l),1)})},wilt(c){a=c,Ks(i,c),this.grow(1),i.rotation.z=-c*.08},poke(){},update(c,l){for(const u of o)u.position.y=Math.sin(l*2)*.02;i.position.y+=0}}}function oS(){const i=new ze,e=Vo("#3f9a37"),t=Vo("#79cf4f"),n=new Be({color:"#6b8f2f",roughness:.8}),s=[];for(const c of[-.45,.45]){const l=[];for(let h=0;h<=24;h++){const d=vi*h/24;l.push(new R(Math.sin(h*.9+c*3)*.08,d,c+Math.cos(h*.7)*.06))}const u=new G(new Ws(new Dr(l),60,.07,6),e);u.castShadow=!0,i.add(u),s.push({o:u,h:0})}for(let c=.45;c<vi;c+=.5){const l=new G(new mt(.045,.045,.95,6),n);l.rotation.x=Math.PI/2,l.position.set(0,c,0),i.add(l),s.push({o:l,h:c})}for(let c=0;c<26;c++){const l=.2+c/26*(vi-.2),u=new G(Ho,c%3?e:t);u.scale.setScalar(1.3+c%4*.2),u.position.set(.05,l,c%2?.5:-.5),u.rotation.set(c%2?.3:-.3,0,c%2?-1.2:1.2),i.add(u),s.push({o:u,h:l})}const r=new G(new Li(.18,.05,6,16,Math.PI*1.5),t);r.position.set(.1,vi+.1,0),i.add(r),s.push({o:r,h:vi});let o=0,a=0;return{kind:"vine",root:i,grow(c){o=c;const l=vi*Yt(c*1.15);for(const u of s){if(u.h===0){u.o.scale.set(1,Math.max(.001,Yt(c*1.15)),1);continue}const h=Yt((l-u.h)/.6);u.o.visible=h>0,u.o!==r&&h>0&&u.o.scale.setScalar((u.o.type==="Mesh"&&u.o.geometry===Ho?1.4:1)*Hs(h))}},wilt(c){Ks(i,c),a=c},poke(){},update(c,l){i.rotation.z=Math.sin(l*1.3)*.015*o-a*.5*Math.min(1,a*2)}}}function aS(){const i=new ze,e=new ze;i.add(e);const t=new Be({color:"#f6ead2",roughness:.7}),n=new Be({color:"#ff6b6b",roughness:.45}),s=new Be({color:"#fff8ec",roughness:.6}),r=new G(new mt(.22,.32,Io-.1,14),t);r.position.y=(Io-.1)/2,r.castShadow=!0,e.add(r);const o=new ze;o.position.y=Io-.12,e.add(o);const a=new G(new We(.62,28,14,0,Math.PI*2,0,Math.PI/2),n);a.scale.set(1,.62,1),a.castShadow=!0,o.add(a);const c=new G(new dn(.62,28),new Be({color:"#f1c7a8",side:Bt}));c.rotation.x=Math.PI/2,o.add(c);for(let h=0;h<7;h++){const d=h*2.4,f=h===0?0:.36+h%2*.1,g=new G(new We(.075+h%3*.02,10,8),s),_=Math.sqrt(Math.max(0,.62**2-f*f))*.62;g.position.set(Math.cos(d)*f,_,Math.sin(d)*f),g.scale.y=.4,o.add(g)}for(let h=0;h<6;h++){const d=new G(Ho,Vo("#5cb840"));d.position.set(Math.cos(h)*.3,0,Math.sin(h)*.3),d.rotation.set(-.3,h,(h%2?1:-1)*.4),i.add(d)}let l=0,u=0;return{kind:"mushroom",root:i,grow(h){u=h;const d=Math.max(.001,Hs(Yt(h)));e.scale.set(d,Math.max(.001,Hs(Yt(h*1.1))),d)},wilt(h){Ks(i,h),e.rotation.z=-h*.6},poke(){l=1},update(h,d){l=Math.max(0,l-h*3.5);const f=Math.sin(l*14)*l;u>=1&&e.scale.set(1+f*.35,1-f*.45,1+f*.35),o.rotation.y=d*.2}}}function Ef(i=1.6,e=.85){const t=new Pi;t.moveTo(0,0),t.bezierCurveTo(e,i*.2,e*1.05,i*.7,0,i),t.bezierCurveTo(-e*1.05,i*.7,-e,i*.2,0,0);const n=new es(t,16),s=n.attributes.position;for(let r=0;r<s.count;r++)s.setZ(r,-(Math.abs(s.getX(r))**2)*.35);return n.computeVertexNormals(),n}function cS(){const i=new ze,e=new Be({color:"#5fbf45",roughness:.6,side:Bt}),t=new Be({color:"#3f8f2f",roughness:.6}),n=new G(new mt(.05,.08,1.6,6),t);n.position.y=.8;const s=new ze;s.position.y=1.6;const r=new G(Ef(),e);r.rotation.x=-Math.PI/2+.7,r.position.set(0,0,.8),r.castShadow=!0;const o=new G(new mt(.025,.025,1.5,4),t);o.rotation.x=Math.PI/2-.25,o.position.set(0,.06,.78),s.add(r,o),i.add(n,s),i.rotation.y=-Math.PI/2+.6;let a=0;return{kind:"leaf",root:i,grow(c){a=c,n.scale.set(1,Math.max(.001,Yt(c*1.6)),1),n.position.y=.8*Yt(c*1.6),s.position.y=1.6*Yt(c*1.6);const l=Hs(Yt((c-.35)/.65));s.scale.setScalar(Math.max(.001,l)),s.rotation.z=(1-Yt(l))*1.2},wilt(c){Ks(i,c),s.rotation.x=c*.8},poke(){},update(c,l){a>=1&&(s.rotation.y=Math.sin(l*2)*.06)}}}function lS(){const i=new ze,e=new ze;i.add(e);const t=new Be({color:"#b98a5a",map:ts("#8b5a35"),roughness:.9}),n=new G(new mt(.32,.42,Do,14),t);n.position.y=Do/2,n.castShadow=n.receiveShadow=!0;const s=new G(new dn(.42,14),new Be({map:ta(),roughness:.9}));s.rotation.x=Math.PI/2,e.add(n,s);const r=new ze;r.position.y=Do-.4;const o=["#5cb840","#7bd05a","#4a9a35"].map(c=>new Be({color:c,roughness:.85}));for(let c=0;c<7;c++){const l=new G(new Zo(.7+c%3*.2,1),o[c%3]);l.position.set(Math.cos(c*2.1)*.6,c%3*.35,Math.sin(c*2.1)*.6),l.castShadow=!0,r.add(l)}e.add(r);let a=0;return{kind:"tree",root:i,grow(c){a=c;const l=Yt(c/.55);e.scale.set(1,Math.max(.001,Hs(l)),1);const u=Yt((c-.55)/.45);e.rotation.z=-(Math.PI/2)*u*u,e.position.y=-.4*u},wilt(c){Ks(i,c)},poke(){},update(c,l){a<.55&&(r.rotation.y=l)}}}function uS(){const i=new ze,e=new ze;i.add(e);const t=new Be({color:"#a8784a",map:ts("#7b5236"),roughness:.9}),n=(ff-.2)/2+.05,s=new G(new mt(n,n,pr,16),t);s.rotation.z=Math.PI/2,s.position.set(pr/2,.2+n,0),s.castShadow=s.receiveShadow=!0,e.add(s);const r=new Be({map:ta(),roughness:.9});for(const a of[0,pr]){const c=new G(new dn(n,16),r);c.rotation.y=a?Math.PI/2:-Math.PI/2,c.position.set(a,.2+n,0),e.add(c)}const o=new Be({color:"#6dbb4a"});for(let a=0;a<6;a++){const c=new G(new We(.16,8,6),o);c.scale.y=.4,c.position.set(.4+a*.65,.2+n*2,a%2*.2-.1),e.add(c)}for(const a of[.3,pr-.3]){const c=new G(new mt(.06,.08,.6,6),t);c.position.set(a,.1,.5),e.add(c)}return{kind:"log",root:i,grow(a){const c=Yt(a);e.position.y=(1-c)**2*6,e.scale.setScalar(Math.max(.001,Yt(a*3)))},wilt(a){Ks(i,a),e.rotation.z=-a*.3},poke(){},update(){}}}function hS(i){return i==="bridge"?rS():i==="vine"?oS():i==="leaf"?cS():i==="tree"?lS():i==="log"?uS():aS()}const Xh=[{stage:{skyTop:"#6db9ec",skyBottom:"#fdf3d0",fog:"#dff0e4",hills:["#8fcf72","#a7d68e","#b9dbc0","#cfe3e6"],sun:"#fff1c9",ambientSky:"#dff3ff",ambientGround:"#6f8f4a",fogNear:45,fogFar:230,rays:.22},grass:"#86cf5c",grassDark:"#5fae47",soil:["#9a6a43","#6f4a2e","#b98457"],meadow:"#8ccf6a",water:"#59b8e6",waterFront:"#2f7fb0",near:[{name:"CommonTree_1"}],far:[{name:"Pine_3"},{name:"Pine_5"}],flowers:1,shrooms:.3,giantShrooms:!1,mist:!1,thorn:"#5a3d58",ambient:{color:"#fff7c2",size:.22,count:90,fall:0,flicker:!1}},{stage:{skyTop:"#5f9fb8",skyBottom:"#e6efd2",fog:"#a9c9b4",hills:["#4f8f4a","#5f9a5a","#7fae8a","#a3c4b4"],sun:"#fff0c0",ambientSky:"#cfe8dc",ambientGround:"#3f5f34",fogNear:30,fogFar:160,rays:.42},grass:"#6fbf55",grassDark:"#4a9a3f",soil:["#7e5636","#573a22","#9a6a43"],meadow:"#5f9a4a",water:"#4aa8c8",waterFront:"#2a6f90",near:[{name:"Pine_1"},{name:"CommonTree_1",tint:"#4f9a3a"},{name:"Pine_3"}],far:[{name:"Pine_3"},{name:"Pine_5"},{name:"Pine_1"}],flowers:.4,shrooms:1,giantShrooms:!1,mist:!1,thorn:"#4a3550",ambient:{color:"#fff3b0",size:.18,count:70,fall:0,flicker:!1}},{stage:{skyTop:"#a796e6",skyBottom:"#ffe1ee",fog:"#efd9ef",hills:["#8fcfa8","#a8b9e0","#c7b2e3","#e4cfee"],sun:"#ffe6f2",ambientSky:"#f3e6ff",ambientGround:"#6a7f5a",fogNear:40,fogFar:210,rays:.25},grass:"#8fd69a",grassDark:"#62b578",soil:["#a0634f","#74443a","#bd8068"],meadow:"#93cfa2",water:"#6fc0e8",waterFront:"#3a7fb8",near:[{name:"CommonTree_1",tint:"#a88ae0"},{name:"CommonTree_1",tint:"#6fc0a0"}],far:[{name:"Pine_5",tint:"#7fa8c8"}],flowers:.8,shrooms:2.5,giantShrooms:!0,mist:!1,thorn:"#6a3d6e",ambient:{color:"#ffc2f0",size:.2,count:80,fall:-.05,flicker:!0}},{stage:{skyTop:"#7fb2de",skyBottom:"#ffe2b8",fog:"#f2dcbc",hills:["#c99a4a","#d6a865","#d9bf98","#e6d5c0"],sun:"#ffd9a0",ambientSky:"#ffeccf",ambientGround:"#7a5a2f",fogNear:40,fogFar:210,rays:.3},grass:"#c6b85a",grassDark:"#9a9a3f",soil:["#8a5a36","#5f3c22","#a8724a"],meadow:"#c9a85a",water:"#5aa8d0",waterFront:"#2f6f98",near:[{name:"CommonTree_1",tint:"#e8862e"},{name:"CommonTree_1",tint:"#d9502e"},{name:"CommonTree_1",tint:"#e8b22e"}],far:[{name:"Pine_3"},{name:"Pine_5"}],flowers:.2,shrooms:1.2,giantShrooms:!1,mist:!1,thorn:"#5a3a2e",ambient:{color:"#f08a3a",size:.32,count:70,fall:.6,flicker:!1}},{stage:{skyTop:"#6f8d9c",skyBottom:"#cdd8cc",fog:"#aebfb4",hills:["#5f7f5a","#6f8a72","#8a9f94","#a8b8b0"],sun:"#e6f0d8",ambientSky:"#c8d8d0",ambientGround:"#3f4a34",fogNear:18,fogFar:110,rays:.12},grass:"#759e5a",grassDark:"#4f7a42",soil:["#5f4a36","#3f3022","#7a6046"],meadow:"#5f7f52",water:"#5f9a82",waterFront:"#2f5f4f",near:[{name:"DeadTree_1"},{name:"Pine_1",tint:"#5f7f52"}],far:[{name:"DeadTree_1"},{name:"Pine_5",tint:"#6f8a7a"}],flowers:.1,shrooms:1.5,giantShrooms:!1,mist:!0,thorn:"#3f3546",ambient:{color:"#e8ff7a",size:.26,count:70,fall:0,flicker:!0}}],Tf=i=>Xh[Math.max(0,Math.min(Xh.length-1,i-1))],Af="sprout-trail-save",Go=()=>({v:1,levels:{},gems:0,last:null,music:!0,sfx:!0,lang:null,hat:"none",color:"leaf",owned:[],dailyDay:-1,streak:0,bestStreak:0});let Zc=null,De=Go();function dS(){return null}function fS(i=null){Zc=i??dS();try{const e=Zc?.getItem(Af);e&&(De={...Go(),...JSON.parse(e)})}catch{De=Go()}return De}function Ri(){try{Zc?.setItem(Af,JSON.stringify(De))}catch{}}function pS(i,e,t){const n=De.levels[i];De.levels[i]={stars:Math.max(n?.stars??0,e.stars),acorns:Math.max(n?.acorns??0,e.acorns),gems:Math.max(n?.gems??0,e.gems),done:!0},De.gems+=t,i.startsWith("daily")||(De.last=i),Ri()}const Jc=(i=Date.now())=>Math.floor((i-Date.UTC(2026,0,1))/864e5);function mS(i){De.dailyDay!==i&&(De.streak=De.dailyDay===i-1?De.streak+1:1,De.bestStreak=Math.max(De.bestStreak,De.streak),De.dailyDay=i,Ri())}const Rf=i=>De.dailyDay>=i-1?De.streak:0;function gS(){const i={music:De.music,sfx:De.sfx,lang:De.lang};De={...Go(),...i},Ri()}const qh=[{id:"none",kind:"hat",price:0},{id:"acorn",kind:"hat",price:150},{id:"flower",kind:"hat",price:300},{id:"bow",kind:"hat",price:450},{id:"mushroom",kind:"hat",price:650},{id:"straw",kind:"hat",price:900},{id:"crown",kind:"hat",price:1500}],Wo=[{id:"leaf",kind:"color",price:0,value:"#9fd66b"},{id:"sun",kind:"color",price:120,value:"#f6d75a"},{id:"sky",kind:"color",price:250,value:"#8fd0f2"},{id:"blossom",kind:"color",price:400,value:"#f6a8c8"},{id:"lavender",kind:"color",price:600,value:"#b9a2ee"},{id:"autumn",kind:"color",price:800,value:"#f2a25a"},{id:"moss",kind:"color",price:1100,value:"#5fae6a"}],$h={get hat(){return De.hat??"none"},get color(){return Wo.find(i=>i.id===(De.color??"leaf"))?.value??Wo[0].value}},Cf=i=>i.price===0||De.owned.includes(i.id),_S=i=>i.kind==="hat"?(De.hat??"none")===i.id:(De.color??"leaf")===i.id;function xS(i){let e="equipped";if(!Cf(i)){if(De.gems<i.price)return"poor";De.gems-=i.price,De.owned.push(i.id),e="bought"}return i.kind==="hat"?De.hat=i.id:De.color=i.id,Ri(),e}function Yh(i,e){const t=new Pi;return t.moveTo(0,0),t.bezierCurveTo(e,i*.25,e*.9,i*.75,0,i),t.bezierCurveTo(-e*.9,i*.75,-e,i*.25,0,0),new es(t,10)}class vS{constructor(e="#9fd66b"){te(this,"root",new ze);te(this,"body",new ze);te(this,"head",new ze);te(this,"sprout",new ze);te(this,"leafL");te(this,"leafR");te(this,"armL");te(this,"armR");te(this,"footL");te(this,"footR");te(this,"eyes",[]);te(this,"stars",new ze);te(this,"skin");te(this,"blinkAt",2);te(this,"shadow");te(this,"hat",new ze);te(this,"glideLeaf",null);this.skin=new Be({color:e,roughness:.65});const t=new Be({color:"#f4efcf",roughness:.75}),n=new Be({color:"#2b2118",roughness:.3}),s=new Dt({color:"#ffffff"}),r=new Dt({color:"#ff9e9e",transparent:!0,opacity:.75}),o=new Be({color:"#5cbf3f",roughness:.6,side:Bt}),a=new Be({color:"#8b5a35",roughness:.8});this.root.add(this.body),this.body.rotation.y=.75;const c=new G(new We(.44,32,24),this.skin);c.scale.set(1,1.04,.96),c.position.y=.56,c.castShadow=!0,this.body.add(c);const l=new G(new We(.3,24,16),t);l.scale.set(.95,.95,.5),l.position.set(0,.46,.28),this.body.add(l),this.head.position.set(0,.62,0),this.body.add(this.head);for(const m of[-1,1]){const p=new ze;p.position.set(m*.15,.06,.38);const M=new G(new We(.085,16,12),n);M.scale.set(.9,1.15,.6);const v=new G(new We(.03,8,6),s);v.position.set(.025,.04,.045);const x=new G(new We(.014,8,6),s);x.position.set(-.02,-.03,.05),p.add(M,v,x),this.head.add(p),this.eyes.push(p);const I=new G(new dn(.07,16),r);I.position.set(m*.26,-.08,.36),I.rotation.y=m*.55,this.head.add(I)}const u=new G(new Li(.045,.014,6,12,Math.PI),n);u.rotation.z=Math.PI,u.position.set(0,-.08,.42),this.head.add(u),this.sprout.position.set(0,.98,-.02),this.body.add(this.sprout);const h=new Dr([new R(0,-.05,0),new R(.02,.1,0),new R(-.02,.2,0)]),d=new G(new Ws(h,8,.025,6),o);this.sprout.add(d),this.leafL=new G(Yh(.32,.13),o),this.leafL.position.set(-.02,.19,0),this.leafL.rotation.z=.95,this.leafR=new G(Yh(.27,.11),o),this.leafR.position.set(-.02,.19,0),this.leafR.rotation.z=-.85,this.leafL.castShadow=this.leafR.castShadow=!0,this.sprout.add(this.leafL,this.leafR);const f=m=>{const p=new ze;p.position.set(m*.4,.55,.02);const M=new G(new Er(.065,.16,4,8),this.skin);return M.position.y=-.11,M.castShadow=!0,p.add(M),this.body.add(p),p};this.armL=f(-1),this.armR=f(1);const g=m=>{const p=new G(new We(.12,12,10),a);return p.scale.set(1,.7,1.35),p.position.set(m*.17,.08,.04),p.castShadow=!0,this.body.add(p),p};this.footL=g(-1),this.footR=g(1);const _=new Dt({color:"#ffe066"});for(let m=0;m<3;m++){const p=new G(new Jo(.07),_);this.stars.add(p)}this.stars.position.y=1.25,this.stars.visible=!1,this.root.add(this.stars),this.shadow=new G(new dn(.42,24),new Dt({color:"#203010",transparent:!0,opacity:.28,depthWrite:!1})),this.shadow.rotation.x=-Math.PI/2,this.shadow.renderOrder=1}setColor(e){this.skin.color.set(e)}setHat(e){this.body.remove(this.hat),this.hat=yS(e),this.hat.position.set(0,.92,0),this.body.add(this.hat)}setGlide(e,t){e&&!this.glideLeaf&&t?(this.glideLeaf=t,t.position.set(.05,1.55,0),this.root.add(t)):!e&&this.glideLeaf&&(this.root.remove(this.glideLeaf),this.glideLeaf=null)}update(e){const t=e.t,n=e.grounded&&!e.idle&&!e.climbing,s=Math.sin(e.phase);let r=1,o=1;if(e.ducking)r=.55,o=1.3;else if(!e.grounded&&!e.climbing){const c=gl.clamp(e.vy/12,-1,1);r=1+.16*c,o=1-.09*c}if(r-=e.squash*.28,o+=e.squash*.2,this.body.scale.set(o,r,o),this.body.position.y=n&&!e.ducking?Math.abs(s)*.07:e.idle?Math.sin(t*3)*.012:0,e.cheer&&(this.body.position.y=Math.abs(Math.sin(t*7))*.35),this.body.rotation.z=n?-.12-Math.min(.1,e.speed*.01):!e.grounded&&!e.climbing?-.05:0,this.body.rotation.x=0,e.climbing){const c=Math.sin(t*12);this.armL.rotation.set(0,0,2.6+c*.35),this.armR.rotation.set(0,0,-2.6+c*.35),this.footL.position.set(-.17,.08+Math.max(0,c)*.12,.04),this.footR.position.set(.17,.08+Math.max(0,-c)*.12,.04),this.body.rotation.y=.75-.9}else if(this.body.rotation.y=e.idle?.55+Math.sin(t*.7)*.1:.75,n)this.armL.rotation.set(s*.9,0,.25),this.armR.rotation.set(-s*.9,0,-.25),this.footL.position.set(-.17,.08+Math.max(0,s)*.14,.04+s*.16),this.footR.position.set(.17,.08+Math.max(0,-s)*.14,.04-s*.16);else if(e.grounded){const c=e.cheer?Math.sin(t*14)*.4:0;this.armL.rotation.set(0,0,e.cheer?2.6+c:.2+Math.sin(t*2)*.05),this.armR.rotation.set(0,0,e.cheer?-2.6-c:-.2-Math.sin(t*2)*.05),this.footL.position.set(-.17,.08,.04),this.footR.position.set(.17,.08,.04)}else{const c=e.vy>0?1:.4;this.armL.rotation.set(0,0,.6+1.6*c),this.armR.rotation.set(0,0,-.6-1.6*c),this.footL.position.set(-.17,.16,.08),this.footR.position.set(.17,.12,-.06)}const a=Math.sin(t*9)*(n?.12:.05)+(e.grounded?0:-e.vy*.025);if(this.leafL.rotation.z=.95+a,this.leafR.rotation.z=-.85+a*.8,this.sprout.rotation.z=n?.25:.05*Math.sin(t*1.5),t>this.blinkAt){const c=t-this.blinkAt,l=c<.12?.1:1;for(const u of this.eyes)u.scale.y=l;c>.12&&(this.blinkAt=t+2+t*7.7%2.5)}for(const c of this.eyes)c.position.y=e.dizzy?.06+Math.sin(t*10)*.01:.06;this.skin.emissive.set(e.hurt&&Math.floor(t*12)%2===0?"#ff5a3c":"#000000"),this.skin.emissiveIntensity=.6,this.stars.visible=e.dizzy,e.dizzy&&this.stars.children.forEach((c,l)=>{const u=t*5+l*Math.PI*2/3;c.position.set(Math.cos(u)*.35,Math.sin(u*2)*.05,Math.sin(u)*.35),c.rotation.y=t*6})}}const un=(i,e={})=>new Be({color:i,roughness:.6,...e});function yS(i){const e=new ze,t=n=>(n.castShadow=!0,e.add(n),n);switch(i){case"acorn":{const n=t(new G(new We(.36,20,10,0,Math.PI*2,0,Math.PI/2),un("#9a6a3a",{roughness:.9})));n.scale.y=.6,n.position.y=-.06,t(new G(new mt(.04,.05,.16,6),un("#5a3a20"))).position.set(.12,.18,0);break}case"flower":{t(new G(new We(.09,10,8),un("#ffd23a"))).position.set(.22,.02,.12);for(let s=0;s<6;s++){const r=t(new G(new We(.08,8,6),un("#ff8fc0"))),o=s/6*Math.PI*2;r.position.set(.22+Math.cos(o)*.12,.02+Math.sin(o)*.12,.1),r.scale.z=.4}break}case"mushroom":{const n=t(new G(new We(.34,20,10,0,Math.PI*2,0,Math.PI/2),un("#ff6b6b",{roughness:.45})));n.scale.y=.7;for(let s=0;s<5;s++){const r=t(new G(new We(.05,8,6),un("#fff8ec"))),o=s*1.3;r.position.set(Math.cos(o)*.2,.16,Math.sin(o)*.2),r.scale.y=.4}break}case"crown":{const n=t(new G(new Li(.28,.05,6,20),un("#5cb840")));n.rotation.x=Math.PI/2,n.position.y=-.04;for(let s=0;s<7;s++){const r=t(new G(new ai(.07,.24,4),un(s%2?"#7bd05a":"#ffd23a",{metalness:s%2?0:.4}))),o=s/7*Math.PI*2;r.position.set(Math.cos(o)*.28,.08,Math.sin(o)*.28)}break}case"straw":{const n=t(new G(new mt(.5,.52,.04,24),un("#f0cf7a",{roughness:.9})));n.position.y=-.02;const s=t(new G(new mt(.24,.28,.2,18),un("#f0cf7a",{roughness:.9})));s.position.y=.09;const r=t(new G(new mt(.285,.285,.06,18),un("#e0566a")));r.position.y=.02;break}case"bow":{for(const s of[-1,1]){const r=t(new G(new ai(.12,.22,4),un("#7fb8ff")));r.rotation.z=s*Math.PI/2,r.position.set(s*.12,0,.18)}t(new G(new We(.06,8,6),un("#5a8fe0"))).position.set(0,0,.2),e.position.x=.15;break}}return e}const rt=(i,e={})=>new Be({color:i,roughness:.7,...e}),Pf=new Jo(.26,0);Pf.scale(1,1.35,1);const MS=rt("#5fd8ff",{roughness:.15,metalness:.1,emissive:"#1a9ad0",emissiveIntensity:.55,flatShading:!0});function SS(){const i=new ze,e=rt("#ffc83d",{roughness:.3,metalness:.35,emissive:"#b36b00",emissiveIntensity:.35}),t=rt("#c58a2a",{roughness:.6,metalness:.2,emissive:"#5a3500",emissiveIntensity:.25}),n=new G(new We(.26,20,16),e);n.scale.set(1,1.15,1),n.position.y=-.06;const s=new G(new ai(.08,.14,10),e);s.rotation.x=Math.PI,s.position.y=-.36;const r=new G(new We(.29,20,10,0,Math.PI*2,0,Math.PI/2),t);r.scale.set(1,.55,1),r.position.y=.08;const o=new G(new mt(.03,.04,.14,6),t);o.position.set(.02,.27,0),o.rotation.z=-.3;const a=new Vd(new Ml({map:Dl(),color:"#ffe48a",transparent:!0,opacity:.75,depthWrite:!1,blending:Cs}));a.scale.setScalar(1.5),i.add(a,n,s,r,o);for(const c of[n,s,r])c.castShadow=!0;return i}function wS(){const i=new ze,e=new ze;i.add(e);const t=new G(new We(.42,22,14,0,Math.PI*2,0,Math.PI/2),rt("#7a5cd6",{roughness:.35}));t.scale.set(1.15,.85,.95),t.position.y=.16,t.castShadow=!0;const n=new G(new li(.03,.36,.02),rt("#3d2a7a"));n.position.set(-.05,.32,.39);const s=rt("#f7d24a");for(const[u,h]of[[-.18,.3],[.16,.3],[0,.42],[-.22,-.15],[.2,-.15]]){const d=new G(new We(.07,8,6),s);d.position.set(u,.36+(h>.35?-.12:0),h*.8),d.scale.y=.5,e.add(d)}const r=new G(new We(.2,16,12),rt("#3a2c4a"));r.position.set(.42,.22,0),r.castShadow=!0;const o=new Dt({color:"#ffffff"}),a=new Dt({color:"#1a1020"});for(const u of[-.09,.09]){const h=new G(new We(.07,10,8),o);h.position.set(.56,.3,u+.04);const d=new G(new We(.035,8,6),a);d.position.set(.62,.3,u+.07),e.add(h,d);const f=new G(new mt(.012,.012,.25,4),rt("#3a2c4a"));f.position.set(.5,.48,u),f.rotation.z=-.5,e.add(f)}e.add(t,n,r);const c=[],l=rt("#3a2c4a");for(let u=0;u<6;u++){const h=new G(new mt(.025,.02,.22,4),l);h.position.set(-.22+u%3*.22,.08,u<3?.3:-.3),h.rotation.x=u<3?.6:-.6,e.add(h),c.push(h)}return{root:i,update(u,h){e.rotation.y=h>0?-.5:Math.PI+.5,e.position.y=Math.abs(Math.sin(u*10))*.04,c.forEach((d,f)=>d.rotation.z=Math.sin(u*14+f*2)*.5)}}}function bS(i){const e=new ze,t=rt("#8b5a35",{map:ts("#8b5a35")}),n=new G(new mt(.09,.11,1.9,8),t);n.position.set(0,.95,-.14),n.castShadow=!0;const s=new G(new li(2.4,1.2,.12),rt("#a87346"));s.position.y=1.75,s.castShadow=!0;const r=new G(new kn(2.36,1.18),new Be({map:dM(i),roughness:.9}));return r.position.set(0,1.75,.065),e.add(n,s,r),e.rotation.y=.12,e}function ES(){const i=new ze,e=new G(new mt(.05,.07,1.6,6),rt("#4f9e3a"));e.position.y=.8,i.add(e);const t=new ze;t.position.y=1.65,i.add(t);const n=[],s=rt("#ffd1e8",{emissive:"#ff8cc6",emissiveIntensity:.15});for(let a=0;a<8;a++){const c=new G(new We(.2,10,8),s);c.scale.set(1,.35,.55);const l=a/8*Math.PI*2;c.userData.a=l,t.add(c),n.push(c)}const r=new G(new We(.13,12,10),rt("#ffcf3d",{emissive:"#ffb000",emissiveIntensity:.3}));t.add(r);for(const a of[-1,1]){const c=new G(new We(.2,8,6),rt("#5cb840"));c.scale.set(1,.25,.5),c.position.set(a*.2,.6,0),c.rotation.z=a*.5,i.add(c)}const o=a=>{n.forEach(c=>{const l=c.userData.a,u=.05+.22*a;c.position.set(Math.cos(l)*u,Math.sin(l)*u,.02),c.rotation.set(0,0,l),c.scale.set(.5+.5*a,.35,.55)}),s.color.set(a>.5?"#ff9ccf":"#ffd1e8"),r.scale.setScalar(.6+.4*a)};return o(0),i.traverse(a=>a.castShadow=!0),{root:i,open:o}}function TS(){const i=new ze,e=rt("#8b5a35",{map:ts("#9a6640")}),t=new G(new mt(1.5,1.8,3.2,20),e);t.position.set(1.6,1.6,-1.6);const n=new G(new dn(1.5,20),rt("#d9a86c",{map:ta()}));n.rotation.x=-Math.PI/2,n.position.set(1.6,3.21,-1.6);const s=new G(new We(1.7,20,12,0,Math.PI*2,0,Math.PI/2),rt("#ff7a6b",{roughness:.5}));s.scale.set(1,.7,1),s.position.set(1.6,3.15,-1.6);const r=rt("#fff6ea");for(let d=0;d<6;d++){const f=new G(new We(.2,8,6),r),g=d*1.1;f.position.set(1.6+Math.cos(g)*1.1,3.75-d%2*.2,-1.6+Math.sin(g)*1.1),f.scale.y=.4,i.add(f)}const o=new G(new dn(.6,20),rt("#5a3a22"));o.position.set(1,1,-.15),o.rotation.y=-.35;const a=new G(new We(.06,8,6),rt("#ffd34d",{metalness:.5}));a.position.set(1.25,.95,-.05);const c=new G(new dn(.3,16),rt("#ffe9a8",{emissive:"#ffcc66",emissiveIntensity:.8}));c.position.set(2.3,2.1,-.25),c.rotation.y=.3,i.add(t,n,s,o,a,c);const l=rt("#5aa83c"),u=new G(new Li(1.6,.1,8,30,Math.PI),l);u.position.set(-.6,0,.3),i.add(u);const h=["#ffd84a","#ff8fb8","#ffffff","#b38bff"];for(let d=0;d<=14;d++){const f=d/14*Math.PI,g=new G(new We(.14,8,6),rt(h[d%4],{emissive:h[d%4],emissiveIntensity:.15}));g.position.set(-.6+Math.cos(f)*1.6,Math.sin(f)*1.6,.35),i.add(g)}return i.traverse(d=>d.castShadow=!0),i}function AS(){const i=new ze,e=new ze;i.add(e);const t=rt("#c9d88a",{roughness:.5}),n=new G(new Er(.16,.7,6,12),t);n.rotation.z=Math.PI/2,n.position.set(0,.14,0),n.castShadow=!0;const s=new G(new Er(.13,.25,4,10),t);s.position.set(.42,.33,0),s.rotation.z=-.4;const r=rt("#b5653a",{roughness:.45}),o=new G(new Cl(.22,.12,64,10,1,3),r);o.scale.set(1,1,.75),o.position.set(-.08,.5,0),o.castShadow=!0;const a=new G(new We(.33,18,14),rt("#d4874e",{roughness:.5}));a.position.copy(o.position),a.scale.set(1,1,.7);const c=rt("#f3e6c8",{roughness:.4});for(let u=0;u<7;u++){const h=u/7*Math.PI*1.4-.1,d=new G(new ai(.06,.24,6),c);d.position.set(-.08+Math.cos(h)*.36,.5+Math.sin(h)*.36,0),d.rotation.z=h-Math.PI/2,e.add(d)}const l=rt("#2b2118");for(const u of[-.07,.07]){const h=new G(new mt(.02,.025,.28,5),t);h.position.set(.52,.58,u),h.rotation.z=-.3;const d=new G(new We(.05,8,6),l);d.position.set(.57,.72,u),e.add(h,d)}return e.add(n,s,a,o),{root:i,update(u,h){e.rotation.y=h>0?-.5:Math.PI+.5,n.scale.x=1+Math.sin(u*6)*.06}}}function RS(){const i=new ze,e=new ze;e.position.y=.3,i.add(e);const t=rt("#ffd23a",{roughness:.4}),n=rt("#3a2c22",{roughness:.5}),s=new G(new We(.3,20,14),t);s.scale.set(1.25,.95,.95),s.castShadow=!0,e.add(s);for(const u of[-.12,.08]){const h=new G(new Li(.27,.055,6,20),n);h.rotation.y=Math.PI/2,h.position.x=u,h.scale.set(1,.98,1),e.add(h)}const r=new G(new ai(.06,.18,6),n);r.rotation.z=Math.PI/2,r.position.x=-.42,e.add(r);const o=new G(new We(.17,12,10),n);o.position.x=.36,e.add(o);const a=new Dt({color:"#ffffff"});for(const u of[-.08,.08]){const h=new G(new We(.05,8,6),a);h.position.set(.47,.05,u),e.add(h)}const c=new Be({color:"#e8f6ff",transparent:!0,opacity:.7,side:Bt}),l=[];for(const u of[-1,1]){const h=new G(new dn(.22,14),c);h.scale.set(1.3,.7,1),h.position.set(0,.28,u*.12),e.add(h),l.push(h)}return{root:i,update(u,h){e.rotation.y=h>0?-.4:Math.PI+.4,l.forEach((d,f)=>d.rotation.x=Math.PI/2+(f?1:-1)*(.6+Math.sin(u*60)*.5)),e.rotation.z=Math.sin(u*3)*.1}}}function CS(){const i=new ze,e=new ze;e.position.y=.4,i.add(e);const t=new G(new We(.4,20,16),rt("#b7743a",{roughness:.45}));t.castShadow=!0;const n=new G(new We(.42,18,10,0,Math.PI*2,0,Math.PI/2.2),rt("#6e4a2a",{roughness:.8,map:ts("#6e4a2a")}));n.position.y=.06;const s=new G(new mt(.04,.05,.16,6),rt("#5a3a20"));s.position.y=.48;const r=new G(new Li(.4,.03,6,24),rt("#d9a060"));r.rotation.y=Math.PI/2,e.add(t,n,s,r);const o=new ze;o.position.y=.4;const a=new Dt({color:"#ffffff"}),c=new Dt({color:"#2b2118"});for(const l of[-.13,.13]){const u=new G(new We(.08,8,6),a);u.position.set(-.3,.05,l+.12);const h=new G(new We(.04,6,5),c);h.position.set(-.36,.05,l+.15);const d=new G(new li(.14,.03,.03),c);d.position.set(-.33,.15,l+.13),d.rotation.x=l>0?.4:-.4,o.add(u,h,d)}return i.add(o),{root:i,update(l,u,h){e.rotation.z=h/.4}}}const Lf=()=>typeof matchMedia<"u"&&matchMedia("(pointer: coarse)").matches,If=i=>nS(`${i}.touch`)?$t(`${i}.${Lf()?"touch":"keys"}`):$t(i),Ot=-2.4,Pn=1.25;function Df(i){let e=i>>>0||1;return()=>(e=e*1664525+1013904223>>>0,e/4294967296)}function Mo(i,e,t,n,s,r,o=.25){const a=[],c=[],l=[],u=[],h=(f,g,_,m,p,M)=>{const v=a.length/3;for(const x of[f,g,_,m])a.push(...x),l.push(...p),c.push(...M(x).map(I=>I*o));u.push(v,v+1,v+2,v,v+2,v+3)};h([i,t,r],[e,t,r],[e,n,r],[i,n,r],[0,0,1],f=>[f[0],f[1]]),h([i,t,s],[i,t,r],[i,n,r],[i,n,s],[-1,0,0],f=>[f[2],f[1]]),h([e,t,r],[e,t,s],[e,n,s],[e,n,r],[1,0,0],f=>[-f[2],f[1]]),h([i,n,r],[e,n,r],[e,n,s],[i,n,s],[0,1,0],f=>[f[0],f[2]]);const d=new Tt;return d.setAttribute("position",new Ze(a,3)),d.setAttribute("normal",new Ze(l,3)),d.setAttribute("uv",new Ze(c,2)),d.setIndex(u),d}function So(i,e,t,n,s,r=.32,o=1){const a=Df(o),c=new Pi,l=.1;c.moveTo(i-l,t+.07),c.lineTo(e+l,t+.07),c.lineTo(e+l,t-r*.6);const u=Math.max(2,Math.round((e-i)/.75)),h=(e-i+2*l)/u;for(let f=u-1;f>=0;f--){const g=i-l+f*h,_=r*(.75+a()*.5);c.quadraticCurveTo(g+h/2,t-_-r*.5,g,t-r*.6)}c.lineTo(i-l,t+.07);const d=new Rl(c,{depth:s-n,bevelEnabled:!0,bevelThickness:.06,bevelSize:.05,bevelSegments:2,curveSegments:4});return d.translate(0,0,n),d}function PS(i){const e=new ze,t=Df(i.seed*7919),n=Tf(i.world),s=new Be({map:$a(...n.soil),roughness:.95}),r=new Be({map:$a("#9c9184","#6f665c","#bdb3a4"),roughness:.95}),o=new Be({color:n.grass,roughness:.85}),a=new Be({color:"#a8a092",roughness:.95,flatShading:!0}),c=new Be({map:$a("#5e3f27","#3f2918","#6f4a2e"),roughness:1}),l=new Be({color:n.grassDark,roughness:.9}),u=new Be({map:ts(),roughness:.9}),h=new Be({map:ta(),roughness:.9}),d=[],f=(L,S,y=!0)=>{const N=new G(L,S);return N.castShadow=y,N.receiveShadow=!0,e.add(N),N};for(const L of i.boxes)if(L.kind==="ground"||L.kind==="wall"){const S=Math.max(L.y0,L.y1-30);if(f(Mo(L.x0,L.x1,S,L.y1,Ot,Pn),s,L.kind==="wall"),L.kind==="wall")for(let y=L.y0+.6;y<L.y1-.4;y+=1.1){const N=new G(new jo(.45+t()*.2,0),a);N.position.set(L.x0+.1+t()*.3,y,Pn-.2-t()*.8),N.rotation.set(t()*3,t()*3,0),N.castShadow=!0,e.add(N)}f(So(L.x0,L.x1,L.y1,Ot,Pn,.32,Math.round(L.x0*10)),o),f(So(L.x0+.05,L.x1-.05,L.y1-.12,Ot+.02,Pn+.03,.28,Math.round(L.x0*13)),l,!1),d.push({x0:L.x0,x1:L.x1,y:L.y1})}else L.kind==="stump"?LS(e,L,u,h):L.kind==="log"?IS(e,L,u,h):L.kind==="ledge"&&(f(Mo(L.x0+.1,L.x1-.1,L.y0,L.y1-.05,-1.1,.9),r),f(So(L.x0,L.x1,L.y1,-1.15,.95,.22,Math.round(L.x0*10)),o),d.push({x0:L.x0,x1:L.x1,y:L.y1}));const g=i.boxes.filter(L=>L.kind==="ground"||L.kind==="wall").sort((L,S)=>L.x0-S.x0);for(let L=0;L+1<g.length;L++){const S=g[L],y=g[L+1];if(y.x0-S.x1<.5||i.water.some(B=>B.x0<y.x0&&B.x1>S.x1))continue;const N=Math.min(S.y1,y.y1)-.6;f(Mo(S.x1-.05,y.x0+.05,N-30,N,Ot-.4,Ot+.05),c,!1),f(So(S.x1,y.x0,N,Ot-.4,Ot+.05,.25,Math.round(S.x1*10)),l,!1)}const _=new G(new kn(i.goalX+200,60),new Be({color:n.meadow,roughness:1}));_.rotation.x=-Math.PI/2,_.position.set(i.goalX/2,-3.2,-33),_.receiveShadow=!0,e.add(_);const m=new Be({color:n.water,roughness:.15,metalness:.05,transparent:!0,opacity:.85});m.onBeforeCompile=L=>{L.uniforms.uT=jh,L.vertexShader=L.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vW;`).replace("#include <worldpos_vertex>",`#include <worldpos_vertex>
vW = (modelMatrix * vec4(transformed,1.0)).xyz;`),L.fragmentShader=L.fragmentShader.replace("#include <common>",`#include <common>
uniform float uT; varying vec3 vW;`).replace("#include <color_fragment>",`#include <color_fragment>
        float rip = sin(vW.x * 3.0 + uT * 2.0) * sin(vW.z * 4.0 - uT * 1.3);
        diffuseColor.rgb += vec3(0.12, 0.16, 0.18) * smoothstep(0.55, 0.95, rip);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.86, 0.95, 1.0), smoothstep(0.75, 1.0, abs(vW.z + 0.6) / 1.9) * 0.4);`)};for(const L of i.water){const S=new G(new kn(L.x1-L.x0+.4,Pn-Ot,24,4),m);S.rotation.x=-Math.PI/2,S.position.set((L.x0+L.x1)/2,L.y,(Ot+Pn)/2),e.add(S);const y=new G(new kn(L.x1-L.x0+.4,1.2),new Dt({color:n.waterFront,transparent:!0,opacity:.75}));y.position.set((L.x0+L.x1)/2,L.y-.6,Pn),e.add(y);const N=new G(Mo(L.x0-.2,L.x1+.2,L.y-30,L.y-1.2,Ot,Pn-.05),s);e.add(N);for(const B of[L.x0+.3,L.x1-.3])for(let K=0;K<4;K++){const $=new G(new mt(.02,.03,1.2+t()*.6,4),l);$.position.set(B+(t()-.5)*.6,L.y+.5,Ot+.4+t()*.8),$.rotation.z=(t()-.5)*.3,e.add($)}}const p=new Be({color:n.thorn,roughness:.7}),M=new Be({color:"#efe1c6",roughness:.5}),v=new Be({color:"#d63b5a",roughness:.3}),x=new Be({color:"#3f6e35",roughness:.8}),I=new ai(.05,.22,5);for(const L of i.hazards){const S=[],y=L.x1-L.x0,N=Math.max(6,Math.round(y*3.6));for(let K=0;K<N;K++){const $=L.x0+.15+(K+t()*.6)/N*(y-.3),Ee=-1.6+t()*2.6,de=L.y1*(.7+t()*.5),Se=[new R($,L.y0-.1,Ee),new R($+(t()-.5)*.5,L.y0+de*.5,Ee+(t()-.5)*.3),new R($+(t()-.5)*.8,L.y0+de,Ee)],$e=new Dr(Se),oe=new G(new Ws($e,10,.075,5),p);for(let me=0;me<2;me++){const Ue=new G(new We(.16,6,4),x);Ue.scale.set(1,.3,.6),Ue.position.copy($e.getPoint(.35+me*.3)),Ue.rotation.set(t()*3,t()*3,t()*3),e.add(Ue)}oe.castShadow=!0,e.add(oe);for(let me=0;me<7;me++){const Ue=.2+me/7*.8,Ge=$e.getPoint(Ue),be=new R((t()-.5)*2,t()*1.2-.2,(t()-.5)*2).normalize(),it=new Un().setFromUnitVectors(new R(0,1,0),be);S.push(new He().compose(Ge.add(be.clone().multiplyScalar(.1)),it,new R(1,1,1)))}if(K%3===0){const me=new G(new We(.08,8,6),v);me.position.copy($e.getPoint(.9)),e.add(me)}}const B=new ko(I,M,S.length);S.forEach((K,$)=>B.setMatrixAt($,K)),e.add(B)}const A=[],T=[],P=[],b=[],w=[],D=[],z=[],O=[],Y=[],q=(L,S,y,N,B=t()*Math.PI*2)=>new He().compose(new R(L,S,y),new Un().setFromEuler(new fn(0,B,0)),new R(N,N,N)),j=L=>i.boxes.some(S=>(S.kind==="stump"||S.kind==="log")&&L>S.x0-.6&&L<S.x1+.6)||i.hazards.some(S=>L>S.x0-.3&&L<S.x1+.3)||i.signs.some(S=>Math.abs(S.x-L)<1.4);for(const L of d){for(let S=L.x0+.3;S<L.x1-.3;S+=.35+t()*.35){if(A.push(q(S,L.y,Ot+.3+t()*1.1,.55+t()*.4)),t()<.45&&A.push(q(S+.1,L.y,Pn-.25-t()*.3,.3+t()*.15)),j(S))continue;const y=t();y<.1*n.flowers?T.push(q(S,L.y,Ot+.5+t()*.9,.6+t()*.3)):y>.1&&y<.1+.08*n.flowers?P.push(q(S,L.y,Ot+.5+t()*.9,.6+t()*.3)):y<.215?b.push(q(S,L.y,Ot+.2,.55+t()*.25)):y<.24?O.push(q(S,L.y,Ot+.6,.5+t()*.3)):y<.255?w.push(q(S,L.y-.05,Ot+.5,.35+t()*.2)):y<.255+.015*n.shrooms?Y.push(q(S,L.y,Ot+.8+t()*.6,.6+t()*.3)):y<.33&&z.push(q(S,L.y-.02,Pn-.4-t()*.4,.5+t()*.4))}t()<.5&&D.push(q(L.x1-.4,L.y-.2,Pn-.3,.45))}const Q=(L,S)=>{const y=uM(L);return y.y>0?S/y.y:1},W=(L,S)=>L.map(y=>y.clone().multiply(new He().makeScale(S,S,S)));lM("Grass_Common_Tall")&&e.add(gn("Grass_Common_Tall",W(A,Q("Grass_Common_Tall",.75)),!1)),e.add(gn("Flower_3_Group",W(T,Q("Flower_3_Group",.7)),!1)),e.add(gn("Flower_4_Group",W(P,Q("Flower_4_Group",.7)),!1)),e.add(gn("Bush_Common_Flowers",W(b,Q("Bush_Common_Flowers",1.4)))),e.add(gn("Plant_1_Big",W(O,Q("Plant_1_Big",1)))),e.add(gn("Rock_Medium_1",W(w,Q("Rock_Medium_1",1)))),e.add(gn("Rock_Medium_2",W(D,Q("Rock_Medium_2",1)))),e.add(gn("Pebble_Round_1",W(z,Q("Pebble_Round_1",.25)),!1)),e.add(gn("Mushroom_Common",W(Y,Q("Mushroom_Common",.5)),!1));const le=[],pe=[],Me=[],Le=[];for(let L=-20;L<i.goalX+40;L+=5+t()*6)le.push(q(L,-3.2,-6.5-t()*7,7+t()*3));for(let L=-30;L<i.goalX+60;L+=4+t()*5)(t()<.5?pe:Me).push(q(L,-3.2,-17-t()*10,8+t()*5));for(let L=-20;L<i.goalX+40;L+=2+t()*4)Le.push(q(L,-3.2,-4.5-t()*9,1.4+t()*.8));const qe=(L,S)=>L.map(y=>y.clone().multiply(new He().makeScale(Q(S,1),Q(S,1),Q(S,1)))),J=(L,S)=>L.map((y,N)=>S.filter((B,K)=>K%L.length===N));J(n.near,le).forEach((L,S)=>e.add(gn(n.near[S].name,qe(L,n.near[S].name),!0,n.near[S].tint)));const ae=[...pe,...Me];J(n.far,ae).forEach((L,S)=>e.add(gn(n.far[S].name,qe(L,n.far[S].name),!1,n.far[S].tint))),n.giantShrooms&&e.add(DS(i.goalX,t)),n.mist&&e.add(NS(i.goalX,t)),e.add(gn("Bush_Common_Flowers",qe(Le,"Bush_Common_Flowers"),!1));const we=i.pickups.map((L,S)=>({p:L,i:S})).filter(L=>L.p.kind==="gem"),X=new ko(Pf,MS,Math.max(1,we.length));X.castShadow=!0;const he=new Array(i.pickups.length).fill(-1);we.forEach((L,S)=>he[L.i]=S),e.add(X);const Ae=new Set,Ie=new Map;i.pickups.forEach((L,S)=>{if(L.kind!=="acorn")return;const y=SS();y.position.set(L.x,L.y,0),e.add(y),Ie.set(S,y)});const Je=i.enemies.map(L=>L.kind==="snail"?AS():L.kind==="bee"?RS():L.kind==="roller"?CS():wS());for(const L of Je)e.add(L.root);for(const L of i.signs){const S=bS(If(L.key));S.position.set(L.x,L.y,-1.5),e.add(S)}const ee=i.checkpoints.map(L=>{const S=ES();return S.root.position.set(L.x,L.y,-1.1),e.add(S.root),S});for(const L of i.dps){const S=new G(new We(.5,16,8,0,Math.PI*2,0,Math.PI/2),new Be({color:"#7a5233",roughness:1}));S.scale.set(1.3,.25,1),S.position.set(L.anchorX-.9,L.y,.6),e.add(S)}const re=TS();re.position.set(i.goalX,i.goalY,0),e.add(re);const C=new He,Te=new Un,ie=new R(1,1,1),_e=new R(0,0,0),ue=new R,Oe=ee.map(()=>0);return{root:e,gems:X,gemIndex:he,acorns:Ie,beetles:Je,checkpoints:ee,goal:re,hidePickup(L){Ae.add(L);const S=Ie.get(L);S&&(S.visible=!1)},update(L,S,y){jh.value=S,we.forEach((N,B)=>{const K=N.p;Te.setFromEuler(new fn(0,S*2+K.x,0)),ue.set(K.x,K.y+Math.sin(S*3+K.x)*.06,0),C.compose(ue,Te,L.got[N.i]||Ae.has(N.i)?_e:ie),X.setMatrixAt(B,C)}),X.instanceMatrix.needsUpdate=!0;for(const[N,B]of Ie)L.got[N]&&(B.visible=!1),B.rotation.y=S*1.6,B.position.y=i.pickups[N].y+Math.sin(S*2.4)*.1;i.enemies.forEach((N,B)=>{const K=Je[B];if(L.enemyDead[B]){K.root.scale.y=Math.max(.001,K.root.scale.y-y*6),K.root.scale.y<.05&&(K.root.visible=!1);return}const $=qc(N,L.et,L.rollAt[B]),Ee=qc(N,L.et+1,L.rollAt[B]);K.root.position.set($,_f(N,L.et),0),K.root.visible=N.kind!=="roller"||N.x0-$<22,K.update(S,Ee>=$?1:-1,N.x0-$)}),ee.forEach((N,B)=>{const K=L.cp>=B?1:0;Oe[B]+=(K-Oe[B])*Math.min(1,y*5),N.open(Oe[B])})}}}const jh={value:0};function LS(i,e,t,n){const s=(e.x1-e.x0)/2,r=e.y1-e.y0,o=new G(new mt(s,s*1.15,r,16),t);o.position.set((e.x0+e.x1)/2,e.y0+r/2,0),o.castShadow=o.receiveShadow=!0,i.add(o);const a=new G(new dn(s*.98,16),n);a.rotation.x=-Math.PI/2,a.position.set(o.position.x,e.y1+.005,0),i.add(a);for(let c=0;c<4;c++){const l=new G(new ai(.12,.6,6),t),u=c/4*Math.PI*2+.4;l.position.set(o.position.x+Math.cos(u)*s,e.y0+.08,Math.sin(u)*s),l.rotation.set(Math.sin(u)*1.2,0,-Math.cos(u)*1.2),i.add(l)}}function IS(i,e,t,n){const s=e.x1-e.x0+.6,r=.5,o=(e.x0+e.x1)/2,a=e.y0+r,c=new G(new mt(r,r,s,18,1,!0),t);c.rotation.z=Math.PI/2,c.position.set(o,a,0),c.castShadow=c.receiveShadow=!0,i.add(c);for(const g of[-1,1]){const _=new G(new dn(r,18),n);_.rotation.y=g*Math.PI/2,_.position.set(o+g*s/2,a,0),i.add(_);const m=new G(new jo(.7,1),new Be({color:"#a39a8c",roughness:.95,flatShading:!0}));m.scale.set(1,.9,1),m.position.set(o+g*(s/2-.3),e.y0-.15,-1.5),m.castShadow=!0,i.add(m)}const l=new Be({color:"#6dbb4a",roughness:.9}),u=new Be({color:"#4f9c3a",roughness:.9}),h=new Be({color:"#6cb84c",roughness:.9}),d=Math.round(s*1.6);for(let g=0;g<d;g++){const _=e.x0-.2+g/(d-1)*(s-.2),m=.55+g*7%5*.08,p=new G(new Zo(m,1),g%2?u:h);p.position.set(_,a+r+m*.7+g%2*.4,g%3*.3-.3),p.castShadow=!0,i.add(p)}const f=new G(new mt(r*1.02,r*1.02,s*.95,18,1,!0,Math.PI*.6,Math.PI*.8),l);f.rotation.z=Math.PI/2,f.position.set(o,a,0),i.add(f)}function DS(i,e){const t=new ze,n=new Be({color:"#f4ead8",roughness:.7}),s=["#ff8fb0","#b48cff","#7fd0ff","#ffb36b"].map(o=>new Be({color:o,roughness:.5,emissive:o,emissiveIntensity:.12})),r=new Be({color:"#fff8ec"});for(let o=-10;o<i+30;o+=6+e()*8){const a=3+e()*5,c=-5-e()*12,l=new ze,u=new G(new mt(.3+a*.04,.5+a*.05,a,10),n);u.position.y=a/2;const h=1.2+a*.25,d=new G(new We(h,18,10,0,Math.PI*2,0,Math.PI/2),s[Math.floor(e()*s.length)]);d.scale.y=.55,d.position.y=a-.1;for(let f=0;f<5;f++){const g=new G(new We(h*.12,8,6),r),_=e()*Math.PI*2;g.position.set(Math.cos(_)*h*.6,a+h*.32,Math.sin(_)*h*.6),g.scale.y=.4,l.add(g)}u.castShadow=d.castShadow=!0,l.add(u,d),l.position.set(o,-3.2,c),l.rotation.z=(e()-.5)*.2,t.add(l)}return t}function NS(i,e){const t=new ze,n=US();for(let s=-10;s<i+30;s+=7+e()*6){const r=new G(new kn(14+e()*8,3+e()*2),new Dt({map:n,color:"#eef4ee",transparent:!0,opacity:.35+e()*.2,depthWrite:!1}));r.position.set(s,-1.2+e()*2,-3-e()*10),t.add(r)}return t}let wo=null;function US(){if(wo)return wo;const i=document.createElement("canvas");i.width=128,i.height=64;const e=i.getContext("2d"),t=e.createRadialGradient(64,32,4,64,32,64);return t.addColorStop(0,"rgba(255,255,255,0.9)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,128,64),wo=new $d(i),wo}const ft=(i,e="0 0 64 64")=>`<svg viewBox="${e}" aria-hidden="true">${i}</svg>`,kS={heart:ft('<path d="M32 56 C10 40 4 28 8 18 C12 8 26 6 32 17 C38 6 52 8 56 18 C60 28 54 40 32 56Z" fill="#ff5d73" stroke="#a8243c" stroke-width="4" stroke-linejoin="round"/><ellipse cx="20" cy="20" rx="6" ry="4" fill="#ffd0d8" transform="rotate(-30 20 20)"/>'),heartEmpty:ft('<path d="M32 56 C10 40 4 28 8 18 C12 8 26 6 32 17 C38 6 52 8 56 18 C60 28 54 40 32 56Z" fill="rgba(60,40,30,.35)" stroke="#6a4a3a" stroke-width="4" stroke-linejoin="round"/>'),acorn:ft('<path d="M18 30 C18 46 26 56 32 58 C38 56 46 46 46 30Z" fill="#ffc83d" stroke="#9a5a00" stroke-width="3.5"/><path d="M12 30 C12 18 22 12 32 12 C42 12 52 18 52 30Z" fill="#c58a2a" stroke="#6a3c00" stroke-width="3.5" stroke-linejoin="round"/><path d="M32 12 C32 8 34 5 38 4" stroke="#6a3c00" stroke-width="4" fill="none" stroke-linecap="round"/><ellipse cx="25" cy="38" rx="3" ry="6" fill="#fff0a8"/>'),acornEmpty:ft('<path d="M18 30 C18 46 26 56 32 58 C38 56 46 46 46 30Z" fill="rgba(60,40,30,.3)" stroke="#6a4a3a" stroke-width="3.5"/><path d="M12 30 C12 18 22 12 32 12 C42 12 52 18 52 30Z" fill="rgba(60,40,30,.4)" stroke="#6a4a3a" stroke-width="3.5" stroke-linejoin="round"/>'),gem:ft('<path d="M32 4 L52 26 L32 60 L12 26Z" fill="#5fd8ff" stroke="#1676a8" stroke-width="3.5" stroke-linejoin="round"/><path d="M32 4 L40 26 L32 60 L24 26Z" fill="#9ff0ff"/><path d="M12 26 H52" stroke="#1676a8" stroke-width="2.5"/>'),seed:ft('<path d="M32 8 C46 18 50 34 44 48 C40 56 24 56 20 48 C14 34 18 18 32 8Z" fill="#d79a52" stroke="#7a4a1c" stroke-width="3.5"/><path d="M32 14 C30 26 30 38 32 50" stroke="#a86a2c" stroke-width="3" fill="none"/><path d="M32 8 C30 2 38 0 42 3 C38 4 34 6 32 8Z" fill="#6cc04a" stroke="#2f7a1c" stroke-width="2"/>'),pause:ft('<rect x="17" y="13" width="11" height="38" rx="4" fill="#fff"/><rect x="36" y="13" width="11" height="38" rx="4" fill="#fff"/>'),play:ft('<path d="M20 12 L52 32 L20 52Z" fill="#fff" stroke="#fff" stroke-width="4" stroke-linejoin="round"/>'),retry:ft('<path d="M48 22 A20 20 0 1 0 52 36" stroke="#fff" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M40 8 L52 22 L36 26Z" fill="#fff"/>'),home:ft('<path d="M10 30 L32 10 L54 30" stroke="#fff" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 30 V52 H46 V30" fill="#fff"/>'),gear:ft('<circle cx="32" cy="32" r="10" fill="none" stroke="#fff" stroke-width="7"/><path d="M32 6V14M32 50V58M6 32H14M50 32H58M13.6 13.6L19.3 19.3M44.7 44.7L50.4 50.4M13.6 50.4L19.3 44.7M44.7 19.3L50.4 13.6" stroke="#fff" stroke-width="7" stroke-linecap="round"/>'),map:ft('<path d="M8 14 L24 8 L40 14 L56 8 V50 L40 56 L24 50 L8 56Z" fill="#fff"/><path d="M24 8V50M40 14V56" stroke="#7a4a1c" stroke-width="3"/>'),calendar:ft('<rect x="8" y="12" width="48" height="44" rx="7" fill="#fff"/><rect x="8" y="12" width="48" height="12" rx="6" fill="#ffd1a0"/><circle cx="24" cy="38" r="4" fill="#7a4a1c"/><circle cx="40" cy="38" r="4" fill="#7a4a1c"/>'),music:ft('<path d="M24 46 V14 L50 8 V40" stroke="#fff" stroke-width="6" fill="none" stroke-linejoin="round"/><circle cx="18" cy="46" r="8" fill="#fff"/><circle cx="44" cy="40" r="8" fill="#fff"/>'),sound:ft('<path d="M10 24 H22 L36 12 V52 L22 40 H10Z" fill="#fff"/><path d="M44 22 C50 28 50 36 44 42M50 16 C60 26 60 38 50 48" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round"/>'),lock:ft('<rect x="14" y="28" width="36" height="28" rx="6" fill="#fff"/><path d="M22 28 V20 A10 10 0 0 1 42 20 V28" stroke="#fff" stroke-width="6" fill="none"/>'),star:ft('<path d="M32 4 L40 24 L61 24 L44 37 L50 58 L32 45 L14 58 L20 37 L3 24 L24 24Z" fill="#ffd54a" stroke="#b07a00" stroke-width="3" stroke-linejoin="round"/>'),starEmpty:ft('<path d="M32 4 L40 24 L61 24 L44 37 L50 58 L32 45 L14 58 L20 37 L3 24 L24 24Z" fill="rgba(80,60,40,.25)" stroke="#8a6a4a" stroke-width="3" stroke-linejoin="round"/>'),tv:ft('<rect x="6" y="16" width="52" height="38" rx="7" fill="#fff"/><path d="M22 6 L32 16 L42 6" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M27 26 L41 35 L27 44Z" fill="#e0672f"/>'),hat:ft('<path d="M8 46 C8 40 18 38 32 38 C46 38 56 40 56 46 C56 50 8 50 8 46Z" fill="#fff"/><path d="M18 40 C18 22 24 14 32 14 C40 14 46 22 46 40Z" fill="#fff"/><path d="M18 34 H46" stroke="#e0672f" stroke-width="5"/>'),globe:ft('<circle cx="32" cy="32" r="24" fill="none" stroke="#fff" stroke-width="5"/><path d="M8 32 H56 M32 8 C20 20 20 44 32 56 M32 8 C44 20 44 44 32 56" stroke="#fff" stroke-width="4" fill="none"/>'),close:ft('<path d="M16 16 L48 48 M48 16 L16 48" stroke="#fff" stroke-width="8" stroke-linecap="round"/>')},FS={bridge:ft('<path d="M4 70 H36 V96 H4Z" fill="#9a6a43"/><path d="M84 70 H116 V96 H84Z" fill="#9a6a43"/><path d="M4 66 H36 M84 66 H116" stroke="#7cc95a" stroke-width="8" stroke-linecap="round"/><path d="M36 80 Q60 92 84 80" stroke="#5ab0e0" stroke-width="10" fill="none" opacity=".7"/><g fill="#c99662" stroke="#7a4a1c" stroke-width="2.5">'+[0,1,2,3,4,5,6,7].map(i=>`<rect x="${22+i*10}" y="${62+Math.sin(i/7*Math.PI)*4}" width="8" height="8" rx="2"/>`).join("")+'</g><path d="M24 46 Q60 58 96 46" stroke="#3f9a37" stroke-width="5" fill="none"/><path d="M24 46 V64 M96 46 V64" stroke="#7a4a1c" stroke-width="5" stroke-linecap="round"/><path d="M44 52 l-5 -6 l7 1z M70 54 l5 -6 l-7 1z" fill="#5cb840"/>',"0 0 120 100"),vine:ft('<rect x="70" y="10" width="40" height="86" rx="4" fill="#9c9184"/><path d="M70 10 H110" stroke="#7cc95a" stroke-width="8" stroke-linecap="round"/><path d="M50 96 C44 76 56 60 50 40 C46 26 54 16 52 8" stroke="#3f9a37" stroke-width="6" fill="none"/><path d="M64 96 C58 76 70 60 64 40 C60 26 68 16 66 8" stroke="#3f9a37" stroke-width="6" fill="none"/><g stroke="#6b8f2f" stroke-width="5" stroke-linecap="round">'+[0,1,2,3,4,5,6].map(i=>`<path d="M${50+i%2} ${88-i*12} H${64+i%2}"/>`).join("")+'</g><g fill="#79cf4f">'+[0,1,2,3,4].map(i=>`<path d="M${i%2?66:48} ${80-i*16} q${i%2?12:-12} -4 ${i%2?14:-14} -12 q${i%2?-10:10} 0 ${i%2?-14:14} 12z"/>`).join("")+'</g><circle cx="58" cy="10" r="5" fill="none" stroke="#79cf4f" stroke-width="4"/>',"0 0 120 100"),mushroom:ft('<path d="M48 92 C46 76 48 62 52 54 H68 C72 62 74 76 72 92Z" fill="#f6ead2" stroke="#b89a70" stroke-width="3"/><path d="M16 58 C16 26 38 12 60 12 C82 12 104 26 104 58 C90 64 30 64 16 58Z" fill="#ff6b6b" stroke="#a8243c" stroke-width="3.5" stroke-linejoin="round"/><g fill="#fff8ec"><ellipse cx="44" cy="30" rx="8" ry="6"/><ellipse cx="72" cy="26" rx="9" ry="6"/><ellipse cx="88" cy="44" rx="6" ry="5"/><ellipse cx="30" cy="48" rx="6" ry="4"/><ellipse cx="60" cy="46" rx="6" ry="4"/></g><path d="M60 4 v-0 M38 6 l-4 -4 M82 6 l4 -4" stroke="#ffd54a" stroke-width="4" stroke-linecap="round"/><path d="M40 96 q10 -8 20 -2 q10 -6 20 2" stroke="#5cb840" stroke-width="5" fill="none" stroke-linecap="round"/>',"0 0 120 100"),tree:ft('<rect x="52" y="50" width="16" height="46" fill="#8b5a35"/><circle cx="60" cy="38" r="30" fill="#5cb840"/><circle cx="46" cy="30" r="14" fill="#7bd05a"/>',"0 0 120 100"),leaf:ft('<path d="M20 70 C30 20 90 10 104 24 C96 60 50 86 20 70Z" fill="#6cc04a" stroke="#2f7a1c" stroke-width="3.5"/><path d="M20 70 C50 52 76 38 104 24" stroke="#2f7a1c" stroke-width="3" fill="none"/>',"0 0 120 100"),log:ft('<rect x="14" y="44" width="92" height="28" rx="14" fill="#8b5a35" stroke="#5a3a20" stroke-width="3"/><ellipse cx="100" cy="58" rx="8" ry="14" fill="#d9a86c" stroke="#5a3a20" stroke-width="3"/>',"0 0 120 100")},As=()=>document.getElementById("ui");function tn(i){const e=document.createElement("div");return e.innerHTML=i.trim(),e.firstElementChild}const nt=(i,e="ico")=>`<span class="${e}">${kS[i]}</span>`;function Nn(i){return i.replace(/[&<>"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[e])}function Ci(i){return document.getElementById(i.id)?.remove(),As().append(i),i}function Sn(i){document.getElementById(i)?.remove()}const ei=[];function OS(i){for(let e=ei.length-1;e>=0;e--)ei[e].left-=i,(ei[e].left<=0||!ei[e].node.isConnected)&&(ei[e].node.remove(),ei.splice(e,1))}function BS(i,e){ei.push({node:i,left:e})}function Kh(i,e=!1,t=1800){document.querySelectorAll(".bubble").forEach(s=>s.remove());const n=tn(`<div class="bubble${e?" good":""}">${Nn(i)}</div>`);return As().append(n),ei.push({node:n,left:t/1e3}),n}function ia(i,e=2500){const t=tn(`<div class="toast">${Nn(i)}</div>`);As().append(t),ei.push({node:t,left:e/1e3})}function wt(i,e,t,n){i.querySelectorAll(e).forEach(s=>s.addEventListener("click",r=>{r.stopPropagation(),n?.(),t(s)}))}function Qc(i,e="ico"){return[0,1,2].map(t=>nt(t<i?"star":"starEmpty",e)).join("")}const ke=(i,e)=>Nn($t(i,e)),Hi=(i,e,t)=>i+(e-i)*t;class zS{constructor(e,t,n){te(this,"sim");te(this,"world");te(this,"sprite",new vS);te(this,"fx");te(this,"plantViews",[]);te(this,"acc",0);te(this,"prevX");te(this,"prevY");te(this,"phase",0);te(this,"squash",0);te(this,"shake",0);te(this,"time",0);te(this,"cam",{x:0,y:0,w:11,sx:.3,sy:.4,init:!1});te(this,"camGroundY",0);te(this,"hud");te(this,"dpSheet",null);te(this,"usedCards",new Set);te(this,"hand",null);te(this,"handSign",-1);te(this,"handDone",new Set);te(this,"ended",!1);te(this,"endT",0);te(this,"paused",!1);te(this,"replay",null);te(this,"botThink",1.1);te(this,"botT",0);te(this,"hitStop",0);te(this,"glideLeaf",(()=>{const e=new ze,t=new G(Ef(1.3,.75),new Be({color:"#5fbf45",side:Bt,roughness:.6}));return t.rotation.x=-Math.PI/2+.75,t.position.z=-.6,t.castShadow=!0,e.add(t),e.rotation.y=-Math.PI/2+.5,e})());te(this,"won",!1);te(this,"noSeeds",!1);te(this,"revived",!1);te(this,"coverZoom",0);te(this,"frozen",!1);te(this,"last",{hearts:-1,gems:-1,acorns:-1,seeds:-1});te(this,"onBotGesture",null);this.stage=e,this.level=t,this.hooks=n,this.sim=PM(t),this.prevX=this.sim.x,this.prevY=this.sim.y,this.camGroundY=this.sim.y,e.world.clear();const s=Tf(t.world);e.setTheme(s.stage),e.setAmbient(s.ambient),this.world=PS(t),this.sprite.setColor($h.color),this.sprite.setHat($h.hat),e.world.add(this.world.root,this.sprite.root,this.sprite.shadow),this.fx=new sS(e.fx),this.fx.clear(),this.hud=this.buildHud(),As().append(this.hud),this.updateHud(!0)}dispose(){this.hud.remove(),this.dpSheet?.remove(),this.hand?.remove(),document.querySelectorAll(".bubble").forEach(e=>e.remove()),this.fx.clear(),this.stage.world.clear()}buildHud(){const e=tn(`<div id="hud">
      <div class="hud-left">
        <div class="pill" data-hearts></div>
        <div class="pill" data-gems>${nt("gem")}<b data-v>0</b></div>
      </div>
      <div class="progress"><i></i><b></b></div>
      <div class="hud-right">
        <div class="hud-row">
          <div class="pill" data-acorns></div>
          <button class="btn wood" id="btn-pause" aria-label="${Nn($t("pause.title"))}">${HS}</button>
        </div>
        <div class="pill" data-seeds>${nt("seed")}<b data-v>0</b></div>
      </div>
    </div>`);return e.querySelector("#btn-pause").addEventListener("click",t=>{t.stopPropagation(),Mt("click"),this.hooks.onPause()}),e}updateHud(e=!1){const t=this.sim,n=o=>this.hud.querySelector(`[data-${o}]`),s=o=>{o.classList.remove("bump"),o.offsetWidth,o.classList.add("bump")};(e||t.hearts!==this.last.hearts)&&(n("hearts").innerHTML=[0,1,2].map(o=>nt(o<t.hearts?"heart":"heartEmpty")).join(""),e||s(n("hearts"))),(e||t.gems!==this.last.gems)&&(n("gems").querySelector("[data-v]").textContent=String(t.gems),e||s(n("gems"))),(e||t.acorns!==this.last.acorns)&&(n("acorns").innerHTML=[0,1,2].map(o=>nt(o<t.acorns?"acorn":"acornEmpty")).join(""),e||s(n("acorns"))),(e||t.seeds!==this.last.seeds)&&(n("seeds").querySelector("[data-v]").textContent=String(t.seeds),n("seeds").classList.toggle("hidden",this.level.dps.length===0),e||s(n("seeds"))),this.last={hearts:t.hearts,gems:t.gems,acorns:t.acorns,seeds:t.seeds};const r=Math.max(0,Math.min(1,(t.x-this.level.startX)/(this.level.goalX-this.level.startX)));this.hud.querySelector(".progress i").style.width=`${r*100}%`,this.hud.querySelector(".progress b").style.left=`${r*100}%`}showCards(){const e=this.sim,t=this.level.dps[e.dp];if(this.dpSheet?.remove(),this.dpSheet=null,e.seeds<=0){this.noSeeds||this.hooks.onNoSeeds(e),this.noSeeds=!0;return}const n=t.cards.map(s=>{const r=this.usedCards.has(`${e.dp}:${s}`);return`<button class="card${r?" used":""}" data-plant="${s}" ${r?"disabled":""}>
          <span class="art">${FS[s]}</span><span class="name">${Nn($t(`plant.${s}`))}</span></button>`}).join("");this.dpSheet=tn(`<div id="dp" class="ui-block">
      <div class="dp-prompt"><span>${Nn($t("dp.prompt"))}</span><span class="seeds">${nt("seed")}${e.seeds}</span></div>
      <div class="cards">${n}</div></div>`),this.dpSheet.querySelectorAll(".card").forEach(s=>s.addEventListener("click",r=>{r.stopPropagation(),!this.replay&&this.pick(s.dataset.plant)})),As().append(this.dpSheet)}pick(e){const t=this.sim;if(t.mode!=="decide")return;this.dpSheet?.querySelector(`[data-plant="${e}"]`)?.classList.add("picked"),Mt("card"),UM(this.level,t,e)&&(this.usedCards.add(`${t.dp}:${e}`),this.handleEvents())}input(){if(this.replay){const e=this.replay.input(this.sim);return e.jumpPressed&&this.onBotGesture?.("tap"),e.duckPressed&&this.onBotGesture?.("swipeDown"),e}return zt.sample()}update(e){if(!this.paused){if(e=Math.min(e,.1),this.time+=e,this.hud.classList.toggle("hidden",this.frozen),this.frozen){this.render(e);return}if(this.hitStop>0)this.hitStop-=e;else for(this.acc+=e;this.acc>=Rt;){this.acc-=Rt,this.prevX=this.sim.x,this.prevY=this.sim.y;const t=this.input();if(FM(this.level,this.sim,t),this.handleEvents(),this.ended)break}if(this.replay&&this.sim.mode==="decide"&&this.dpSheet){if(this.botT+=e,this.botT>this.botThink){this.botT=0;const t=this.replay.choice();t&&this.pick(t)}}else this.botT=0;this.ended&&(this.endT+=e,this.endT>(this.won?1.6:1.1)&&this.endT-e<=(this.won?1.6:1.1)&&(this.won?this.hooks.onWin(this.sim,OM(this.level,this.sim)):this.hooks.onLose(this.sim))),this.render(e)}}handleEvents(){const e=this.sim;for(const t of e.events)switch(t){case"jump":Mt("jump"),this.fx.dust(e.x,e.y,4,.6);break;case"land":e.landV>6&&(this.squash=Math.min(1,e.landV/18),this.fx.dust(e.x,e.y,e.landV>12?10:5),Mt("land"));break;case"duck":Mt("duck"),e.grounded&&this.fx.dust(e.x-.3,e.y,5,.8);break;case"gem":{const n=this.level.pickups[e.lastPickup];Mt("gem"),this.fx.sparkle(n.x,n.y,"#9ff0ff",8);break}case"acorn":{const n=this.level.pickups[e.lastPickup];Mt("acorn"),this.fx.sparkle(n.x,n.y,"#ffe27a",22),this.world.hidePickup(e.lastPickup);break}case"hit":Mt("hit"),this.shake=.35;break;case"stomp":{Mt("stomp");const n=this.level.enemies[e.lastEnemy];this.fx.dust(e.x,n.y+.3,10,1.2),this.fx.sparkle(e.x,n.y+.5,"#fff0a0",8),this.hitStop=.06;break}case"fall":Mt("fall"),this.cam.init=!1;break;case"checkpoint":Mt("checkpoint");{const n=this.level.checkpoints[e.cp];this.fx.sparkle(n.x,n.y+1.7,"#ffb8e0",12)}break;case"dpStop":Mt("stop"),this.showCards();break;case"plant":{this.dpSheet?.classList.add("hidden");const n=e.plants[e.plants.length-1],s=hS(n.kind);s.root.position.set(n.x,n.y,0),s.grow(0),this.world.root.add(s.root),this.plantViews.push({dp:n.dp,view:s,at:this.time}),Mt("grow"),this.fx.magic(n.x+(n.kind==="bridge"?2.5:0),n.y,n.kind==="vine"?5:1.2),this.fx.leaves(n.x,n.y+.2,10);break}case"bounce":Mt("bounce"),this.plantViews[this.plantViews.length-1]?.view.poke(),this.squash=.8;break;case"climb":Mt("climb");break;case"hop":this.plantViews.length&&e.plants[e.plants.length-1]?.kind==="log"&&Mt("jump");break;case"glide":Mt("glide");break;case"roll":Mt("roll");break;case"speed":GS();break;case"success":Mt("checkpoint"),Kh($t("nice"),!0,1200),this.fx.leaves(e.x,e.y+.5,12),this.dpSheet?.remove(),this.dpSheet=null;break;case"fail":{const n=e.failReason;if(Mt(n==="splash"?"splash":n==="thorns"?"thorns":n==="bonk"?"bonk":"fall"),n==="splash"){const s=this.level.water.find(r=>e.x>=r.x0-1&&e.x<=r.x1+1);this.fx.splash(e.x,s?s.y:e.y)}(n==="thorns"||n==="bonk")&&(this.shake=.3),Kh($t(`fail.${n||"fall"}`),!1,2200);break}case"win":Mt("win"),this.ended=!0,this.won=!0,this.fx.leaves(e.x,e.y+1,30),this.fx.sparkle(e.x,e.y+1.5,"#ffe27a",30);break;case"lose":Mt("lose"),this.ended=!0;break}e.mode==="decide"&&!this.noSeeds&&(!this.dpSheet?.isConnected||this.dpSheet.classList.contains("hidden"))&&this.showCards(),this.updateHud()}render(e){const t=this.sim,n=this.acc/Rt,s=Hi(this.prevX,t.x,n),r=Hi(this.prevY,t.y,n);this.squash=Math.max(0,this.squash-e*5),this.phase+=Math.abs(t.vx)*e*3.2;const o=this.sprite;o.root.position.set(s,r,0),o.update({phase:this.phase,speed:Math.abs(t.vx),vy:t.vy,grounded:t.grounded,ducking:t.ducking,climbing:t.climbing,squash:this.squash,hurt:t.invuln>0&&t.mode==="run",dizzy:t.mode==="fail"&&(t.failReason==="bonk"||t.failReason==="thorns"),idle:t.mode==="decide"||t.mode==="grow"||this.frozen,cheer:t.mode==="won",t:this.time}),o.setGlide(t.gliding&&(t.mode==="cross"||t.mode==="fail"),this.glideLeaf),t.mode==="fail"&&t.failReason==="thorns"&&(o.root.position.y+=Math.abs(Math.sin(t.modeT*9))*.4*Math.max(0,1-t.modeT));const a=this.groundBelow(s,r);o.shadow.position.set(s,a+.03,.05);const c=Math.max(0,r-a);o.shadow.visible=a>-50,o.shadow.scale.setScalar(Math.max(.3,1-c*.15));for(let l=this.plantViews.length-1;l>=0;l--){const u=this.plantViews[l];if(!t.plants.some(f=>f.dp===u.dp&&f.kind===u.view.kind)){this.world.root.remove(u.view.root),this.plantViews.splice(l,1);continue}const d=Math.min(1,(this.time-u.at)/pf);u.view.grow(d),t.mode==="fail"&&t.dp===u.dp&&l===this.plantViews.length-1&&u.view.wilt(Math.min(1,t.modeT/(mf*.7))),u.view.update(e,this.time)}this.world.update(t,this.time,e),this.fx.update(e),this.updateCamera(s,r,e),this.updateHand(s)}groundBelow(e,t){let n=-100;for(const s of this.level.boxes)e>s.x0&&e<s.x1&&s.y1<=t+.05&&s.y1>n&&(n=s.y1);for(const s of this.sim.plants)s.kind==="bridge"&&e>s.x&&e<s.x+qi&&s.y<=t+.05&&s.y>n&&(n=s.y);return n}updateCamera(e,t,n){const s=this.stage,r=s.width/s.height<1,o=this.sim;let a,c,l,u,h;const d=o.dp>=0&&(o.mode==="decide"||o.mode==="grow"||o.mode==="cross"||o.mode==="fail")?this.level.dps[o.dp]:null;o.grounded?this.camGroundY=t:t<this.camGroundY-.5?this.camGroundY=t+.5:t>this.camGroundY+3.2&&(this.camGroundY=t-3.2),d?(a=(d.stopX-1.5+d.exitX+1)/2,c=d.y+(d.obstacle==="wall"?d.height*.45:1),l=Math.max(r?10.5:0,d.exitX-d.stopX+4.5),u=.5,h=r?.56:.5):(a=e+o.vx/12,c=this.camGroundY+.8,u=r?.25:.3,h=r?.33:.36,l=Math.max(r?9.6:0,hf(o.speed)/(1-u)+.4));const f=this.cam.init?1-Math.exp(-n*(d?2.5:12)):1,g=this.cam.init?1-Math.exp(-n*3.5):1;this.cam.x=Hi(this.cam.x,a,f),this.cam.y=Hi(this.cam.y,c,g),this.cam.w=Hi(this.cam.w,l,this.cam.init?1-Math.exp(-n*2.5):1),this.cam.sx=Hi(this.cam.sx,u,this.cam.init?1-Math.exp(-n*2.5):1),this.cam.sy=Hi(this.cam.sy,h,this.cam.init?1-Math.exp(-n*2.5):1),this.cam.init=!0;const _=r?0:d?Math.max(10.5,(d.height||0)+(d.drop||0)+6):10.5;if(this.coverZoom){const m=this.coverZoom;s.frame(e+(r?1:1.6),this.camGroundY+1.2,(r?9:0)*m,10.5*m*(r?0:1),.42,r?.55:.5);return}s.frame(this.cam.x,this.cam.y,this.cam.w,_,this.cam.sx,this.cam.sy),this.shake>0&&(this.shake=Math.max(0,this.shake-n),s.camera.position.x+=Math.sin(this.time*60)*this.shake*.25,s.camera.position.y+=Math.cos(this.time*47)*this.shake*.2)}updateHand(e){const t=this.sim;let n=-1;if(this.level.signs.forEach((s,r)=>{!s.hand||this.handDone.has(r)||(s.hand==="choose"?t.mode==="decide"&&t.dp>=0&&Math.abs(this.level.dps[t.dp].stopX-s.x)<10&&(n=r):e>s.x-1&&e<s.x+9&&t.mode==="run"&&(n=r))}),n!==this.handSign&&(this.handSign=n,this.hand?.remove(),this.hand=null,n>=0)){const s=this.level.signs[n].hand;if(s!=="choose"&&!Lf()&&zt.keyboard&&this.handDone.size>0)return;const r=this.level.signs[n],o=s==="choose"?"":`<span class="cap">${Nn(If(r.key))}</span>`;this.hand=tn(`<div id="hand" class="${s}"><span class="ring"></span>${VS}${o}</div>`),As().append(this.hand)}if(this.hand&&n>=0){const s=this.level.signs[n].hand,r=this.stage.width,o=this.stage.height;if(s==="choose"){const a=this.dpSheet?.querySelector(".cards")?.getBoundingClientRect();a&&(this.hand.style.left=`${a.left+a.width/2}px`,this.hand.style.top=`${a.top+a.height*.45}px`)}else this.hand.style.left=`${r*.62}px`,this.hand.style.top=`${o*(r<o?.62:.6)}px`}}gesture(e){if(this.handSign<0)return;const t=this.level.signs[this.handSign];(t.hand==="tap"||t.hand==="hold")&&e==="tap"&&this.handDone.add(this.handSign),t.hand==="swipeDown"&&e==="swipeDown"&&this.handDone.add(this.handSign)}reviveWithHeart(){BM(this.sim),this.ended=!1,this.endT=0,this.prevX=this.sim.x,this.prevY=this.sim.y,this.cam.init=!1,this.updateHud(!0)}addTwoSeeds(){zM(this.sim,2),this.noSeeds=!1,this.updateHud(!0),this.sim.mode==="decide"&&this.showCards()}forceLose(){this.sim.hearts=0,this.sim.mode="lost",this.ended=!0,this.won=!1,this.endT=0}nextDecision(){return xf(this.level,this.sim)}get finished(){return this.ended}}const HS='<svg viewBox="0 0 64 64"><rect x="15" y="12" width="12" height="40" rx="4" fill="#fff"/><rect x="37" y="12" width="12" height="40" rx="4" fill="#fff"/></svg>',VS='<svg viewBox="0 0 64 64"><path d="M26 30 V10 a5 5 0 0 1 10 0 V28 l2 -1 a5 5 0 0 1 8 2 l1 1 a5 5 0 0 1 8 3 V44 C55 54 48 60 38 60 H34 C26 60 22 56 18 50 L10 38 a5 5 0 0 1 8 -6 Z" fill="#fff" stroke="#4a2e1a" stroke-width="3.5" stroke-linejoin="round"/></svg>';let Zh=-99;function GS(){const i=performance.now()/1e3;i-Zh<4||(Zh=i,ia($t("faster"),1200))}const Jh=30;class sa{constructor(e,t,n,s,r=1,o=Ai,a=0){te(this,"x",0);te(this,"y",0);te(this,"level");this.level={id:e,world:t,n,seeds:s,speed:o,ramp:a,startX:2,startY:0,goalX:0,goalY:0,boxes:[],hazards:[],pickups:[],enemies:[],signs:[],checkpoints:[],dps:[],water:[],killY:-7,seed:r},this.level.boxes.push({x0:-30,x1:0,y0:-Jh,y1:0,kind:"ground"})}ground(e){const t=this.level,n=t.boxes[t.boxes.length-1];return n&&n.kind==="ground"&&Math.abs(n.x1-this.x)<1e-6&&Math.abs(n.y1-this.y)<1e-6?n.x1+=e:t.boxes.push({x0:this.x,x1:this.x+e,y0:this.y-Jh,y1:this.y,kind:"ground"}),this.x+=e,this}up(e){return this.y+=e,this}down(e){return this.y-=e,this}gap(e,t=!1){return t&&this.level.water.push({x0:this.x,x1:this.x+e,y:this.y-1.3}),this.x+=e,this}stump(e=.8,t=1,n=1,s=3){return this.ground(n),this.level.boxes.push({x0:this.x,x1:this.x+t,y0:this.y,y1:this.y+e,kind:"stump"}),this.ground(t+s)}lowLog(e=3,t=1,n=3){return this.ground(t),this.level.boxes.push({x0:this.x,x1:this.x+e,y0:this.y+.78,y1:this.y+3.4,kind:"log"}),this.ground(e+n)}ledge(e,t,n){return this.level.boxes.push({x0:this.x+e,x1:this.x+e+n,y0:this.y+t-.5,y1:this.y+t,kind:"ledge",oneWay:!0}),this}thorns(e,t=1){return this.level.hazards.push({x0:this.x,x1:this.x+e,y0:this.y,y1:this.y+t,kind:"thorns"}),this.ground(e)}gems(e,t=.5,n=.7,s=1){for(let r=0;r<e;r++)this.level.pickups.push({x:this.x+t+r*s,y:this.y+n,kind:"gem"});return this}arc(e,t,n,s,r=.7){for(let o=0;o<e;o++){const a=e===1?.5:o/(e-1);this.level.pickups.push({x:this.x+t+a*n,y:this.y+r+s*4*a*(1-a),kind:"gem"})}return this}acorn(e,t){return this.level.pickups.push({x:this.x+e,y:this.y+t,kind:"acorn"}),this}sign(e,t,n=0){return this.level.signs.push({x:this.x+n,y:this.y,key:e,hand:t}),this}checkpoint(e=0){return this.level.checkpoints.push({x:this.x+e,y:this.y}),this}beetle(e,t,n=1.3){return this.enemy("beetle",e,t,n)}enemy(e,t,n,s=1.3,r={}){return this.level.enemies.push({kind:e,x0:this.x+t,x1:this.x+t+n,y:this.y,speed:s,...r,...r.y!==void 0?{y:this.y+r.y}:{}}),this}decision(e,t,n,s,r={}){const o=typeof r=="number"?{lead:r}:r;this.ground(o.lead??4.5);const a=this.x,c=this.y,l={obstacle:e,stopX:a-2.4,y:c,anchorX:a,exitX:0,cards:n,answer:s,width:t,height:0,alsoWorks:o.alsoWorks??[],acorn:-1};return o.acornAt&&(l.acorn=this.level.pickups.length,this.level.pickups.push({x:a+o.acornAt[0],y:c+o.acornAt[1],kind:"acorn"})),e==="river"||e==="gap"?(this.gap(t,e==="river"),l.exitX=this.x+1.2):e==="cliff"?(l.drop=o.drop??4,this.gap(t),this.down(l.drop),l.exitX=this.x+1.2):e==="wall"?(l.height=t,l.width=0,this.level.boxes.push({x0:this.x,x1:this.x+1.2,y0:this.y,y1:this.y+t,kind:"wall"}),this.up(t),l.exitX=this.x+1.4):e==="thorns"&&(l.height=o.thornH??1.2,this.thorns(t,l.height),l.exitX=this.x+.9),this.level.dps.push(l),this}goal(e=6){return this.level.goalX=this.x+2,this.level.goalY=this.y,this.ground(e+2)}done(){const e=this.level;return e.checkpoints.sort((t,n)=>t.x-n.x),e.killY=Math.min(...e.boxes.map(t=>t.y1))-7,e}}function WS(){const i=new sa("1-1",1,1,0,11,Ai,.02);return i.ground(4).gems(5,1,.7,1.2),i.ground(10),i.sign("tut.jump","tap",1).ground(5),i.arc(3,.2,2.2,1.2,1.2).stump(.9,1,1,6),i.arc(3,.2,2.2,1.2,1.2).stump(.9,1,1,5),i.gems(4,0,.7,1).ground(6),i.arc(4,-.4,3,1.5).gap(2.4).ground(6),i.checkpoint(1).gems(3,2,.7,1).ground(6),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,4),i.arc(4,-.4,3,1.5).gap(2.6).ground(5),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,6),i.checkpoint(0).sign("tut.hold","hold",3.5).ground(6),i.gems(3,0,.7,1).ground(3).up(2.2).ground(8),i.acorn(4,3.4).gems(2,1,.7,1).ground(8),i.down(2.2).ground(6).gems(4,0,.7,1).ground(4),i.up(2.2).ground(3).arc(3,0,2,1).ground(6).down(1).ground(6).down(1.2).ground(6),i.checkpoint(0).sign("tut.duck","swipeDown",3.5).ground(6),i.gems(3,.5,.45,1).lowLog(3,1,4),i.gems(4,0,.7,1).ground(5),i.acorn(1.8,.4).lowLog(3.5,1,5),i.arc(4,-.4,3,1.5).gap(2.4).ground(5),i.checkpoint(0).gems(3,.5,.45,1).lowLog(3,1,4),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.gems(3,0,.7,1).ground(4).up(2).ground(4),i.ledge(3,2.6,4).acorn(5,3.6).gems(3,3.5,3.2,1).ground(10),i.down(2).ground(4).arc(4,-.4,3,1.5).gap(2.6).ground(5),i.gems(3,.5,.45,1).lowLog(3,1,4),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.arc(4,-.4,3,1.5).gap(2.4,!0).ground(5),i.gems(6,0,.7,1).ground(8),i.goal().done()}function XS(){const i=new sa("1-2",1,2,3,23,Ai,.02);return i.ground(6).gems(5,1,.7,1.2).ground(10),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.arc(4,-.4,3,1.5).gap(2.4,!0).ground(5),i.gems(3,.5,.45,1).lowLog(3,1,4),i.gems(3,0,.7,1).ground(4).up(2.2).ground(5),i.acorn(3,3.4).ground(7).down(2.2).ground(5),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,6),i.checkpoint(0).ground(4),i.sign("tut.choose","choose",1).ground(2),i.gems(3,4,.7,1).decision("river",5.5,["bridge","vine"],"bridge"),i.gems(4,1.5,.7,1).ground(8),i.arc(4,-.4,3,1.5).gap(2.6,!0).ground(5),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,4),i.ledge(2,2.6,4).acorn(4,3.6).gems(3,1.5,3.2,1).ground(9),i.checkpoint(0).gems(3,.5,.45,1).lowLog(3,1,4),i.gems(3,0,.7,1).ground(4).up(1).ground(5).up(1).ground(6),i.arc(4,-.4,3,1.5).gap(2.8).ground(6),i.down(2).ground(5),i.acorn(1.8,.4).lowLog(3.5,1,5),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.arc(4,-.4,3,1.5).gap(2.4,!0).ground(6),i.checkpoint(0).gems(5,0,.7,1).ground(8),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.gems(3,.5,.45,1).lowLog(3,1,4),i.arc(4,-.4,3,1.5).gap(2.6).ground(5),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,6),i.gems(6,0,.7,1).ground(8),i.goal().done()}function qS(){const i=new sa("1-3",1,3,4,37,Ai,.02);return i.ground(6).gems(5,1,.7,1.2).ground(10),i.sign("tut.stomp","tap",0).ground(3),i.beetle(3,4).gems(3,3,2.2,1).ground(10),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.arc(4,-.4,3,1.5).gap(2.6,!0).ground(5),i.gems(3,.5,.45,1).lowLog(3,1,4),i.acorn(5,5.6).ground(2).up(2.2).ground(8).down(2.2).ground(4),i.checkpoint(0).ground(4),i.gems(3,3,.7,1).decision("wall",5,["bridge","vine","mushroom"],"vine"),i.gems(4,1,.7,1).ground(8),i.beetle(2,4.5).ground(9),i.arc(4,-.4,3,1.5).gap(2.6).ground(5),i.ledge(2,2.6,4).acorn(4,3.6).gems(3,1.5,3.2,1).ground(9),i.down(2.5).ground(6).down(2.5).ground(5),i.checkpoint(0).gems(3,.5,.45,1).lowLog(3,1,4),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,5),i.beetle(1,5).ground(10),i.checkpoint(0).ground(2),i.arc(5,1.5,5,2.4,1.5).decision("thorns",5,["bridge","mushroom","vine"],"mushroom"),i.gems(4,1.5,.7,1).ground(8),i.arc(4,-.4,3,1.5).gap(2.6,!0).ground(5),i.acorn(1.8,.4).lowLog(3.5,1,5),i.beetle(2,4).ground(10),i.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,4),i.gems(3,0,.7,1).ground(4).up(1.1).ground(5).down(1.1).ground(5),i.checkpoint(0).gems(6,0,.7,1).ground(8),i.goal().done()}const Qh=[WS(),XS(),qS()];function $S(i){let e=i*2654435761>>>0||1;return()=>(e^=e<<13,e>>>=0,e^=e>>>17,e^=e<<5,e>>>=0,e/4294967296)}const ed=[["stump","gap","stream","lowLog","thorns","beetle","step"],["beeHigh","beeLow"],["snail","beetles"],["roller"],[]],td=[["river","wall","thorns","gap"],["cliff","riverAcorn","lowWallAcorn"],["wideRiver","cliffTree"],["shortThorns","shortThornsAcorn"],[]],nd=(i,e)=>i.slice(0,e).flat(),YS={2:[{sign:"tut.bee",hazard:"beeHigh"},{sign:"tut.leaf",recipe:"cliff"},{sign:"tut.acornChoice",recipe:"riverAcorn"}],3:[{sign:"tut.snail",hazard:"snail"},{sign:"tut.tree",recipe:"wideRiver"},{sign:"tut.tree",recipe:"cliffTree"}],4:[{sign:"tut.roll",hazard:"roller"},{sign:"tut.log",recipe:"shortThorns"},{sign:"tut.acornChoice",recipe:"shortThornsAcorn"}],5:[{sign:"tut.double",recipe:"wall"},{sign:"tut.fog",hazard:"beeLow"},{sign:"tut.double",recipe:"riverAcorn"}]};function jS(i,e,t=!1){return Math.min(78,42+(i-1)*5+(e-1)*1.8+(t?4:0))}function KS(i,e){return Math.min(Nl*.92,Ai*(1+.05*(i-1)+.006*(e-1)))}function Bl(i,e,t,n={}){const s=$S(t*977+i*131+e*17),r=X=>X[Math.floor(s()*X.length)],o=!n.special&&!n.daily&&e<=3,a=o?YS[i]?.[e-1]:void 0,c=n.special?1:n.daily?.7:o?.05*e:(e-3)/9,l=Math.min(1,c*.75+(i-1)/4*.35),u=o?.02:.05;let h=KS(i,n.daily?8:e);const d=n.special?4:o?a?.recipe?2:1:2+(l>.45?1:0)+(l>.8?1:0),f=nd(td,i),g=nd(ed,i),_=td[i-1],m=ed[i-1],p=[];for(let X=0;X<d;X++)if(X===0&&a?.recipe)p.push(a.recipe);else{let he=_.length&&s()<.5?r(_):r(f);he===p[X-1]&&(he=r(f)),p.push(he)}let M=0;for(let X=0;X<p.length;X++)p[X].endsWith("Acorn")&&++M>2&&(p[X]="gap");let v=3-Math.min(2,M);const x=i>=5&&!o?.6:a?.sign==="tut.double"?1:0,I=d+(i===1?2:1),A=n.id??(n.special?`${i}-S`:`${i}-${e}`),T=new sa(A,i,e,I,t,h,u);n.special&&(T.level.special=!0),n.daily&&(T.level.daily=!0);const P=jS(i,e,n.special),b=d+1,w=P/b,D=i===5||s()<.4,z=()=>o?1.7+s()*.5:Math.max(.75,1.35-l*.7+s()*.35),O=X=>{const he=Math.max(2.5,X*h);s()<.55&&he>4&&T.gems(Math.min(6,Math.floor(he/1.2)),.6,.7,1.1),T.ground(he)},Y=o?[...a?.hazard?[a.hazard,a.hazard]:[],"stump","gap","lowLog","beetle"].filter(X=>g.includes(X)):g,q=()=>a?.hazard&&s()<.45?a.hazard:!o&&m.length&&s()<.3?r(m):r(Y);let j="";const Q=X=>{switch(X){case"stump":T.arc(3,.3,2.2,1.2,1.2).stump(.9,1,1,1);break;case"gap":case"stream":{const he=2.2+s()*.6;T.ground(1).arc(4,-.4,he+.8,1.5).gap(he,X==="stream"||D).ground(1.5);break}case"lowLog":T.gems(3,1.5,.45,1).lowLog(2.5+s()*1.2,1,1);break;case"thorns":{const he=1.3+s()*.6;T.ground(1).arc(3,0,he,1.4,1.2).thorns(he,.8).ground(1.5);break}case"beetle":T.beetle(2.5,3+s(),1.2+s()*.4).ground(6);break;case"beetles":T.beetle(2,2.5,1.3).beetle(6.5,2.5,1.5).ground(10);break;case"snail":T.enemy("snail",2.5,1.5,.6).arc(3,1.8,2.2,1.2,1.2).ground(5.5);break;case"beeHigh":T.enemy("bee",3,1.2,1.1,{y:1.4,amp:.25,phase:s()*6}).gems(3,2.5,.45,1).ground(6);break;case"beeLow":T.enemy("bee",3,1,1,{y:.4,amp:.2,phase:s()*6}).arc(3,2.2,2,1.2,1.4).ground(6);break;case"roller":T.enemy("roller",13,0,0).gems(4,1,.7,1.2).ground(14);break;case"step":T.y<2&&s()<.6?T.ground(1).up(1).ground(4):T.y>.5?T.ground(1).down(1).ground(4):T.ground(5);break}j=X},W=()=>{const X=s();X<.34?T.ground(2).acorn(2.5,3.4).ground(5):X<.67?T.ground(1).ledge(2.5,2.6,4).acorn(4.5,3.6).gems(3,3,3.2,1).ground(10):T.acorn(2.6,.4).lowLog(3.2,1,1),v--},le=()=>{T.checkpoint(0),h=Math.min(Nl,h*(1+u))},pe=(X,he,Ae)=>{const Ie=T.x;he?(T.ground(6).gems(5,1,.7,1.2).ground(8),a?.hazard&&T.sign(a.sign,a.hand,1).ground(4)):O(1.2);const Je=Math.max(Ae,Math.round(X/3.2)),ee=new Set;for(;ee.size<Ae;)ee.add(Math.floor(s()*Je));let re=T.x;for(let C=0;C<Je||(T.x-Ie)/h<X;C++){if(ee.has(C))W();else{let Te=q();if(Te===j&&s()<.6&&(Te=q()),Q(Te),!o&&s()<.15+l*.55){T.ground(Math.max(1.5,(.55+s()*.2)*h));let ie=q();(ie==="roller"||ie==="step")&&(ie=r(Y.filter(_e=>_e!=="roller"&&_e!=="step"))),Q(ie)}}O(z()),T.x-re>24*h&&(le(),re=T.x)}},Me=X=>{({river:()=>T.decision("river",5.5,Le(["bridge","vine",i>=2?"leaf":"vine"]),"bridge"),gap:()=>T.decision("gap",5.5,Le(["bridge","vine",i>=2?"leaf":"vine"]),"bridge"),wall:()=>T.decision("wall",5,Le(["bridge","vine","mushroom",...i>=3?["tree"]:[]]),"vine"),thorns:()=>T.arc(5,1.5,5,2.4,1.5).decision("thorns",5,Le(["bridge","mushroom","vine",...i>=2?["leaf"]:[]]),"mushroom"),cliff:()=>T.decision("cliff",13,Le(["leaf","bridge","mushroom"]),"leaf",{drop:4}),cliffTree:()=>T.decision("cliff",13,Le(["leaf","tree","bridge"]),"leaf",{drop:4}),riverAcorn:()=>T.decision("river",5.5,Le(["bridge","mushroom","vine"]),"mushroom",{alsoWorks:["bridge"],acornAt:[2.8,3.6]}),lowWallAcorn:()=>T.decision("wall",3,Le(["vine","mushroom","leaf"]),"vine",{alsoWorks:["mushroom"],acornAt:[-.5,5.6]}),wideRiver:()=>T.decision("river",8.5,Le(["bridge","tree","mushroom"]),"tree"),shortThorns:()=>T.decision("thorns",3.4,Le(["log","bridge","tree","vine"]),"log",{thornH:.8}),shortThornsAcorn:()=>T.decision("thorns",3.4,Le(["log","mushroom","bridge"]),"mushroom",{thornH:.8,alsoWorks:["log"],acornAt:[1.7,3.5]})})[X]()};function Le(X){const he=[...new Set(X)];for(let Ae=he.length-1;Ae>0;Ae--){const Ie=Math.floor(s()*(Ae+1));[he[Ae],he[Ie]]=[he[Ie],he[Ae]]}return he}const qe=Array.from({length:b},()=>0);for(let X=0;X<v;X++)qe[(X*2+1)%b]++;let J=0;for(let X=0;X<b&&(X===0||J<d||X===b-1);X++)if(pe(w,X===0,qe[X]),J<d&&(le(),T.ground(3),a?.recipe&&J===0&&T.sign(a.sign,"choose",0).ground(2),Me(p[J++]),J<d&&s()<x&&(T.ground(3),Me(p[J++]),qe[X+1]+=qe[X+2]??0,X+2<b&&(qe[X+2]=0)),T.gems(4,1.5,.7,1).ground(6),J>=d)){pe(w,!1,qe.slice(X+1).reduce((he,Ae)=>he+Ae,0));break}le(),T.gems(6,0,.7,1).ground(8);const ae=T.goal().done(),we=ae.pickups.filter(X=>X.kind==="acorn").length;if(we!==3)throw new Error(`${ae.id}: ${we} golden acorns`);return ae}const ZS={},JS=[1,1,1,1,1],bo=Array.from({length:30},(i,e)=>101+e),zl=5,Pr=12,id=new Map;function Hl(i,e){let t=id.get(i);return t||id.set(i,t=e()),t}function Nf(i,e){return i===1&&e<=Qh.length?Qh[e-1]:Hl(`${i}-${e}`,()=>Bl(i,e,ZS[`${i}-${e}`]??1))}function Uf(i){return Hl(`${i}-S`,()=>Bl(i,12,JS[i-1]??1,{special:!0}))}function kf(i){const e=(i%bo.length+bo.length)%bo.length,t=e%zl+1;return Hl(`daily-${e}`,()=>Bl(t,8,bo[e],{daily:!0,id:`daily-${e}`}))}const Rs=[];for(let i=1;i<=zl;i++)for(let e=1;e<=Pr;e++)Rs.push(`${i}-${e}`);function Lr(i){const e=/^(\d)-(\d+|S)$/.exec(i);if(e)return e[2]==="S"?Uf(+e[1]):Nf(+e[1],+e[2]);const t=/^daily-(\d+)$/.exec(i);return t?kf(+t[1]):null}function QS(i){const e=Rs.indexOf(i);return e>=0&&e+1<Rs.length?Lr(Rs[e+1]):null}class ew{constructor(e){te(this,"i",0);te(this,"c",0);this.plan=e}input(e){return e.mode!=="run"?Nh:this.plan.inputs[this.i++]??Nh}choice(){return this.plan.choices[this.c++]??null}}const tw=12e4,nw=8e3,sd=["sprout-trail-save"],rd=1e4;class iw{constructor(){te(this,"name","playgama");te(this,"autoResume",!1);te(this,"b",null);te(this,"playing",!1);te(this,"levelOn",!1);te(this,"readySent",!1);te(this,"lastMidgame",Date.now());te(this,"pausedBy",new Set);te(this,"paused",!1);te(this,"soundOff",!1);te(this,"lang",null);te(this,"store",null);te(this,"pending",null);te(this,"muted",!1);te(this,"log",[]);te(this,"onMute",()=>{});te(this,"onAdPause",()=>{})}async init(e=rd){typeof window<"u"&&(window.__playgama=this);const t=typeof window<"u"?window.bridge:void 0;if(t?.initialize)try{let s;await Promise.race([t.initialize(),new Promise((r,o)=>s=setTimeout(()=>o(new Error("timeout")),Math.max(e,rd)))]),clearTimeout(s),this.b=t}catch{this.b=null}const n=this.b;if(n){try{this.lang=n.platform.language||null}catch{this.lang=null}await this.loadStore(n);const s=n.EVENT_NAME;try{this.soundOff=n.platform.isAudioEnabled===!1,n.platform.on(s.AUDIO_STATE_CHANGED,(r=>this.setSound(r!==!1))),n.platform.on(s.PAUSE_STATE_CHANGED,(r=>this.setPaused("sdk",!!r))),n.advertisement.on(s.INTERSTITIAL_STATE_CHANGED,(r=>this.onAdState("interstitial",r))),n.advertisement.on(s.REWARDED_STATE_CHANGED,(r=>this.onAdState("rewarded",r)))}catch{}this.updateMute()}typeof document<"u"&&(document.addEventListener("visibilitychange",()=>this.setPaused("hidden",document.hidden)),document.addEventListener("contextmenu",s=>s.preventDefault()),document.documentElement?.style?.setProperty("-webkit-touch-callout","none"))}async loadStore(e){const t=new Map;try{const n=await e.storage.get(sd);sd.forEach((s,r)=>{const o=Array.isArray(n)?n[r]:null;o!=null&&t.set(s,typeof o=="string"?o:JSON.stringify(o))})}catch{}this.store={getItem:n=>t.get(n)??null,setItem:(n,s)=>{if(t.get(n)!==s){t.set(n,s);try{Promise.resolve(e.storage.set(n,s)).catch(()=>{})}catch{}}}}}get available(){try{return!!this.b&&this.b.advertisement.isRewardedSupported===!0}catch{return!1}}setPaused(e,t){if(t===this.pausedBy.has(e))return;t?this.pausedBy.add(e):this.pausedBy.delete(e);const n=this.pausedBy.size>0;n!==this.paused&&(this.paused=n,this.onAdPause(n)),this.updateMute()}setSound(e){this.soundOff!==!e&&(this.soundOff=!e,this.updateMute())}updateMute(){const e=this.paused||this.soundOff;e!==this.muted&&(this.muted=e,this.onMute(e))}onAdState(e,t){this.log.push(`${e}:${t}`);const n=this.pending;!n||n.type!==e||(t==="opened"?(n.opened=!0,this.setPaused("ad",!0)):t==="rewarded"?n.earned=!0:t==="closed"?n.finish(e==="rewarded"?n.earned:!0):t==="failed"&&n.finish(!1))}locale(){return this.lang}data(){return this.store}loadingStart(){}loadingStop(){}gameReady(){this.readySent||!this.b||(this.readySent=!0,this.send("game_ready"))}gameplayStart(){this.playing=!0,!this.levelOn&&(this.levelOn=!0,this.send("level_started"))}gameplayStop(){this.playing=!1}levelEnd(e){this.levelOn&&(this.levelOn=!1,this.send(e?"level_completed":"level_failed"))}happytime(){}sadMoment(){}send(e){this.log.push(e);try{Promise.resolve(this.b?.platform.sendMessage(e)).catch(()=>{})}catch{}}requestAd(e){const t=this.b;return!t||this.pending?Promise.resolve(!1):new Promise(n=>{let s=!1;const r={type:e,opened:!1,earned:!1,finish:a=>{s||(s=!0,clearTimeout(o),this.pending===r&&(this.pending=null),this.setPaused("ad",!1),n(a))}};this.pending=r;const o=setTimeout(()=>{r.opened||r.finish(!1)},nw);try{e==="rewarded"?t.advertisement.showRewarded():t.advertisement.showInterstitial()}catch{r.finish(!1)}})}adSlot(e){return e!=="preroll"}async midgame(e="between"){if(!(!this.adSlot(e)||this.playing||!this.b||this.pending)){try{if(!this.b.advertisement.isInterstitialSupported)return}catch{return}Date.now()-this.lastMidgame<tw||(this.lastMidgame=Date.now(),await this.requestAd("interstitial"))}}async rewarded(){if(!this.available)return!1;const e=await this.requestAd("rewarded");return e&&(this.lastMidgame=Date.now()),e}}const gt=new iw,Ff=new URLSearchParams(location.search),od=Ff.has("capture"),sw=()=>gt.available,rw=document.getElementById("game"),Ji=new pM(rw);Ji.setTheme(fM);let Ve=null,Vt="title",el=!1;function Of(){Ji.resize(window.innerWidth,window.innerHeight,Math.min(window.devicePixelRatio||1,2))}window.addEventListener("resize",Of);Of();const Et=()=>Mt("click"),Bf=i=>!!De.levels[`${i}-${Pr}`]?.done,tl=i=>i===1||Bf(i-1);function nl(i){const e=/^(\d)-(\d+|S)$/.exec(i);if(!e)return!0;const t=+e[1];if(!tl(t))return!1;if(e[2]==="S")return Bf(t);const n=+e[2];return n===1||!!De.levels[`${t}-${n-1}`]?.done}const ow=i=>Array.from({length:Pr},(e,t)=>De.levels[`${i}-${t+1}`]?.stars??0).reduce((e,t)=>e+t,0);function zf(){for(const i of Rs)if(!De.levels[i]?.done&&nl(i))return Lr(i);return Lr(De.last??Rs[0])??Nf(1,1)}function ci(i,e=!1){Ve?.dispose();for(const t of["title","end","pause","worlds","daily","wardrobe","settings"])Sn(t);return Ve=new zS(Ji,i,{onWin:(t,n)=>cw(i,t,n),onLose:()=>lw(i),onNoSeeds:()=>uw(i),onPause:()=>Hf()}),Ve.frozen=e,zt.release(),zt.enabled=!e,e||(Vt="play",gt.gameplayStart(),kl()),Ve}async function Ja(i){gt.adSlot("between")&&(Vt="ad",await gt.midgame("between")),i()}async function Vl(i,e){if(i.classList.contains("busy"))return;i.classList.add("busy");const t=await gt.rewarded();i.classList.remove("busy"),t?(Mt("reward"),e()):ia($t("ad.none"),2500)}const Gl=(i,e)=>sw()?`<button class="btn ad" data-ad="${i}">${nt("tv")}<span>${ke(e)}</span></button>`:"";function Qi(){gt.gameplayStop(),zt.enabled=!1,ci(zf(),!0),Vt="title";const i=Object.keys(De.levels).length>0,e=Ci(tn(`<div id="title" class="screen">
      <div class="top"><div class="logo"><span class="sprout">${mw}</span>${Nn($t("title"))}<small>${Nn($t("tagline"))}</small></div></div>
      <div class="bottom"><div class="menu">
        <button class="btn big" data-act="play">${nt("play")}${ke(i?"menu.continue":"menu.play")}</button>
        <div class="two">
          <button class="btn wood" data-act="worlds">${nt("map")}${ke("menu.worlds")}</button>
          <button class="btn wood" data-act="daily">${nt("calendar")}${ke("menu.daily")}</button>
        </div>
        <div class="two">
          <button class="btn wood" data-act="wardrobe">${nt("hat")}${ke("menu.wardrobe")}</button>
          <button class="btn wood" data-act="settings">${nt("gear")}${ke("menu.settings")}</button>
        </div>
      </div></div>
    </div>`));wt(e,"[data-act=play]",()=>{Sn("title"),Ve&&(Ve.frozen=!1,zt.release(),zt.enabled=!0,Vt="play",gt.gameplayStart(),kl())},Et),wt(e,"[data-act=worlds]",()=>ra(),Et),wt(e,"[data-act=daily]",()=>Wl(),Et),wt(e,"[data-act=wardrobe]",()=>Xl(),Et),wt(e,"[data-act=settings]",()=>Fr(),Et)}let ad=1;function ra(i=ad){ad=i;const e=tl(i),t=Array.from({length:Pr},(o,a)=>{const c=`${i}-${a+1}`;return nl(c)?`<button class="lvl" data-lv="${c}">${a+1}<span class="st">${Qc(De.levels[c]?.stars??0)}</span></button>`:`<button class="lvl locked" disabled>${nt("lock","ico lk")}</button>`}).join(""),n=`${i}-S`,s=nl(n)?`<button class="btn special" data-lv="${n}">${nt("star")}${ke("world.special")}<span class="st">${Qc(De.levels[n]?.stars??0)}</span></button>`:`<button class="btn special locked" disabled>${nt("lock")}${ke("world.special")}<small>${ke("world.specialLocked")}</small></button>`,r=Ci(tn(`<div id="worlds" class="screen dim"><div class="panel worlds">
      <h2>${ke("menu.worlds")}</h2>
      <div class="tabs">${Array.from({length:zl},(o,a)=>a+1).map(o=>`<button class="tab${o===i?" on":""}" data-w="${o}">${tl(o)?o:nt("lock")}</button>`).join("")}</div>
      <div class="wname">${ke(`world.${i}`)} <span>${nt("star")}${ow(i)}/${Pr*3}</span></div>
      ${e?`<div class="grid">${t}</div>${s}`:`<p class="locked-note">${nt("lock")}${ke("world.locked")}</p>`}
      <button class="btn wood" data-act="back">${ke("back")}</button>
    </div></div>`));wt(r,"[data-w]",o=>ra(+o.dataset.w),Et),wt(r,"[data-lv]",o=>ci(Lr(o.dataset.lv)),Et),wt(r,"[data-act=back]",()=>Sn("worlds"),Et)}function Wl(){const i=Jc(),e=De.dailyDay===i,t=Ci(tn(`<div id="daily" class="screen dim"><div class="panel">
      <h2>${ke("daily.title")}</h2>
      <div class="streak">${nt("calendar")}<b>${ke("daily.streak",{n:Rf(i)})}</b><span>${ke("daily.best",{n:De.bestStreak})}</span></div>
      <p>${ke(e?"daily.done":"daily.text")}</p>
      <div class="col">
        <button class="btn big" data-act="go">${nt("play")}${ke(e?"daily.again":"daily.play")}</button>
        <button class="btn wood" data-act="back">${ke("back")}</button>
      </div></div></div>`));wt(t,"[data-act=go]",()=>ci(kf(i)),Et),wt(t,"[data-act=back]",()=>Sn("daily"),Et)}function Xl(){const i=t=>{const n=Cf(t),s=_S(t),r=t.kind==="color"?`<span class="swatch" style="background:${t.value}"></span>`:`<span class="hat-ico">${gw[t.id]??""}</span>`,o=s?ke("wardrobe.equipped"):n?ke("wardrobe.equip"):`${nt("gem","ico sm")}${t.price}`;return`<button class="item${s?" on":""}${n?"":" buy"}" data-item="${t.id}">${r}<span class="nm">${ke(`${t.kind==="hat"?"hat":"color"}.${t.id}`)}</span><span class="act">${o}</span></button>`},e=Ci(tn(`<div id="wardrobe" class="screen dim"><div class="panel wardrobe">
      <h2>${ke("wardrobe.title")}</h2>
      <div class="wallet">${nt("gem")}<b>${De.gems}</b></div>
      <h3>${ke("wardrobe.hats")}</h3><div class="items">${qh.map(i).join("")}</div>
      <h3>${ke("wardrobe.colors")}</h3><div class="items">${Wo.map(i).join("")}</div>
      <button class="btn wood" data-act="back">${ke("back")}</button>
    </div></div>`));wt(e,"[data-item]",t=>{const n=[...qh,...Wo].find(r=>r.id===t.dataset.item),s=xS(n);if(s==="poor"){ia($t("wardrobe.poor"),2e3);return}Mt(s==="bought"?"buy":"click"),Vt==="title"&&ci(zf(),!0),Xl()}),wt(e,"[data-act=back]",()=>Sn("wardrobe"),Et)}function Fr(){const i=Ci(tn(`<div id="settings" class="screen dim"><div class="panel">
      <h2>${ke("settings.title")}</h2>
      <div class="set-row"><span class="lbl">${nt("music")}${ke("settings.music")}</span><button class="toggle${De.music?" on":""}" data-set="music">${ke(De.music?"settings.on":"settings.off")}</button></div>
      <div class="set-row"><span class="lbl">${nt("sound")}${ke("settings.sfx")}</span><button class="toggle${De.sfx?" on":""}" data-set="sfx">${ke(De.sfx?"settings.on":"settings.off")}</button></div>
      <div class="set-row"><span class="lbl">${nt("globe")}${ke("settings.language")}</span><select class="lang">${bf.map(e=>`<option value="${e}" ${e===eS()?"selected":""}>${Z1[e]}</option>`).join("")}</select></div>
      <button class="btn danger" data-act="reset">${ke("settings.reset")}</button>
      <button class="btn wood" data-act="back">${ke("back")}</button>
    </div></div>`));wt(i,"[data-set]",e=>{const t=e.dataset.set;De[t]=!De[t],Ri(),il(),Fr()},Et),i.querySelector("select").addEventListener("change",e=>{De.lang=e.target.value,Ri(),Ol(De.lang)}),wt(i,"[data-act=reset]",()=>{const e=Ci(tn(`<div id="confirm" class="screen dim"><div class="panel"><p>${ke("settings.resetAsk")}</p><div class="row">
        <button class="btn danger" data-act="yes">${ke("settings.resetYes")}</button><button class="btn" data-act="no">${ke("settings.resetNo")}</button></div></div></div>`));wt(e,"[data-act=yes]",()=>{gS(),il(),Sn("confirm"),Sn("settings"),Vt==="title"&&Qi()},Et),wt(e,"[data-act=no]",()=>Sn("confirm"),Et)},Et),wt(i,"[data-act=back]",()=>Sn("settings"),Et)}function Hf(){if(!Ve||Vt!=="play")return;Ve.paused=!0,zt.enabled=!1,Vt="pause",gt.gameplayStop();const i=Ci(tn(`<div id="pause" class="screen dim"><div class="panel">
      <h2>${ke("pause.title")}</h2>
      <div class="col">
        <button class="btn big" data-act="resume">${nt("play")}${ke("pause.resume")}</button>
        <button class="btn wood" data-act="restart">${nt("retry")}${ke("pause.restart")}</button>
        <button class="btn wood" data-act="settings">${nt("gear")}${ke("menu.settings")}</button>
        <button class="btn wood" data-act="menu">${nt("home")}${ke("pause.menu")}</button>
      </div></div></div>`));wt(i,"[data-act=resume]",()=>aw(),Et),wt(i,"[data-act=restart]",()=>Ve&&ci(Ve.level),Et),wt(i,"[data-act=settings]",()=>Fr(),Et),wt(i,"[data-act=menu]",()=>Qi(),Et)}function aw(){Sn("pause"),Ve&&(Ve.paused=!1,zt.release(),zt.enabled=!0,Vt="play",gt.gameplayStart())}function ql(i,e,t,n=""){zt.enabled=!1,Vt="end",gt.gameplayStop();const s=Ci(tn(`<div id="end" class="screen dim"><div class="panel">${i}<div class="col">
      ${n}
      ${t?`<button class="btn big" data-act="next">${nt("play")}${ke("win.next")}</button>`:""}
      <div class="row"><button class="btn wood" data-act="retry">${nt("retry")}${ke("win.retry")}</button>
      <button class="btn wood" data-act="menu">${nt("home")}${ke("win.menu")}</button></div></div></div></div>`));return wt(s,"[data-act=next]",()=>void Ja(()=>t&&ci(t)),Et),wt(s,"[data-act=retry]",()=>void Ja(()=>ci(e)),Et),wt(s,"[data-act=menu]",()=>void Ja(()=>e.daily?(Qi(),Wl()):(Qi(),ra(e.world))),Et),s}function cw(i,e,t){pS(i.id,{stars:t,acorns:e.acorns,gems:e.gems},e.gems),i.daily&&mS(Jc()),gt.happytime(),gt.levelEnd?.(!0);const n=i.daily||i.special?null:QS(i.id),s=ql(`<h2>${ke("win.title")}</h2><div class="stars">${Qc(t)}</div>
     <div class="tally">
       ${nt("acorn")}<span>${ke("win.acorns")}</span><span class="val">${[0,1,2].map(o=>nt(o<e.acorns?"acorn":"acornEmpty")).join("")}</span>
       ${nt("gem")}<span>${ke("win.earned")}</span><span class="val" data-earned>${e.gems}</span>
       ${i.dps.length?`${nt("seed")}<span>${ke("win.seeds")}</span><span class="val">${e.seeds}</span>`:""}
     </div>
     ${i.daily?`<p class="streak-line">${nt("calendar")}${ke("daily.streak",{n:Rf(Jc())})}</p>`:""}`,i,n,e.gems>0?Gl("gems","ad.gems"):""),r=s.querySelector("[data-ad=gems]");r?.addEventListener("click",o=>{o.stopPropagation(),Vl(r,()=>{De.gems+=e.gems,Ri(),s.querySelector("[data-earned]").textContent=String(e.gems*2),r.remove(),ia($t("ad.doubled"),1800)})})}function lw(i){gt.sadMoment?.("lost"),gt.levelEnd?.(!1);const t=ql(`<h2>${ke("lost.title")}</h2><p>${ke("lost.text")}</p>`,i,null,Ve?.revived?"":Gl("heart","ad.heart")).querySelector("[data-ad=heart]");t?.addEventListener("click",n=>{n.stopPropagation(),Vl(t,()=>{Sn("end"),Ve&&(Ve.revived=!0,Ve.paused=!1,Ve.reviveWithHeart(),zt.release(),zt.enabled=!0,Vt="play",gt.gameplayStart())})})}function uw(i){const t=ql(`<h2>${ke("seeds.title")}</h2><p>${ke("seeds.text")}</p>`,i,null,Gl("seeds","ad.seeds")).querySelector("[data-ad=seeds]");t?.addEventListener("click",n=>{n.stopPropagation(),Vl(t,()=>{Sn("end"),Ve&&(Ve.paused=!1,Ve.addTwoSeeds(),zt.release(),zt.enabled=!0,Vt="play",gt.gameplayStart())})})}function il(){$M(De.music),qM(De.sfx)}tS(()=>{document.getElementById("settings")&&(Vt==="title"&&Qi(),Fr())});let sl=performance.now();function Vf(i){const e=Math.min(.1,(i-sl)/1e3);sl=i,el||Gf(e),requestAnimationFrame(Vf)}function Gf(i,e=!0){Ve?.update(i),Ve?.paused||OS(i),Ji.update(i),e&&Ji.render()}document.addEventListener("visibilitychange",()=>{document.hidden&&Vt==="play"&&Hf()});async function hw(){const i=document.querySelector("#loading .bar i");let e=.05;const t=s=>{e=Math.max(e,s),i&&(i.style.width=`${Math.round(e*100)}%`)};gt.loadingStart(),t(.1),zt.attach(document.body),zt.onAny=()=>XM(),zt.onGesture=s=>Ve?.gesture(s),gt.onMute=s=>Ka(s||el),gt.onAdPause=s=>{el=s,Ka(s||gt.muted),Ve&&(Ve.paused=s||Vt!=="play")},wf();const n=od&&Ff.has("nosdk")?Promise.resolve():gt.init(3e3);await Promise.all([n.then(()=>t(.3)),cM("./models/nature.glb").then(()=>t(.85)),document.fonts?.load("700 40px Fredoka").catch(()=>{})]),fS(gt.data()),Ol(Q1(De.lang,gt.locale(),navigator.language)),Ka(gt.muted),il(),t(1),gt.loadingStop(),await gt.ready?.(),Qi(),Ji.render(),document.getElementById("loading")?.remove(),gt.gameReady?.(),od?pw():requestAnimationFrame(s=>{sl=s,requestAnimationFrame(Vf)})}function dw(i){return[...i].map(e=>{const t=e.charCodeAt(0)-65;return{jumpPressed:!!(t&1),jumpHeld:!!(t&2),duckPressed:!!(t&4),duckHeld:!!(t&8)}})}function fw(i){const e=tn(`<div class="finger ${i}" style="left:${Math.round(window.innerWidth*.66)}px;top:${Math.round(window.innerHeight*.62)}px"></div>`);document.getElementById("ui").append(e),BS(e,i==="tap"?.3:.45)}function pw(){window.__game={tick:(i,e=!0)=>Gf(i,e),render:()=>Ji.render(),state:()=>Ve?{mode:Ve.sim.mode,x:Ve.sim.x,y:Ve.sim.y,level:Ve.level.id,screen:Vt,acorns:Ve.sim.acorns,gems:Ve.sim.gems,seeds:Ve.sim.seeds,hearts:Ve.sim.hearts,speed:Ve.sim.speed,finished:Ve.finished}:null,start:i=>ci(Lr(i)),special:i=>ci(Uf(i)),replay:(i,e,t=1.1,n=!0)=>{Ve&&(Ve.replay=new ew({inputs:dw(i),choices:e}),Ve.botThink=t,Ve.onBotGesture=n?s=>fw(s):null)},screen:()=>Vt,sim:()=>Ve?.sim,save:()=>De,setSave:i=>{Object.assign(De,i),Ri()},title:()=>Qi(),showWorlds:i=>ra(i),showDaily:()=>Wl(),showWardrobe:()=>Xl(),showSettings:()=>Fr(),teleportToDecision:()=>{if(!Ve)return;const i=Ve.nextDecision();if(i<0)return;const e=Ve.level.dps[i];Object.assign(Ve.sim,{x:e.stopX-3,y:e.y,vx:0,vy:0,grounded:!0})},lose:()=>Ve?.forceLose(),lang:i=>Ol(i),cover:(i,e=.62)=>{document.body.classList.toggle("cover",i),Ve&&(Ve.coverZoom=i?e:0),document.getElementById("cover-logo")?.remove(),i&&document.getElementById("ui").append(tn(`<div id="cover-logo" class="logo">${Nn($t("title"))}<small>${Nn($t("tagline"))}</small></div>`))},platform:"playgama"},window.__ready=!0}const mw='<svg viewBox="0 0 64 64"><path d="M32 60 C31 48 32 40 33 30" stroke="#2f7a1c" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M33 32 C18 32 8 22 8 10 C22 10 32 18 33 32Z" fill="#7bd05a" stroke="#2f7a1c" stroke-width="3.5" stroke-linejoin="round"/><path d="M33 26 C44 26 56 18 56 6 C42 6 34 14 33 26Z" fill="#9fe070" stroke="#2f7a1c" stroke-width="3.5" stroke-linejoin="round"/></svg>',gw={none:'<svg viewBox="0 0 64 64"><circle cx="32" cy="36" r="20" fill="#9fd66b" stroke="#2f7a1c" stroke-width="3"/></svg>',acorn:'<svg viewBox="0 0 64 64"><path d="M10 40 C10 22 22 14 32 14 C42 14 54 22 54 40Z" fill="#9a6a3a" stroke="#5a3a20" stroke-width="3"/><path d="M36 14 L42 6" stroke="#5a3a20" stroke-width="4"/></svg>',flower:'<svg viewBox="0 0 64 64">'+[0,1,2,3,4,5].map(i=>`<circle cx="${32+Math.cos(i)*14}" cy="${32+Math.sin(i)*14}" r="9" fill="#ff8fc0"/>`).join("")+'<circle cx="32" cy="32" r="8" fill="#ffd23a"/></svg>',bow:'<svg viewBox="0 0 64 64"><path d="M32 32 L8 18 L8 46Z M32 32 L56 18 L56 46Z" fill="#7fb8ff" stroke="#3a6fc0" stroke-width="3"/><circle cx="32" cy="32" r="6" fill="#5a8fe0"/></svg>',mushroom:'<svg viewBox="0 0 64 64"><path d="M6 40 C6 18 22 10 32 10 C42 10 58 18 58 40Z" fill="#ff6b6b" stroke="#a8243c" stroke-width="3"/><circle cx="24" cy="24" r="5" fill="#fff"/><circle cx="40" cy="28" r="4" fill="#fff"/></svg>',straw:'<svg viewBox="0 0 64 64"><ellipse cx="32" cy="42" rx="28" ry="7" fill="#f0cf7a" stroke="#b08a3a" stroke-width="3"/><path d="M18 42 C18 24 46 24 46 42Z" fill="#f0cf7a" stroke="#b08a3a" stroke-width="3"/><path d="M18 38 H46" stroke="#e0566a" stroke-width="5"/></svg>',crown:'<svg viewBox="0 0 64 64"><path d="M8 46 L12 18 L24 32 L32 12 L40 32 L52 18 L56 46Z" fill="#7bd05a" stroke="#2f7a1c" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="38" r="4" fill="#ffd23a"/></svg>'};hw();
